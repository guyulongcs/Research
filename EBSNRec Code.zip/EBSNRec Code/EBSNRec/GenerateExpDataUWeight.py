from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from scipy.sparse import *

class GenerateExpDataUWeight():
    def __init__(self, data, ebsnData):
        self.data = data
        self.ebsnData = ebsnData

        self.dictUserGroupSet = {}
        self.dictUserEventSet = {}

        self._dict_user_user_weight_on = None
        self._dict_user_user_weight_off = None

        self._dict_user_user_sameGroupCnt = None
        self._dict_user_user_sameEventCnt = None

    def generate_user_weight(self):

        self.init_data()
        self.generate_weight()

        #return (self._dict_user_user_weight_on, self._dict_user_user_weight_off)

    def init_data(self):
        dictUserGroupSet = {}
        dictUserEventSet = {}


        for group_id in self.ebsnData.dictGroupUserset:
            for user_id in self.ebsnData.dictGroupUserset[group_id]:
                if((user_id in self.data._userSet) and (group_id in self.ebsnData.setGroup)):
                    TypeProcessTool.dictStrSetstr_add_str_str(dictUserGroupSet, user_id, group_id)

        for rsvp_id in self.ebsnData.dictRsvp:
            rsvp = self.ebsnData.dictRsvp[rsvp_id]
            user_id = rsvp.user_id
            event_id = rsvp.event_id

            if((user_id in self.data._userSet) and (event_id in self.data._itemSet)):
                TypeProcessTool.dictStrSetstr_add_str_str(dictUserEventSet, user_id, event_id)

        self.dictUserGroupSet = dictUserGroupSet
        self.dictUserEventSet = dictUserEventSet

    def is_valid_set_join(self, set_join, threshold):
        return (len(set_join) >= threshold)

    def generate_weight(self):
        InOut.console_func_begin("GenerateExpDataUWeight generate_weight")
        dictUserUserWeightOn = {}
        dictUserUserWeightOff = {}

        dictUserUserSameGroupCnt = {}
        dictUserUserSameEventCnt = {}
        userSet = self.data._userSet

        userList = list(userSet)

        N = len(userList)

        i=0

        for index_1 in range(N):
            user_id_1 = userList[index_1]

            cnt_group = 0
            cnt_event = 0
            for index_2 in range(index_1+1, N):
                user_id_2 = userList[index_2]

                #if(user_id_1 >= user_id_2):
                #    continue

                #print "\nuser_id_1:%s, user_id_2:%s" % (user_id_1, user_id_2)


                ##group
                u1_group_set = self.dictUserGroupSet.get(user_id_1, set())
                u2_group_set = self.dictUserGroupSet.get(user_id_2, set())

                set_join = u1_group_set & u2_group_set

                #linear social feature
                if(self.is_valid_set_join(set_join, Config.p_linear_user_weight_set_join_group_threshold)):
                    TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictUserUserSameGroupCnt, user_id_1, user_id_2, len(set_join))


                if( self.is_valid_set_join(set_join, Config.p_mf_user_weight_set_join_group_threshold)):
                    #print "\nu1_group_set:", len(u1_group_set)
                    #print "u2_group_set:", len(u2_group_set)
                    #print "group set_join:", len(set_join)

                    cnt_group+=1

                    jaccard_group = TypeProcessTool.cal_jaccard(u1_group_set, u2_group_set)

                    #dict
                    if(jaccard_group > 0):
                        #print "u1:%s, u2:%s, jaccard_group:%s" % (user_id_1, user_id_2, str(jaccard_group))
                        TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictUserUserWeightOn, user_id_1, user_id_2, jaccard_group)
                        #TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictUserUserWeightOn, user_id_2, user_id_1, jaccard_group)


                ##event

                u1_event_set = self.dictUserEventSet.get(user_id_1, set())
                u2_event_set = self.dictUserEventSet.get(user_id_2, set())


                set_join = u1_event_set & u2_event_set

                #linear social feature
                if(self.is_valid_set_join(set_join, Config.p_linear_user_weight_set_join_event_threshold)):
                    TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictUserUserSameEventCnt, user_id_1, user_id_2, len(set_join))

                if( self.is_valid_set_join(set_join, Config.p_mf_user_weight_set_join_event_threshold) ):
                    cnt_event+=1
                    # print "\nu1_event_set:", len(u1_event_set)
                    # print "u1_event_set:", len(u1_event_set)
                    #print "event set_join:", len(set_join)
                    jaccard_event = TypeProcessTool.cal_jaccard(u1_event_set, u2_event_set)

                    #dict
                    if(jaccard_event > 0):
                        #print "u1:%s, u2:%s, jaccard_event:%s" % (user_id_1, user_id_2, str(jaccard_event))
                        TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictUserUserWeightOff, user_id_1, user_id_2, jaccard_event)
                        #TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictUserUserWeightOff, user_id_2, user_id_1, jaccard_event)

            #print "user_id:%s, cnt_group:%d, cnt_event:%d" % (user_id_1, cnt_group, cnt_event)
            #print info
            i += 1
            if(i% 10 == 0):
                print "processed %d/%d" % (i, N)
                #break
        self._dict_user_user_weight_on = dictUserUserWeightOn
        self._dict_user_user_weight_off = dictUserUserWeightOff

        self._dict_user_user_sameGroupCnt = dictUserUserSameGroupCnt
        self._dict_user_user_sameEventCnt = dictUserUserSameEventCnt


    @classmethod
    def generate_user_weight_matrix(cls, dict_user_user_weight_on, dict_user_user_weight_off, dictUserIndex, userSet, user_weight_on):
        InOut.console_func_begin("generate_user_weight_matrix")
        N = len(userSet)

        user_weight = lil_matrix((N, N))
        user_weight_off = 1 - user_weight_on
        #on
        for u_id_1 in dict_user_user_weight_on:
            print "\nu_id_1:", u_id_1
            print "on friend:", len(dict_user_user_weight_on[u_id_1])
            for u_id_2 in dict_user_user_weight_on[u_id_1]:

                #print "u_id_1:%s, u_id_2:%s" %( u_id_1, u_id_2)

                weight_on = dict_user_user_weight_on[u_id_1][u_id_2]

                u_index_1 = dictUserIndex[u_id_1]
                u_index_2 = dictUserIndex[u_id_2]

                weight_res = user_weight_on * weight_on
                #print "weight_res:", weight_res
                user_weight[u_index_1, u_index_2] += weight_res

        #off
        for u_id_1 in dict_user_user_weight_off:
            print "\nu_id_1:", u_id_1
            print "off friend:", len(dict_user_user_weight_off[u_id_1])
            for u_id_2 in dict_user_user_weight_off[u_id_1]:

                #print "u_id_1:%s, u_id_2:%s" %( u_id_1, u_id_2)
                weight_off = dict_user_user_weight_off[u_id_1][u_id_2]
                u_index_1 = dictUserIndex[u_id_1]
                u_index_2 = dictUserIndex[u_id_2]
                weight_res = user_weight_off * weight_off
                #print "weight_res:", weight_res
                #user_weight[u_index_1, u_index_2] += weight_res


        user_weight = user_weight.tocsr()

        print "user_weight:", user_weight.getnnz()
        return user_weight
        pass

    @classmethod
    def generate_user_weight_matrix_1(cls, dict_user_user_weight_on, dict_user_user_weight_off, dictUserIndex, userSet, user_weight_on):
        InOut.console_func_begin("generate_user_weight_matrix")
        N = len(userSet)

        user_weight = lil_matrix((N, N))
        user_weight_off = 1 - user_weight_on
        #on
        for u_id_1 in dict_user_user_weight_on:

            if(u_id_1 not in dict_user_user_weight_off):
                continue
            for u_id_2 in dict_user_user_weight_on[u_id_1]:
                if(u_id_2 not in dict_user_user_weight_off[u_id_1]):
                    continue

                print "u_id_1:%s, u_id_2:%s" %( u_id_1, u_id_2)

                weight_on = dict_user_user_weight_on[u_id_1][u_id_2]
                weight_off =  dict_user_user_weight_off[u_id_1][u_id_2]

                u_index_1 = dictUserIndex[u_id_1]
                u_index_2 = dictUserIndex[u_id_2]

                weight_res = user_weight_on * weight_on + user_weight_off * weight_off
                print "weight_res:", weight_res
                user_weight[u_index_1, u_index_2] += weight_res

        #off
        # for u_id_1 in dict_user_user_weight_off:
        #     print "u_id_1:", u_id_1
        #     print "off frined:", len(dict_user_user_weight_off[u_id_1])
        #     for u_id_2 in dict_user_user_weight_off[u_id_1]:
        #         weight = dict_user_user_weight_off[u_id_1][u_id_2]
        #         u_index_1 = dictUserIndex[u_id_1]
        #         u_index_2 = dictUserIndex[u_id_2]
        #         user_weight[u_index_1, u_index_2] += user_weight_off * weight


        user_weight = user_weight.tocsr()

        print "user_weight:", user_weight.getnnz()
        return user_weight
        pass





