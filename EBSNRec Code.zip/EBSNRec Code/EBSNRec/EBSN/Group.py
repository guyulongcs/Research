
from os.path import *
from Config import *
from Tool import *
from Tool.FileTool.FileTool import *
from Tool.TypeTool.TypeToTool import *
from Tool.TimeTool.TimeTool import *
from FilePro import *

class Group():
    def __init__(self):
        self.group_id = ""
        self.name = ""
        self.urlname = ""
        self.created = ""
        self.city = ""
        self.country = ""
        self.join_mode = ""
        self.visibility = ""
        self.latitude = 0.0
        self.longitude = 0.0
        self.users = 0
        self.category_id = ""
        self.organizer_id = ""
        self.region = ""

        pass

    def set_value(self, list):
        if(len(list) != Config.file_col_cnt[Config.file_group]):
            print " set_value error..."
            return

        self.group_id = list[0]
        self.name = list[1]
        self.urlname = list[2]
        self.created = TimeTool.get_datetime_or_str(list[3])
        self.city = list[4]
        self.country = list[5]
        self.join_mode = list[6]
        self.visibility = list[7]
        self.latitude = TypeToTool.float_str_to_float(list[8])
        self.longitude = TypeToTool.float_str_to_float(list[9])
        self.users = TypeToTool.int_str_to_int(list[10])
        self.category_id = list[11]
        self.organizer_id = list[12]
        self.region = list[13]

    def ToList(self):
        resList = [self.group_id, self.name, self.urlname, self.created, self.city, self.country, self.join_mode, self.visibility, self.latitude, self.longitude,
                   self.users, self.category_id, self.organizer_id, self.region]
        return resList

    @classmethod
    def load_data_group_0(cls):
        file_group = Group.get_file_group()
        listlineList = FileTool.ReadListLineListFromFile(file_group, Config.file_skip_count, Config.file_split_char)

        dictRes = []
        for listline in listlineList:
            group = Group()
            group.set_value(listline)
            dictRes[group.group_id] = group

        return dictRes


    @classmethod
    def load_data_group(cls):
        InOut.console_func_begin("load_data_group")
        file_group = Group.get_file()
        return Group.load_data_group_file(file_group)

    @classmethod
    def load_data_group_region(cls):
        file_group = Group.get_file_region()
        return Group.load_data_group_file(file_group)

    @classmethod
    def load_set_group_region(cls):
        dictGroup = Group.load_data_group_region()
        groupList = dictGroup.keys()
        groupSet = set(groupList)
        return groupSet

    @classmethod
    def load_data_group_file(cls, file):
        listlineList = FilePro.load_file_csv(file)

        dictRes = {}
        for listline in listlineList:
            #print ','.join(listline)
            group = Group()
            group.set_value(listline)
            dictRes[group.group_id] = group

        return dictRes

    @classmethod
    def load_data_listLineList(cls):
        file_group = Group.get_file()
        listLineList = FilePro.load_file_csv(file_group)

        return listLineList


    @classmethod
    def get_file(cls):
        file_group = FilePro.get_file(Config.file_group)
        return file_group
        pass

    @classmethod
    def get_file_region(cls):
        file_group = FilePro.get_file_region(Config.file_group)
        return file_group

