import numpy as np

from scipy.sparse import csr_matrix
from Tool.MatrixTool.SparseMatrix import *
from Tool.MLTool.Metric import *

class Content():
    def __init__(self):
        pass

    @classmethod
    def cal_item_similarity_dot(cls, item1_vec, item2_vec):
        InOut.console_func_begin("cal_item_similarity")

        ##print "item1_vec:"
        #print item1_vec

        #print "item2_vec:"
        #print item2_vec

        sim = Content.cal_item_dot(item1_vec, item2_vec)

        #print "sim:", sim
        return sim

    @classmethod
    def cal_item_dot(cls, item1_vec, item2_vec):
        res = SparseMatrix.cal_sparseMatrix_dot(item1_vec, item2_vec)
        return res

    @classmethod
    def cal_item_similarity_cos(cls, item1_vec, item2_vec):
        res = 0
        res = Metric.cal_vec_cos(item1_vec, item2_vec)
        return res

    @classmethod
    def cal_event_similarity(cls, eventid1, eventid2, dataLinear):
        #print "dict_content_eventid_vec_tfidf:"
        #print len(dataLinear.dict_content_eventid_vec_tfidf)
        #print "eventid1:%s, eventid2:%s" % (eventid1, eventid2)
        v1 = dataLinear.dict_content_eventid_vec_tfidf[eventid1]
        v2 = dataLinear.dict_content_eventid_vec_tfidf[eventid2]
        res = Content.cal_item_similarity_cos(v1, v2)
        return res
