from Event import *
class EBSNData():
    def __init__(self):
        self.dictUser = {}
        self.dictUserTag = {}

        self.dictUserGroupset = {}

        self.dictGroup = {}
        self.dictGroupUserset = {}
        self.dictGroupTagset = {}
        self.dictGroupEventset = {}

        self.dictEvent = {}
        self.dictEventGroup = {}

        self.dictRsvp = {}

        self.dictLocation = {}

        self.dictCategory = {}

        self.dictTag = {}

        self.setGroup = set()

        pass
    pass

    def print_info(self):
        InOut.console_func_begin("EBSNData print_info")
        print "dictUser:", len(self.dictUser)
        print "dictEventGroup:", len(self.dictEventGroup)
        print "dictGroup:", len(self.dictGroup)
        print "dictRsvp:", len(self.dictRsvp)
        print "setGroup:", len(self.setGroup)
        print "dictUserGroupset:", len(self.dictUserGroupset)


    @classmethod
    def get_past_eventid_list(cls, event_id, ebsnData):
        eventid_list = []

        for eventid in ebsnData.dictEvent:
            flag =  Event.happenBefore(ebsnData.dictEvent[eventid], ebsnData.dictEvent[event_id])
            if(flag == False):
                continue
            eventid_list.append(event_id)
        return eventid_list
