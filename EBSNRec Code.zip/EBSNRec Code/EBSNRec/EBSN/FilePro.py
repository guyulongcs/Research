from Tool.FileTool import *
from Config import *
from Tool.FileTool.FileTool import *
from Tool.DMTool.StatisTool import *
from os.path import *

class FilePro():
    @classmethod
    def load_file_csv(cls, file):
        listlineList = FileTool.ReadFileCSVToListStringList(file, Config.file_skip_count, Config.file_csv_delimiter, Config.file_csv_quotechar)
        return listlineList

    @classmethod
    def write_file_csv(cls, file, listLineList):
        FileTool.WriteFileCSVUseListStringList(file, listLineList, Config.file_csv_delimiter, Config.file_csv_quotechar)


    @classmethod
    def analyse_file_csv(cls, file, col):
        listLineList = FilePro.load_file_csv(file)
        dict = StatisTool.StatisListLineListColDict(listLineList, col)
        return dict

    @classmethod
    def get_file_region(cls, file_flag):
        file = join(Config.folder_data, file_flag + Config.file_format)
        if(Config.flag_process_region):
            file = join(Config.folder_data, Config.folder_City, Config.file_process_region, Config.file_process_region + Config.file_conn + file_flag + Config.file_format)
        print "get_file:", file
        return file

    @classmethod
    def get_file_region_filt(cls, file_flag):
        fileName = Config.file_filt + Config.file_conn + file_flag + Config.file_format
        file = join(Config.folder_data, fileName)
        if(Config.flag_process_region):
            file = join(Config.folder_data, Config.folder_City, Config.file_process_region, Config.file_process_region + Config.file_conn + fileName)
        print "get_file:", file
        return file

    @classmethod
    def get_file_region_org_name(cls, file_flag):
        file = join(Config.folder_data, file_flag + Config.file_format)
        if(Config.flag_process_region):
            file = join(Config.folder_data, Config.folder_City, Config.file_process_region, file_flag + Config.file_format)
        print "get_file:", file
        return file

    @classmethod
    def get_file_region_filt_org_name(cls, file_flag):
        fileName = Config.file_filt + Config.file_conn + file_flag + Config.file_format
        file = join(Config.folder_data, fileName)
        if(Config.flag_process_region):
            file = join(Config.folder_data, Config.folder_City, Config.file_process_region, fileName)
        print "get_file:", file
        return file

    @classmethod
    def get_file(cls, file_flag):
        file = join(Config.folder_data, file_flag + Config.file_format)
        print "get_file:", file
        return file

    @classmethod
    def load_region_user_id_set(cls):
        file = FilePro.get_file_region_filt(Config.file_user_id)
        res = FileTool.ReadFileColumnSet(file)
        return res

    @classmethod
    def load_region_event_id_set(cls):
        file = FilePro.get_file_region_filt(Config.file_event_id)
        res = FileTool.ReadFileColumnSet(file)
        return res

    @classmethod
    def get_file_by_region(cls, flag, region = None):
        file = None
        if(region == None):
            file = FilePro.get_file(flag)
        else:
            file = FilePro.get_file_region(flag)
        return file
    @classmethod
    def load_file_pair_to_dictStrSetstr_flag(cls, flag, region=None):
        file = FilePro.get_file_by_region(flag, region)
        return FilePro.load_file_pair_to_dictStrSetstr(file)

    @classmethod
    def load_file_pair_to_dictStrSetstr_reverse_flag(cls, flag, region=None):
        file = FilePro.get_file_by_region(flag, region)
        return FilePro.load_file_pair_to_dictStrSetstr_reverse(file)

    @classmethod
    def load_file_pair_to_dictStrStr_reverse_flag(cls, flag, region=None):
        file = FilePro.get_file_by_region(flag, region)
        return FilePro.load_file_pair_to_dictStrStr_reverse(file)

    @classmethod
    def load_file_pair_to_bi_dictStrSetstr_flag(cls, flag, region=None):
        file = FilePro.get_file_by_region(flag, region)
        return FilePro.load_file_pair_to_bi_dictStrSetstr(file)


    @classmethod
    def load_file_pair_to_dictStrSetstr(cls, file):
        listLineList = FilePro.load_file_csv(file)
        dictRes = {}
        for listLine in listLineList:
            key = listLine[0]
            value = listLine[1]
            TypeProcessTool.dictStrSetstr_add_str_str(dictRes, key, value)
        return dictRes

    @classmethod
    def load_file_pair_to_dictStrSetstr_reverse(cls, file):
        listLineList = FilePro.load_file_csv(file)
        dictRes = {}
        for listLine in listLineList:
            key = listLine[0]
            value = listLine[1]
            TypeProcessTool.dictStrSetstr_add_str_str(dictRes, value, key)
        return dictRes

    @classmethod
    def load_file_pair_to_bi_dictStrSetstr(cls, file):
        listLineList = FilePro.load_file_csv(file)
        dictRes = {}
        dictRes2 = {}
        for listLine in listLineList:
            key = listLine[0]
            value = listLine[1]
            TypeProcessTool.dictStrSetstr_add_str_str(dictRes, key, value)
            TypeProcessTool.dictStrSetstr_add_str_str(dictRes2, value, key)
        return (dictRes, dictRes2)


    @classmethod
    def load_file_pair_to_dictStrStr_reverse(cls, file):
        listLineList = FilePro.load_file_csv(file)
        dictRes = {}

        for listLine in listLineList:
            key = listLine[0]
            value = listLine[1]
            dictRes[value] = key
        return dictRes


