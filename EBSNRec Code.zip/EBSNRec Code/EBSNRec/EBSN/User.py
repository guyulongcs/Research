
from os.path import *
from Config import *
from Tool import *
from Tool.FileTool import *
from Tool.TypeTool.TypeToTool import *
from Tool.TimeTool.TimeTool import *
from FilePro import *

class User():
    def __init__(self):
        self.user_id = ""
        self.name = ""
        self.city = ""
        self.country = ""
        self.latitude = 0.0
        self.longitude = 0.0
        self.joined = None


        pass

    def set_value(self, list):
        if(len(list) != Config.file_col_cnt[Config.file_user]):
            print " set_value error..."
            return

        self.user_id = list[0]
        self.name = list[1]
        self.city = list[2]
        self.country = list[3]
        self.latitude = TypeToTool.float_str_to_float(list[4])
        self.longitude = TypeToTool.float_str_to_float(list[5])
        self.joined = TimeTool.get_datetime_or_str(list[6])



    @classmethod
    def load_data_user(cls):
        InOut.console_func_begin("load_data_user")
        file = User.get_file_user()
        dictRes = User.load_data_user_file(file)

        return dictRes

    @classmethod
    def load_data_user_file(cls, file):

        #print file
        listlineList = FilePro.load_file_csv(file)

        dictRes = {}
        for listline in listlineList:
            #print ','.join(listline)
            user = User()
            user.set_value(listline)
            dictRes[user.user_id] = user

        return dictRes



    @classmethod
    def get_file_user(cls):
        file = FilePro.get_file(Config.file_user)
        return file
