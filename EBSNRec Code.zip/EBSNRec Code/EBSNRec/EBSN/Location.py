from os.path import *
from Config import *
from Tool import *
from Tool.FileTool.FileTool import *
from Tool.TypeTool.TypeToTool import *
from Tool.TimeTool.TimeTool import *
from FilePro import *

from Tool.GeoTool.GeoLoc import *
from Tool.GeoTool.GeoCoder import *

class Location():
    def __init__(self):
        self.location_id = ""
        self.latitude = 0.0
        self.longitude = 0.0
        self.name = ""
        self.address_1 = ""
        self.address_2 = ""
        self.address_3 = ""
        self.city = ""
        self.country = ""

    def set_value(self, list):
        if(len(list) != Config.file_col_cnt[Config.file_location]):
            print " set_value error..."
            return
        self.location_id = list[0]
        self.latitude =  TypeToTool.float_str_to_float(list[1])
        self.longitude =  TypeToTool.float_str_to_float(list[2])
        self.name = list[3]
        self.address_1 = list[4]
        self.address_2 = list[5]
        self.address_3 = list[6]
        self.city = list[7]
        self.country = list[8]

    @classmethod
    def get_file(cls):
        file = FilePro.get_file(Config.file_location)
        return file

    @classmethod
    def get_file_region(cls):
        file = FilePro.get_file_region(Config.file_location)
        return file



    @classmethod
    def load_data_location(cls):
        InOut.console_func_begin("load_data_location")
        file = Location.get_file()
        return Location.load_data_location_file(file)

    @classmethod
    def load_data_location_region(cls):
        InOut.console_func_begin("load_data_location_region")
        file = Location.get_file_region()
        return Location.load_data_location_file(file)

    @classmethod
    def load_data_location_file(cls, file):

        listlineList = FilePro.load_file_csv(file)

        dictRes = {}
        for listline in listlineList:
            #print ','.join(listline)
            loc = Location()
            loc.set_value(listline)
            dictRes[loc.location_id] = loc

        return dictRes

    @classmethod
    def get_userid_eventid_dis(cls, user_id, event_id, ebsnData):
        res = 0
        #if(True):
        try:
            user = ebsnData.dictUser[user_id]
            loc = Location.get_eventid_loc(event_id, ebsnData)
            res = Location.get_obj_obj_dis(user, loc)
        except:
            res = 0
        return res

    @classmethod
    def get_eventid_loc(cls, event_id, ebsnData):
        event = ebsnData.dictEvent[event_id]
        event_loc_id = event.location_id
        loc = ebsnData.dictLocation[event_loc_id]
        return loc


    @classmethod
    def get_eventid_eventid_dis(cls, eventid_1, eventid_2, ebsnData):
        loc1 = Location.get_eventid_loc(eventid_1, ebsnData)
        loc2 = Location.get_eventid_loc(eventid_2, ebsnData)
        return Location.get_obj_obj_dis(loc1, loc2)

    @classmethod
    def get_obj_obj_dis(cls, obj1, obj2):
        loc1 = GeoLoc(obj1.latitude, obj1.longitude)
        loc2 = GeoLoc(obj2.latitude, obj2.longitude)
        dis = GeoCoder.cal_loc_distance(loc1, loc2)
        res = dis

        res = Location.norm_dis(res)
        return res

    @classmethod
    def norm_dis(cls, n):
        #res = math.exp(-n/2.)
        res = n
        if(Config.p_linear_location_norm_method == Config.p_linear_location_norm_method_list[0]):
            res = n
        elif(Config.p_linear_location_norm_method == Config.p_linear_location_norm_method_list[1]):
            num = Config.p_linear_location_norm_method_linear_num
            res = int(float(res) / num)
        elif(Config.p_linear_location_norm_method == Config.p_linear_location_norm_method_list[2]):
            num = float(Config.p_linear_location_norm_method_exp_num)
            res =  math.exp(-n/num)
        return res