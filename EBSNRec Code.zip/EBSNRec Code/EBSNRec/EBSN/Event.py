
from os.path import *
from Config import *
from Tool import *
from Tool.FileTool import *
from Tool.TimeTool.TimeTool import *

from FilePro import *
from Tool.MLTool.FeatureExtraction import *

class Event():
    def __init__(self):
        self.event_id = ""
        self.name = ""
        self.event_url = ""
        self.description = ""
        self.fee_price = ""
        self.created = None
        self.time = None
        self.utc_offset = ""
        self.status = ""
        self.visibility = ""
        self.headCount = 0
        self.rsvp_limit = 0
        self.location_id = ""
        self.group_id = ""

        pass

    def set_value(self, list):
        if(len(list) != Config.file_col_cnt[Config.file_event]):
            print " set_value error..."
            return
        self.event_id = list[0]
        self.name = list[1]
        self.event_url = list[2]
        self.description = list[3]
        self.fee_price = list[4]
        self.created = TimeTool.get_datetime_or_str(list[5])
        self.time = TimeTool.get_datetime_or_str(list[6])
        self.utc_offset = list[7]
        self.status = list[8]
        self.visibility = list[9]
        self.headCount = TypeToTool.int_str_to_int(list[10])
        self.rsvp_limit = TypeToTool.int_str_to_int(list[11])
        self.location_id = list[12]
        self.group_id = list[13]

    @classmethod
    def get_file(cls):
        file = FilePro.get_file(Config.file_event)
        return file

    @classmethod
    def get_file_region(cls):
        file = FilePro.get_file_region(Config.file_event)
        return file

    @classmethod
    def load_data_event(cls):
        InOut.console_func_begin("load_data_event")
        file = Event.get_file()
        return Event.load_data_event_file(file)

    @classmethod
    def load_data_event_region(cls):
        InOut.console_func_begin("load_data_event")
        file = Event.get_file_region()
        return Event.load_data_event_file(file)


    @classmethod
    def load_data_event_file(cls, file):

        listlineList = FilePro.load_file_csv(file)

        dictRes = {}
        for listline in listlineList:
            #print ','.join(listline)
            event = Event()
            event.set_value(listline)
            dictRes[event.event_id] = event

        return dictRes

    @classmethod
    def GetEventIdSetHasLoc(cls):
        dictEvent = Event.load_data_event()
        res = set()
        for event_id in dictEvent:
            event = dictEvent[event_id]
            if(event.location_id != ""):
                res.add(event_id)
        return res

    @classmethod
    def get_dict_eventId_vec_tfidf(cls, dictEvent, max_features):
        InOut.console_func_begin("get_dict_eventId_vec_tfidf")
        dict_eventid_tfidf = {}
        (listEventid, listEventtext) = Event.get_eventId_eventtext(dictEvent)
        X_tfidf = FeatureExtraction.extract_list_str_tf_idf(listEventtext, max_features)
        for i in xrange(len(listEventid)):
            event_id = listEventid[i]
            v = X_tfidf[i]
            dict_eventid_tfidf[event_id] = v
            #print "event:", event_id
            #print "tfidf:", v
        return dict_eventid_tfidf

    @classmethod
    def get_eventId_eventtext(cls, dictEvent):
        InOut.console_func_begin("get_eventId_eventtext")
        listEventid = []
        listEventtext = []

        cnt = 0
        for event_id in dictEvent:
            event = dictEvent[event_id]
            event_text = event.name + " " + event.description
            listEventid.append(event_id)
            listEventtext.append(event_text)
            cnt += 1
            if(cnt == 1):
                #print "event_id:", event_id
                #print "event_text:", event_text
                pass

        return (listEventid, listEventtext)

    @classmethod
    def comparse_time(cls, event1, event2):
        t1 = event1.get_event_time()
        t2 = event2.get_event_time()
        tOrder = 0
        if(t1 < t2):
            tOrder = -1
        elif (t1 > t2):
            tOrder = 1
        return tOrder

    @classmethod
    def happenBefore(cls, event1, event2):
        flag = False
        tOrder = Event.comparse_time(event1, event2)
        if(tOrder < 0):
            flag = True
        return flag


    def get_event_time(self):
        res= self.time
        return res