
from os.path import *
from Config import *
from Tool import *
from Tool.FileTool.FileTool import *
from Tool.TypeTool.TypeToTool import *
from Tool.TimeTool.TimeTool import *
from FilePro import *

class Tag():
    def __init__(self):
        self.tag_id = ""
        self.name = ""



    def set_value(self, list):
        if(len(list) != Config.file_col_cnt[Config.file_tag]):
            print " set_value error..."
            return
        self.tag_id = list[0]
        self.name = list[1]


    @classmethod
    def get_file(cls):
        file = FilePro.get_file(Config.file_tag)
        return file


    @classmethod
    def load_data_tag(cls):
        InOut.console_func_begin("load_data_tag")
        file = Tag.get_file()
        return Tag.load_data_tag_file(file)

    @classmethod
    def load_data_tag_file(cls, file):
        listlineList = FilePro.load_file_csv(file)

        dictRes = {}
        for listline in listlineList:
            #print ','.join(listline)
            tag = Tag()
            tag.set_value(listline)
            dictRes[tag.tag_id] = tag

        return dictRes