
from os.path import *
from Config import *
from Tool import *
from Tool.FileTool import *
from FilePro import *
from Tool.TimeTool.TimeTool import *

class RSVP():
    def __init__(self):
        self.rsvp_id = ""
        self.created = None
        self.mtime = None
        self.response = ""
        self.user_id = ""
        self.event_id = ""

        pass

    def set_value(self, list):
        if(len(list) != Config.file_col_cnt[Config.file_rsvp]):
            print "set_value error..."
            return
        self.rsvp_id = list[0]
        self.created = TimeTool.get_datetime_or_str(list[1])
        self.mtime = TimeTool.get_datetime_or_str(list[2])
        self.response = list[3]
        self.user_id = list[4]
        self.event_id = list[5]

    @classmethod
    def get_file(cls):
        file = FilePro.get_file(Config.file_rsvp)
        return file

    @classmethod
    def get_file_region(cls):
        file = FilePro.get_file_region(Config.file_rsvp)
        return file

    @classmethod
    def load_data_rsvp(cls):
        InOut.console_func_begin("load_data_rsvp")
        file = RSVP.get_file()

        return RSVP.load_data_file(file)
        pass
    @classmethod
    def load_data_rsvp_region(cls):
        InOut.console_func_begin("load_data_rsvp_region")
        file = RSVP.get_file_region()
        return RSVP.load_data_file(file)
        pass



    @classmethod
    def load_data_file(cls, file):
        InOut.console_func_begin("load_data_file")
        listlineList = FilePro.load_file_csv(file)

        print "listlineList:", len(listlineList)
        dictRes = {}
        for listline in listlineList:
            #print ','.join(listline)
            rsvp = RSVP()
            rsvp.set_value(listline)
            dictRes[rsvp.rsvp_id] = rsvp

        InOut.console_func_end("load_data_file")
        return dictRes

    @classmethod
    def load_data_region_filt_user_event(cls):

        file = FilePro.get_file_region(Config.file_rsvp)
        listlineList = FilePro.load_file_csv(file)

        dictRes = {}
        user_id_set = FilePro.load_region_user_id_set()
        event_id_set = FilePro.load_region_event_id_set()
        for listLine in listlineList:
            rsvp = RSVP()
            rsvp.set_value(listLine)
            if((rsvp.user_id in user_id_set) and (rsvp.event_id in event_id_set)):
                dictRes[rsvp.rsvp_id] = rsvp
        return dictRes

    @classmethod
    def happenBefore(cls, rsvp1, rsvp2):
        flag = False
        tOrder = RSVP.comparse_time(rsvp1, rsvp2)
        if(tOrder < 0):
            flag = True
        return flag

    @classmethod
    def comparse_time(cls, rsvp1, rsvp2):
        t1 = rsvp1.get_rsvp_time()
        t2 = rsvp2.get_rsvp_time()
        tOrder = 0
        if(t1 < t2):
            tOrder = -1
        elif (t1 > t2):
            tOrder = 1
        return tOrder

    def get_rsvp_time(self):
        res= self.created
        return res