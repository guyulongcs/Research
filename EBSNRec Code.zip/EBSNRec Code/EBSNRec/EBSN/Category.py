
from os.path import *
from Config import *
from Tool import *
from Tool.FileTool.FileTool import *
from Tool.TypeTool.TypeToTool import *
from Tool.TimeTool.TimeTool import *
from FilePro import *

class Category():
    def __init__(self):
        self.category_id = ""
        self.name = ""
        self.shortname = ""


    def set_value(self, list):
        if(len(list) != Config.file_col_cnt[Config.file_category]):
            print " set_value error..."
            return
        self.category_id = list[0]
        self.name = list[1]
        self.shortname = list[2]

    @classmethod
    def get_file(cls):
        file = FilePro.get_file(Config.file_category)
        return file


    @classmethod
    def load_data_category(cls):
        InOut.console_func_begin("load_data_category")
        file = Category.get_file()
        return Category.load_data_category_file(file)

    @classmethod
    def load_data_category_file(cls, file):

        listlineList = FilePro.load_file_csv(file)

        dictRes = {}
        for listline in listlineList:
            #print ','.join(listline)
            category = Category()
            category.set_value(listline)
            dictRes[category.category_id] = category

        return dictRes

