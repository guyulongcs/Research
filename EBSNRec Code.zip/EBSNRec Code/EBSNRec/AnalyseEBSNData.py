from EBSN.EBSNData import *
from Tool.MLTool.FeatureExtraction import *
from EBSN.Content import *
class AnalyseEBSNData():
    def __init__(self, ebsnData=None):
        self.ebsnData = ebsnData

    def start(self):
        #self.analyse_event()
        #self.analyse_event_info()
        pass


    @classmethod
    def get_dict_eventid_tfidf(cls, dictEvent, max_features=1000):
        dict_eventid_tfidf = {}
        (listEventid, listEventtext) = AnalyseEBSNData.get_eventid_eventtext(dictEvent)
        X_tfidf = FeatureExtraction.extract_list_str_tf_idf(listEventtext, max_features)
        for i in xrange(len(listEventid)):
            event_id = listEventid[i]
            v = X_tfidf[0]
            dict_eventid_tfidf[event_id] = v
        return dict_eventid_tfidf


    @classmethod
    def get_eventid_eventtext(cls, dictEvent):
        listEventid = []
        listEventtext = []

        cnt = 0
        for event_id in dictEvent:
            event = dictEvent[event_id]
            event_text = event.name + " " + event.description
            listEventid.append(event_id)
            listEventtext.append(event_text)
            cnt += 1
            if(cnt == 1):
                print "event_id:", event_id
                print "event_text:", event_text

        return (listEventid, listEventtext)

    def analyse_event(self):
        (listEventid, listEventtext) = AnalyseEBSNData.get_eventid_eventtext(self.ebsnData)
        print "listEventtext:", len(listEventtext)
        X_tfidf = FeatureExtraction.extract_list_str_tf_idf(listEventtext)
        Content.cal_item_similarity(X_tfidf[0], X_tfidf[1])
        #print X_tfidf
        pass

    def analyse_event_info(self):
        for event_id in self.ebsnData.dictEvent:
            event = self.ebsnData.dictEvent[event_id]
            headCount = event.headCount
            rsvp_limit = event.rsvp_limit
            print "%d\t%d" % (headCount, rsvp_limit)

        pass
