
from PreProcess import *
from GenerateExpData import *
from EventRecommendation import *
from LoadEBSNData import *
from Plot.Plot import *
class Process():
    def __init__(self):
        pass

    def start(self):
        preProcess = PreProcess()
        #preProcess.start()
        #return

        self.process_model()
        #self.plot()

    def process_model(self):
        for region in Config.region_list:
            #if(region == "CHICAGO"):
            #    continue
            print "process region:", region

            Config.file_process_region = region

            generateExpData = GenerateExpData()
            #generateExpData.start()

            eventRec = EventRecommendation()
            eventRec.start()

    def plot(self):
        plot = Plot()
        plot.start()


def __main__():
    process = Process()
    process.start()

__main__()




