from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool.StringTool import *


class SplitData():
    def __init__(self):
        pass

    def start(self):
        InOut.console_func_begin("SplitData")
        #self.filt_user_event_threshold()
        self.SplitDataByRegion()
        pass

    def filt_user_event_threshold(self):
        InOut.console_func_begin("filt_user_event_threshold")
        dictRsvp = RSVP.load_data_rsvp()

        dictUserCnt = {}
        dictEventCnt = {}
        for rsvp_id in dictRsvp:
            rsvp = dictRsvp[rsvp_id]
            if(rsvp.response != "yes"):
                continue
            user_id = rsvp.user_id
            event_id = rsvp.event_id
            TypeProcessTool.dictStrInt_add_key(dictUserCnt, user_id)
            TypeProcessTool.dictStrInt_add_key(dictEventCnt, event_id)

        print "\ndictUserCnt:", len(dictUserCnt)
        print "\ndictEventCnt:", len(dictEventCnt)

        user_id_filt_set = TypeProcessTool.FiltDictStrIntByThreshold(dictUserCnt, Config.p_region_user_rsvp_min_cnt)
        event_id_filt_set = TypeProcessTool.FiltDictStrIntByThreshold(dictEventCnt, Config.p_region_event_rsvp_min_cnt)

        print "user_id_filt_set:", len(user_id_filt_set), "/", len(dictUserCnt)
        print "event_id_filt_set:", len(event_id_filt_set), "/", len(dictEventCnt)

        file_user_id_filt = FilePro.get_file_region_filt_org_name(Config.file_user_id)
        file_event_id_filt = FilePro.get_file_region_filt_org_name(Config.file_event_id)
        FileTool.WriteStrListToFileWithNewLine(list(user_id_filt_set), file_user_id_filt)
        FileTool.WriteStrListToFileWithNewLine(list(event_id_filt_set), file_event_id_filt)

        InOut.console_func_end("filt_user_event_threshold")


    def SplitDataByRegion(self):
        #split by city
        InOut.console_func_begin("SplitDataByRegion")
        for region in Config.region_list:
            print "\n Process region: ", region
            Config.file_process_region = region
            self.SplitDataOfRegion(region)

    def SplitDataOfRegion(self, region):
        InOut.console_func_begin("SplitDataOfRegion")

        #get event set has loc
        event_id_set_has_loc = Event.GetEventIdSetHasLoc()

        #get group set
        filt_group_id_set = self.SplitDataOfRegionGroup(region)

        #get user set
        filt_user_id_set = self.SplitDataOfRegionUser(region, filt_group_id_set)

        #get event set
        filt_event_id_set = self.SplitDataOfRegionGroupEvent(region, filt_group_id_set)
        filt_event_id_set = filt_event_id_set & event_id_set_has_loc

        #filt user set, group set by threshold
        (filt_user_id_set, filt_event_id_set) = self.filt_region_user_event_threshold(region, filt_user_id_set, filt_event_id_set)

        #write region filt user, event
        self.SplitDataByRegionFiltUserEvent(filt_user_id_set, filt_event_id_set)

        #get rsvp
        filt_rsvp_id_set = self.SplitDataOfRegionRsvp(region, filt_user_id_set, filt_event_id_set)

        #get event
        self.SplitDataByRegionEvent(region, filt_event_id_set)

        print "group:", len(filt_group_id_set)
        print "user:", len(filt_user_id_set)
        print "event:", len(filt_event_id_set)
        print "rsvp:", len(filt_rsvp_id_set)

    def SplitDataByRegionFiltUserEvent(self, filt_user_id_set, filt_event_id_set):

        file_user_id_filt = FilePro.get_file_region_filt(Config.file_user_id)
        file_event_id_filt = FilePro.get_file_region_filt(Config.file_event_id)
        FileTool.WriteStrListToFileWithNewLine(list(filt_user_id_set), file_user_id_filt)
        FileTool.WriteStrListToFileWithNewLine(list(filt_event_id_set), file_event_id_filt)


    def filt_region_user_event_threshold(self, region,  filt_user_id_set, filt_event_id_set):
        file = Config.file_rsvp
        fileSrc = self.SplitDataOfRegionGetFileSrcName(region, file)
        fileDst_user_id_filt = FilePro.get_file_region_filt(Config.file_user_id)
        fileDst_event_id_filt = FilePro.get_file_region_filt(Config.file_event_id)

        (filt_user_id_set, filt_event_id_set) = self.filt_user_event_threshold_file(fileSrc, filt_user_id_set, filt_event_id_set, fileDst_user_id_filt, fileDst_event_id_filt)
        return (filt_user_id_set, filt_event_id_set)
        pass

    def SplitDataOfRegionGetFileSrcName(self, region, fileFlag):
        res = fileFlag + Config.file_format
        res = join(Config.folder_data, res)
        return res

    def SplitDataOfRegionGetFileResName(self, region, fileFlag):
        res = region + Config.file_conn + fileFlag + Config.file_format
        res = join(Config.folder_data, Config.folder_City, region, res)
        return res

    def SplitDataOfRegionGroup(self, region):
        InOut.console_func_begin("SplitDataOfRegionGroup")
        dictGroup = Group.load_data_group()
        fileRes = self.SplitDataOfRegionGetFileResName(region, Config.file_group)

        resList = []
        header = self.SplitDataOfRegionGroupParseHeader(Config.file_header[Config.file_group])
        resList.append(header)
        group_id_set = set()
        for group_id in dictGroup:
            group = dictGroup[group_id]
            if(group.region == region):
                group_id_set.add(group_id)
                lineList = group.ToList()
                resList.append(lineList)

        FileTool.WriteFileCSVUseListStringList(fileRes, resList, Config.file_csv_delimiter, Config.file_csv_quotechar)

        return group_id_set
        pass

    def SplitDataOfRegionGroupParseHeader(self, headerLine):
        list = StringTool.SplitStr(headerLine, ',')
        resList = []
        for item in list:
            item = item.replace('"', '')
            resList.append(item)
        return resList

    def SplitDataOfRegionUser(self, region, filt_group_id_set):
        InOut.console_func_begin("SplitDataOfRegionUser")
        filt_id_set = self.SplitDataOfRegionByRegion(region, filt_group_id_set, Config.file_group_user)
        return filt_id_set

        pass

    def SplitDataOfRegionGroupEvent(self, region, filt_group_id_set):
        InOut.console_func_begin("SplitDataOfRegionGroupEvent")
        filt_id_set = self.SplitDataOfRegionByRegion(region, filt_group_id_set, Config.file_group_event)
        return filt_id_set
        pass

    def SplitDataOfRegionByRegion(self, region, filt_group_id_set, file_flag):
        file = file_flag
        srcFile = self.SplitDataOfRegionGetFileSrcName(region, file)
        dstFile = self.SplitDataOfRegionGetFileResName(region, file)
        listLineList = FilePro.load_file_csv(srcFile)

        lineNo = 0
        resList=[]
        header = self.SplitDataOfRegionGroupParseHeader(Config.file_header[file_flag])
        resList.append(header)
        filt_id_set=set()
        for listLine in listLineList:
            lineNo += 1
            # if(lineNo == 1):
            #     resList.append(listLine)
            #     continue
            if(listLine[0] in filt_group_id_set):
                resList.append(listLine)
                filt_id_set.add(listLine[1])


        FilePro.write_file_csv(dstFile, resList)
        return filt_id_set


    def SplitDataOfRegionRsvp(self, region, user_set, event_set):
        InOut.console_func_begin("SplitDataOfRegionRsvp")
        file = Config.file_rsvp
        srcFile = self.SplitDataOfRegionGetFileSrcName(region, file)
        dstFile = self.SplitDataOfRegionGetFileResName(region, file)

        listLineList = FilePro.load_file_csv(srcFile)

        lineNo = 0
        resList=[]
        header = self.SplitDataOfRegionGroupParseHeader(Config.file_header[file])
        resList.append(header)
        filt_id_set=set()
        for listLine in listLineList:
            lineNo += 1
            # if(lineNo == 1):
            #     print listLine
            #     resList.append(listLine)
            #     continue
            if((listLine[4] in user_set) and (listLine[5] in event_set)):
                resList.append(listLine)
                filt_id_set.add(listLine[0])


        FilePro.write_file_csv(dstFile, resList)
        return filt_id_set

        pass

    def SplitDataByRegionEvent(self, region, event_set):
        InOut.console_func_begin("SplitDataByRegionEvent")
        file = Config.file_event
        srcFile = self.SplitDataOfRegionGetFileSrcName(region, file)
        dstFile = self.SplitDataOfRegionGetFileResName(region, file)

        listLineList = FilePro.load_file_csv(srcFile)

        lineNo = 0
        resList=[]
        header = self.SplitDataOfRegionGroupParseHeader(Config.file_header[file])
        resList.append(header)

        for listLine in listLineList:
            lineNo += 1
            # if(lineNo == 1):
            #     resList.append(listLine)
            #     continue
            if((listLine[0] in event_set)):
                resList.append(listLine)

        FilePro.write_file_csv(dstFile, resList)

    def filt_user_event_threshold_file(self, file, filt_user_id_set, filt_event_id_set, fileDstUser, fileDstEvent):
        InOut.console_func_begin("filt_user_event_threshold_file")
        dictRsvp = RSVP.load_data_file(file)

        dictUserCnt = {}
        dictEventCnt = {}
        for rsvp_id in dictRsvp:
            rsvp = dictRsvp[rsvp_id]
            if(rsvp.response != "yes"):
                continue
            user_id = rsvp.user_id
            event_id = rsvp.event_id
            if((user_id not in filt_user_id_set) or (event_id not in filt_event_id_set)):
                continue

            TypeProcessTool.dictStrInt_add_key(dictUserCnt, user_id)
            TypeProcessTool.dictStrInt_add_key(dictEventCnt, event_id)

        print "\ndictUserCnt:", len(dictUserCnt)
        print "\ndictEventCnt:", len(dictEventCnt)

        user_id_filt_set = TypeProcessTool.FiltDictStrIntByThreshold(dictUserCnt, Config.p_region_user_rsvp_min_cnt)
        event_id_filt_set = TypeProcessTool.FiltDictStrIntByThreshold(dictEventCnt, Config.p_region_event_rsvp_min_cnt)

        print "user_id_filt_set:", len(user_id_filt_set), "/", len(dictUserCnt)
        print "event_id_filt_set:", len(event_id_filt_set), "/", len(dictEventCnt)


        return (user_id_filt_set, event_id_filt_set )
        #FileTool.WriteStrListToFileWithNewLine(list(user_id_filt_set), fileDstUser)
        #FileTool.WriteStrListToFileWithNewLine(list(event_id_filt_set), fileDstEvent)

        InOut.console_func_end("filt_user_event_threshold_file")


