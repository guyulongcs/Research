from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from GenerateExpDataLinear.GenerateDataLinear import *
from GenerateExpDataUWeight import *
from EBSN.EBSNData import *
from LoadEBSNData import *
from AnalyseEBSNData import *


from RecSys.Datamodel.data import *

class GenerateExpData():
    def __init__(self):
        self.ebsnData= EBSNData()
        self.data = Data()


    def start(self):
        InOut.console_func_begin("GenerateExpData")

        self.generate_exp_data_region()

    def generate_exp_data_region(self):
        self.init_data()
        #process
        self.load_ebsnData(Config.file_process_region)
        #self.generate_exp_data()
        #self.dump_data()

    def init_data(self):
        self.ebsnData= EBSNData()
        self.data = Data()

    def analyse_ebsnData(self):
        analyseEbsnData = AnalyseEBSNData(self.ebsnData)
        analyseEbsnData.start()

    def load_ebsnData(self, region):
        InOut.console_func_begin("load_ebsnData")
        loadEbsnData = LoadEBSNData(region)
        self.ebsnData = loadEbsnData.load_data()
        self.ebsnData.print_info()

    def generate_exp_data(self):
        InOut.console_func_begin("generate_exp_data")
        self.load_ratingList()
        self.generate_evaluate_data()
        self.generate_model_data()

    def dump_data(self):
        dataDump = self.data.get_dump_data()
        file_exp_recommend = FilePro.get_file_region(Config.file_exp_recommend)
        data={}
        data["dataDump"] = dataDump
        FileTool.DumpData(file_exp_recommend, data)

    def dump_data_user_weight(self):
        dataDump = self.data.get_dump_data_user_weight()
        file_exp_userWeight = FilePro.get_file_region(Config.file_exp_userWeight)
        data = {}
        data["dataDump"] = dataDump
        FileTool.DumpData(file_exp_userWeight, data)


    def load_ratingList(self):
        #load ratingList, user_id_set, event_id_set
        InOut.console_func_begin("generate_user_event_matrix")
        dictRsvp = RSVP.load_data_region_filt_user_event()

        #ratingList
        yesCnt = 0
        noCnt = 0
        rating = 0
        ratingList = []
        for rsvp_id in dictRsvp:
            rsvp = dictRsvp[rsvp_id]
            if(rsvp.response != "yes"):
                noCnt += 1
                rating = -1
                #continue
            else:
                yesCnt += 1
                rating = 1

            user_id = rsvp.user_id
            event_id = rsvp.event_id

            item = [user_id, event_id, rating]
            #print "item:"
            #print "user_id:%s, event_id:%s, rating:%d" % (user_id, event_id, rating)
            #item = Rating(user_id, event_id, rating)
            ratingList.append(item)


        #
        print "yesCnt:", yesCnt
        print "noCnt:", noCnt
        print "ratingList:", len(ratingList)


        #set result
        self.data._ratingList_init = ratingList
        #set
        self.data._userSet = FilePro.load_region_user_id_set()
        self.data._itemSet = FilePro.load_region_event_id_set()


    def generate_evaluate_data(self):
        #generate R_Init, train_validation_test
        self.data.generate_evaluate_data(Config.flag_filt_R_not_positive, Config.p_ml_split_ratio["train"], Config.p_ml_split_ratio["validation"])
        pass

    def generate_user_event_matrix(self):
        InOut.console_func_begin("generate_user_event_matrix")
        dictRsvp = RSVP.load_data_region_filt_user_event()

        #matrix
        yesCnt = 0
        noCnt = 0
        rating = 0
        resList = []
        for rsvp_id in dictRsvp:
            rsvp = dictRsvp[rsvp_id]
            if(rsvp.response != "yes"):
                noCnt += 1
                rating = -1
                #continue
            else:
                yesCnt += 1
                rating = 1

            user_id = rsvp.user_id
            event_id = rsvp.event_id

            #item = [user_id, event_id, rating]
            item = Rating(user_id, event_id, rating)
            resList.append(item)

        #set
        user_id_set = FilePro.load_region_user_id_set()
        event_id_set = FilePro.load_region_event_id_set()

        #
        print "yesCnt:", yesCnt
        print "noCnt:", noCnt
        print "resListCnt:", len(resList)

        #build matrix
        #rsvpMatrix = SparseMatrix.CreateSparseMatrix(resList, user_id_set, event_id_set)

        #print "Matrix nnz:", rsvpMatrix.nnz


        file_exp_rsvp = FilePro.get_file_region(Config.file_exp_rsvp)

        data = {}
        data["ratingList"] = resList
        data["rowSet"] = user_id_set
        data["colSet"] = event_id_set
        FileTool.DumpData(file_exp_rsvp, data)

        #np.save(file_exp_rsvp, rsvpMatrix)

        #SparseMatrixTool.MatrixFactorization(rsvpMatrix)

        pass

    def generate_model_data(self):
        #self.ebsnData = self.generate_model_data_linear_prepare(self.ebsnData)
        self.data.printInfo()
        self.generate_model_data_UserWeight(self.data, self.ebsnData)
        self.generate_model_data_linear(self.data, self.ebsnData)


    def generate_model_data_UserWeight(self, data, ebsnData):
        self.generate_model_data_UWeight(self.data, self.ebsnData)
        self.data.norm_exp_data_user_weight()

    def generate_model_data_linear(self, data, ebsnData):
        generateExpDataLinear = GenerateExpDataLinear(data, ebsnData)
        dict_linear_feature =  generateExpDataLinear.generate_data_linear()
        self.data._dict_user_event_featureList = dict_linear_feature
        self.data.printInfo()

    def generate_model_data_UWeight(self, data, ebsnData):
        generateExpDataUWeight = GenerateExpDataUWeight(data, ebsnData)
        generateExpDataUWeight.generate_user_weight()
        self.data._dict_user_user_weight_on =  generateExpDataUWeight._dict_user_user_weight_on
        self.data._dict_user_user_weight_off = generateExpDataUWeight._dict_user_user_weight_off

        self.data._dict_user_user_sameGroupCnt = generateExpDataUWeight._dict_user_user_sameGroupCnt
        self.data._dict_user_user_sameEventCnt = generateExpDataUWeight._dict_user_user_sameEventCnt

        self.data.printInfo()



