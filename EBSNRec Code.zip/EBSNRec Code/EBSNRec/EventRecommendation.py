from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from EBSN.FilePro import *
from Tool.StringTool import *
from Tool.MatrixTool import *
from Tool.FileTool.FileTool import *
from Tool.TimeTool.TimeTool import *
from RecSys.Recommend.RecommendMF import *
from RecSys.Recommend.RecommendMFLinear import *
from RecSys.Recommend.RecommendBMF import *
from RecSys.Recommend.RecommendBPRMFLinear import *
from RecSys.Datamodel.data import *
from GenerateExpDataLinear.GenerateDataLinear import *

class EventRecommendation():
    def __init__(self):
        #self.rsvpMatrix = None
        self._data = Data()
        self.log = []
        self.log_detail = []
        pass

    def start(self):
        InOut.console_func_begin("EventRecommendation")
        self.event_rec_region()

    def event_rec_region(self ):
        self.add_log_info()
        self.write_log()


        self.load_exp_data()

        self.recommendation()



        pass

    def clear_log(self):
        self.log = []
        self.log_detail = []

    def add_log_info(self):
        timeNow = TimeTool.get_time_now_str()
        s = "\n>>>>>>>>>>>>>>>>>>Log Time: " + timeNow

        strList = []
        strList.append(s)
        strList.append("\nEventRecommendation")
        s = "iteration: " + str(Config.p_mf_iteration_number)
        strList.append(s)
        s = "mf iteration: " + str(Config.p_mf_base_iteration_number)
        strList.append(s)
        s = "camf components: " + str(Config.p_mf_components)
        strList.append(s)

        self.log.extend(strList)
        self.log_detail.extend(strList)




    def load_exp_data(self):
        InOut.console_func_begin("load_exp_data")
        self.load_exp_data_recommend()

        #self.load_exp_data_update_user_weight()
        self.norm_exp_data()


        self.print_data()

        InOut.console_func_end("load_exp_data")


    def load_exp_data_recommend(self):
        InOut.console_func_begin("load_exp_data_recommend")
        #file = FilePro.get_file_region(Config.file_exp_rsvp)
        file = FilePro.get_file_region(Config.file_exp_recommend)
        #file = file + Config.file_np_format
        #print "file:", file
        #print "end"

        data = FileTool.LoadDumpData(file)
        self._data = data["dataDump"]
        InOut.console_func_end("load_exp_data_recommend")

    def load_exp_data_update_user_weight(self):
        InOut.console_func_begin("load_exp_data_update_user_weight")
        #file = FilePro.get_file_region(Config.file_exp_rsvp)
        file = FilePro.get_file_region(Config.file_exp_userWeight)


        data = FileTool.LoadDumpData(file)
        dataDump = data["dataDump"]
        self._data._dict_user_user_weight_on = dataDump._dict_user_user_weight_on
        self._data._dict_user_user_weight_off = dataDump._dict_user_user_weight_off
        self._data._user_weight = dataDump._user_weight

    def recommendation(self):
        if(Config.flag_method_mf):
            self.recommend_MF()

        if(Config.flag_method_mfLinear):
            if(Config.flag_mflinear_para_list):
                self.recommend_MFLinear_list()
            else:
                self.recommend_MFLinear()

        if(Config.flag_method_mfLinear_singLinearFeature):
            self.recommend_MFLinear_singLinearFeature()


        if(Config.flag_method_bmf):
            self.recommend_BMF()

        if(Config.flag_method_bmfLinear):
            if(Config.flag_mflinear_para_list):
                self.recommend_BPRMFLinear_list()
            else:
                self.recommend_BPRMFLinear()

        if(Config.flag_method_linear):
            self.recommend_Linear()

        if(Config.flag_method_mdm15):
            self.recommend_mdm15()

        if(Config.flag_method_recsys15):
            self.recommend_recsys15()

        if(Config.flag_method_bmfLinear_singLinearFeature):
            self.recommend_BMFLinear_singLinearFeature()





    def write_log(self):
        self.write_log_log()
        self.write_log_detail()
        self.clear_log()


    def write_log_log(self):
        file_log = FilePro.get_file_region(Config.file_log)
        FileTool.WriteStrListToFileWithNewLine(self.log, file_log, True)

    def write_log_detail(self):
        file_log_detail = FilePro.get_file_region(Config.file_log_detail)
        FileTool.WriteStrListToFileWithNewLine(self.log_detail, file_log_detail, True)


    def write_log_with_data(self, log):
        file_log = FilePro.get_file_region(Config.file_log)
        FileTool.WriteStrListToFileWithNewLine(log, file_log, True)

    def write_log_detail_with_data(self, log):
        file_log_detail = FilePro.get_file_region(Config.file_log_detail)
        FileTool.WriteStrListToFileWithNewLine(log, file_log_detail, True)

    def recommend_Linear(self):
        Config.p_mflinear_w_mf = 0
        Config.p_mflinear_w_linear = 1
        self.recommend_MFLinear()

    def recommend_mdm15(self):
        print "recommend_mdm15"
        self.log_info_append("\n>>>>recommend_mdm15")
        typeList = Config.p_linear_type_list_MDM15
        self.set_data_type_list(typeList)
        #return

        self.recommend_Linear()
        self.reset_data_type_list()

        pass

    def recommend_recsys15(self):
        self.log_info_append("\n>>>>recommend_recsys15")
        typeList = Config.p_linear_type_list_Recsys15
        self.set_data_type_list(typeList)

        #return
        self.recommend_Linear()
        self.reset_data_type_list()
        pass

    def set_data_type_list(self, typeList):

        self._data._R_linear_valid_index_list = DataLinear.get_linear_valid_index_list(typeList)
        print "self._data._R_linear_valid_index_list:", self._data._R_linear_valid_index_list


    def reset_data_type_list(self):
        self._data._R_linear_valid_index_list = []

    def recommend_MFLinear_list(self):
        for w_mf in Config.w_mf_list:
            Config.p_mflinear_w_mf = w_mf
            Config.p_mflinear_w_linear = 1 - w_mf
            print "w_mf:", Config.p_mflinear_w_mf
            print "w_linear:", Config.p_mflinear_w_linear
            self.recommend_MFLinear()


    def recommend_BPRMFLinear_list(self):
        for w_mf in Config.w_mf_list:
            Config.p_mflinear_w_mf = w_mf
            Config.p_mflinear_w_linear = 1 - w_mf
            print "w_mf:", Config.p_mflinear_w_mf
            print "w_linear:", Config.p_mflinear_w_linear
            self.recommend_BPRMFLinear()

    def recommend_MFLinear_singLinearFeature(self):
        w_mf = Config.w_mf_singFeature[0]
        Config.p_mflinear_w_mf = w_mf
        Config.p_mflinear_w_linear = 1 - w_mf


        for type in Config.p_linear_feature_type_list:
            self.recommend_MFLinear_singLinearFeature_singleType(type)
            #break

    def recommend_BMFLinear_singLinearFeature(self):
        w_mf = Config.w_bmf_singFeature[0]
        Config.p_mflinear_w_mf = w_mf
        Config.p_mflinear_w_linear = 1 - w_mf

        for type in Config.p_linear_feature_type_list:
            self.recommend_BMFLinear_singLinearFeature_singleType(type)
            # break





    def recommend_MFLinear_singLinearFeature_singleType(self, type):
        str = "\n>>>>recommend_MFLinear_singLinearFeature"
        self.log_info_append(str)
        print str

        str = "type:%s" % type
        self.log_info_append(str)
        print str

        typeList = [type]
        self.set_data_type_list(typeList)

        #return
        self.recommend_MFLinear()
        self.reset_data_type_list()

    def recommend_BMFLinear_singLinearFeature_singleType(self, type):
        str = "\n>>>>recommend_BMFLinear_singLinearFeature_singleType"
        self.log_info_append(str)
        print str

        str = "type:%s" % type
        self.log_info_append(str)
        print str

        typeList = [type]
        self.set_data_type_list(typeList)

        # return
        self.recommend_BPRMFLinear()
        self.reset_data_type_list()


    def recommend_MF(self):
        self.recommend_MF = RecommendMF()
        self.recommend_MF.evaluate_model(self._data)

        recLog = self.recommend_MF.get_log()
        recLogDetail = self.recommend_MF.get_log_detail()
        self.add_rec_log(recLog , recLogDetail)


    def recommend_BMF(self):
        self.recommend_BMF = RecommendBMF()
        self.recommend_BMF.evaluate_model(self._data)

        recLog = self.recommend_BMF.get_log()
        recLogDetail = self.recommend_BMF.get_log_detail()

        InOut.printDebug()
        print "recLog:", recLog
        print "recLogDetail:", recLogDetail
        self.add_rec_log(recLog , recLogDetail)

    def recommend_BPRMFLinear(self):
        InOut.console_func_begin("recommend_BPRMFLinear")
        self._recommend_BPRMFLinear = RecommendBPRMFLinear()
        self._recommend_BPRMFLinear.evaluate_model(self._data)

        recLog = self._recommend_BPRMFLinear.get_log()
        recLogDetail = self._recommend_BPRMFLinear.get_log_detail()

        InOut.printDebug()
        print "recLog:", recLog
        print "recLogDetail:", recLogDetail
        self.add_rec_log(recLog , recLogDetail)


    def recommend_MFLinear(self):
        self._recommend_MFLinear = RecommendMFLinear()
        self._recommend_MFLinear.evaluate_model(self._data)

        recLog = self._recommend_MFLinear.get_log()
        recLogDetail = self._recommend_MFLinear.get_log_detail()
        self.add_rec_log(recLog , recLogDetail)

    def add_rec_log(self, recLog, recLogDetail):
        self.log.extend(recLog)
        self.write_log_with_data(self.log)

        self.log_detail.extend(recLogDetail)
        self.write_log_detail_with_data(self.log_detail)

        self.clear_log()



        #recommend.RecTest(self._data)

    def norm_exp_data(self):
        InOut.console_func_begin("norm_exp_data")
        self._data.norm_exp_data_linear()

        self._data._R_linear_valid_index_list = []
        self._data._user_weight = None
        if(Config.p_mf_user_reg):
            self._data.norm_exp_data_user_weight()


        InOut.console_func_end("norm_exp_data")
        pass

    def print_data(self):
        self._data.printInfo()
        #self._data.print_dict_user_event_featureList()
        #self._data.printRLinear()
        #self._data.print_dict_user_user_weight_on()
        #self._data.print_dict_user_user_weight_off()


    def log_info_append(self, str):
        print "log_info_append"
        print str
        self.log.append(str)
        self.log_detail.append(str)

    def log_info_extend(self, strList):
        self.log.extend(strList)
        self.log_detail.extend(strList)

