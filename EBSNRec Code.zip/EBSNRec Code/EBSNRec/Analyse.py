
from EBSN.Group import *
from EBSN.User import *
from EBSN.RSVP import *
from EBSN.Event import *
from Tool.TypeTool.TypeProcessTool import *

class Analyse():
    def __init__(self):
        pass

    def start(self):
        InOut.console_func_begin("Analyse")
        self.analyse_group()
        self.analyse_user()
        self.analyse_rsvp()
        self.analyse_event()
        pass

    def analyse_group_(self):
        InOut.console_func_begin("analyse_group")
        print "dictRegionCnt:"
        dictGroup = Group.load_data_group()

        dictRegionCnt = {}

        for group_id in dictGroup:
            group = dictGroup[group_id]
            TypeProcessTool.dictStrInt_add_key(dictRegionCnt, group.region)

        InOut.console_print_dict_str_str(dictRegionCnt)

    def analyse_group(self):
        InOut.console_func_begin("analyse_group")
        print "dictRegionCnt:"
        fileGroup = Group.get_file()
        dict = FilePro.analyse_file_csv(fileGroup, Config.file_group_col_region)
        InOut.console_print_dict_str_str(dict)


    def analyse_user(self):
        InOut.console_func_begin("analyse_user")
        print "dictCityCnt:"
        dict = User.load_data_user()
        dictColCnt = {}
        for id in dict:
            item = dict[id]
            TypeProcessTool.dictStrInt_add_key(dictColCnt, item.city)

        InOut.console_print_dict_str_str(dictColCnt)

    def analyse_rsvp(self):
        InOut.console_func_begin("analyse_rsvp")

        file = RSVP.get_file()
        self.analyse_rsvp_response(file)
        self.analyse_rsvp_user_event(file)

    def analyse_rsvp_response(self, file):
        print "\ndictResponseCnt:"
        dict = FilePro.analyse_file_csv(file, Config.file_rsvp_col_response)
        InOut.console_print_dict_str_str(dict)

    def analyse_rsvp_user_event(self, file):
        InOut.console_func_begin("analyse_rsvp_user_event")
        dictRsvp = RSVP.load_data_rsvp()

        dictUserCnt = {}
        dictEventCnt = {}
        for rsvp_id in dictRsvp:
            rsvp = dictRsvp[rsvp_id]
            if(rsvp.response != "yes"):
                continue
            user_id = rsvp.user_id
            event_id = rsvp.event_id
            TypeProcessTool.dictStrInt_add_key(dictUserCnt, user_id)
            TypeProcessTool.dictStrInt_add_key(dictEventCnt, event_id)

        print "dictUserCnt:", len(dictUserCnt)





    def analyse_event(self):
        InOut.console_func_begin("analyse_event")
        dictEvent = Event.load_data_event()

        locIdEmptyCnt = 0
        totalCnt = len(dictEvent)
        for event_id in dictEvent:
            if(dictEvent[event_id].location_id == ""):
                locIdEmptyCnt += 1
        print "locIdEmptyCnt:" + str(locIdEmptyCnt) + "/" + str(totalCnt)


