import numpy as np
class Config():
    folder_base = "/Volumes/T"
    #folder_base = '/home/gyl'
    folder_data = folder_base + "/Data/dataset/EBSN/MeetupRec/collection_april_14/"

    folder_parsed = "Parsed/"
    folder_City = "City/"

    folder_Pic = "Pic/"

    file_conn = "_"
    file_format = ".csv"

    file_event = "events"
    file_rsvp = "rsvps"
    file_user = "users"
    file_group = "groups"

    file_group_user = "group_users"
    file_group_event = "group_events"

    file_group_tag = "group_tags"

    file_location = "locations"

    file_category = "categories"
    file_tag = "tags"
    file_filt = "filt"


    #file_list_range = {file_event: 24, file_rsvp:17, file_user: 7, file_rsvp:6}

    file_col_cnt = {file_user:7, file_group: 14, file_event:14, file_rsvp:6, file_location:9, file_category:3, file_tag:2}

    file_skip_count = 1
    file_split_char = ","

    file_csv_delimiter = ','
    file_csv_quotechar= '"'

    file_group_col_region = 13
    file_rsvp_col_response = 3


    file_header = {
        file_user: '"user_id","name","city","country","latitude","longitude","joined"',
        file_group: '"group_id","name","urlname","created","city","country","join_mode","visibility","latitude","longitude","users","category_id","organizer_id","region"',
        file_event: '"event_id","name","event_url","description","fee_price","created","time","utc_offset","status","visibility","headCount","rsvp_limit","location_id","group_id"',
        file_group_event: '"group_id","event_id"',
        file_group_user: '"group_id","user_id"',
        file_rsvp: '"rsvp_id","created","mtime","response","user_id","event_id"',
    }


    timestamp_timezone = "America/Chicago"

    timestampe_fileList = [file_event, file_user, file_group, file_rsvp]



    flag_process_region = True
    file_process_region = ""

    p_region_user_rsvp_min_cnt = 20
    p_region_event_rsvp_min_cnt = 20

    file_user_id = "user_id"
    file_event_id = "event_id"

    file_exp_rsvp = "exp_rsvp"

    file_exp_recommend = "recommend"
    file_exp_userWeight = "userWeight"

    file_np_format = ".npy"

    file_log = "log"
    file_log_detail = "log_detail"

    flag_filt_R_not_positive = True

    batch_size = 100

    p_ml_split_ratio ={"train": 0.6, "validation":0.2, "test": 0.2}

    p_linear_content_tfidf_wordscnt = 2000
    p_linear_group_same_group_weigtht = 0.5
    p_linear_event_similar_content_threshold = 0.01

    p_linear_feature_type_list = ["user", "time", "location", "content", "event", "group", "social"]


    p_linear_type_list_MDM15 = ["user", "time", "location"]
    p_linear_type_list_Recsys15 = ["user", "time", "location", "content"]


    #mf func
    p_mf_func_list = ["None", "Sigmoid"]
    p_mf_func = p_mf_func_list[0]

    #linear func
    p_linear_linear_func_list = ['None', 'Linear', 'Sigmoid']
    p_linear_linear_func = p_linear_linear_func_list[2]

    #feature
    p_linear_location_norm_method_list = ['None', 'Linear', 'Exp']
    p_linear_location_norm_method = p_linear_location_norm_method_list[0]
    p_linear_location_norm_method_linear_num = 10
    p_linear_location_norm_method_exp_num = 2
    p_linear_event_sim_thres = 0.4

    #para
    w_mf = [.5, 0.5]
    #w_mf = [0, 1.]
    #w_mf = [1, 0.]
    #w_mf = [.8, 0.2]
    w_mf_list = np.arange(0,1.1,0.2)
    w_mf_list = [0, 0.2, 0.5, 0.8, 1]
    w_mf_list = [.2]
    flag_mflinear_para_list = True

    p_mflinear_w_mf = w_mf[0]
    p_mflinear_w_linear = w_mf[1]





    p_mf_base_iteration_number = 20
    p_mf_components = 400

    #alpha
    p_mf_alpha = 0.1

    #lamda
    p_mf_lamda_u = 0.01
    p_mf_lamda_v = 0.01
    p_mf_lamda_theta = 0.01

    p_mf_user_reg = False
    p_mf_lamda_user_reg = 0.01

    p_mf_user_weight_set_join_group_threshold = 10
    p_mf_user_weight_set_join_event_threshold = 10

    p_linear_user_weight_set_join_group_threshold = 1
    p_linear_user_weight_set_join_event_threshold = 1

    p_mf_user_weight_on = 0.5

    p_mf_train_only_positive = False

    flag_method_mf = False
    flag_method_mfLinear = True
    flag_method_bmf = False
    flag_method_linear = False
    flag_method_bmfLinear = False

    flag_method_mdm15 = False
    flag_method_recsys15 = False

    flag_method_mfLinear_singLinearFeature = False

    flag_method_bmfLinear_singLinearFeature = False

    w_mf_singFeature = [.2, 0.8]
    w_bmf_singFeature = [.1, .9]



    region_list = [ "CHICAGO",  "SAN JOSE", "PHOENIX"]

    region_list = ["PHOENIX"]

    #iteration
    p_mf_iteration_number = 500
    BPR_sample_PosNegCol_MaxCnt = 20


    p_linear_feature_dictTypeCnt = {
        "user": 3, "time": 1, "location": 2, "content":1, "event": 3, "group": 1, "social": 2
    }
    #p_linear_feature_type_list = ["social"]
    p_linear_feature_type_list = ["user"]

