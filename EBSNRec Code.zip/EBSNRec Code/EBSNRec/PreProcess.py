from Config import *

import os
from os.path import *

from Tool.FileTool import *
from Analyse import *

from Tool.TimeTool import *
from SplitData import *
import pytz

class PreProcess():
    def __init__(self):

        pass

    def start(self):
        InOut.console_func_begin("PreProcess")

        #self.test()
        #pass


        #self.merge_org_files()
        #self.parse_timestamp()
        #return

        analyse = Analyse()
        analyse.start()
        return


        splitData = SplitData()
        splitData.start()

        InOut.console_func_end("PreProcess")

    def test(self):
        t = "1372803549"

        dt = TimeTool.get_datetimestr_from_timestamp(t, Config.timestamp_timezone)
        print dt
        pass

    def merge_org_files(self):
        InOut.console_func_begin("merge_org_files")
        self.merge_org_files_type(Config.file_event)
        self.merge_org_files_type(Config.file_rsvp)
        self.merge_org_files_type(Config.file_user)
        InOut.console_func_end("merge_org_files")

    def parse_timestamp(self):
        InOut.console_func_begin("parse_timestamp")
        #self.parse_timestamp_parse()
        self.parse_timestamp_copy_files()
        InOut.console_func_end("parse_timestamp")

    def parse_timestamp_parse(self):
        self.parse_timestamp_type(Config.file_user, [6])
        self.parse_timestamp_type(Config.file_group, [3])
        self.parse_timestamp_type(Config.file_event, [5,6])
        self.parse_timestamp_type(Config.file_rsvp, [1,2])

    def parse_timestamp_copy_files(self):
        for file in Config.timestampe_fileList:
            self.parse_timestamp_copy_file(file)



    def parse_timestamp_copy_file(self, file):
        file = file + Config.file_format
        FileTool.CopyFile(join(Config.folder_data, Config.folder_parsed, file), join(Config.folder_data, file))

        pass

    def merge_org_files_type(self, file):
        resList = []
        file_res = join(Config.folder_data, file + Config.file_format)
        file_list_range = Config.file_list_range[file]
        for file_id in range(1, file_list_range + 1):
            file_name = join(Config.folder_data, file + Config.file_conn + str(file_id) + Config.file_format)
            skipLineCnt = 1
            if(file_id == 1):
                skipLineCnt = 0
            lineList = FileTool.ReadStrListFromFile(file_name, skipLineCnt)
            resList.extend(lineList)

        FileTool.WriteStrListToFileWithNewLine(resList, file_res)

    def parse_timestamp_type(self, file, colTimestampList):
        InOut.console_func_begin("parse_timestamp_type" + file)
        fileSrc = join(Config.folder_data, file + Config.file_format)
        fileDst = join(Config.folder_data, Config.folder_parsed, file + Config.file_format)
        FileTool.ParseFileCSVTimeStamp(fileSrc, colTimestampList, Config.timestamp_timezone, fileDst, Config.file_skip_count, Config.file_csv_delimiter, Config.file_csv_quotechar)


