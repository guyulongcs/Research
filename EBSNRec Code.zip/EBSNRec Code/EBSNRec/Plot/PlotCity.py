import gmplot

from Tool.PlotTool.GeoPlot.gmplot.gmplot import *
from Config import *
from os.path import *


from Tool.InOutTool.InOutTool import *
from Tool.TypeTool.TypeProcessTool import *

from LoadEBSNData import *
from EBSN.Event import *
from EBSN.Location import *


class PlotCity():
    def __init__(self):
        self.path = '/Users/guyulong/Documents/'
        self.fileName = 'map.html'

        self.region =  "SAN JOSE"
        self.dictRegion = {
            "SAN JOSE": [37.339, -121.894],
            "CHICAGO": [41.836944, -87.684722],
            "PHOENIX": [33.45, -112.066667]
        }
        pass

    def start(self):
        self.region = "PHOENIX"
        file = join(self.path, self.fileName)
        (eventLatList, eventLonList) = self.get_event_plot_list()

        #GoogleMapPlotter.demo(file)
        #return


        (lat, lon) = self.dictRegion[self.region]
        mymap = GoogleMapPlotter(lat, lon, 11.5)
        #mymap = GoogleMapPlotter.from_geocode(self.region, 11.5)

        #
        # latList = []
        # lonList = []
        # for cityId in self.dictCity:
        #     city = self.dictCity[cityId]
        #     lat = city.lat
        #     lon = city.lon
        #     latList.append(lat)
        #     lonList.append(lon)
        #
        #     #mymap.marker(lat, lon, "green")
        #     mymap.circle(lat, lon, 20000, "b", ew=2)
            #mymap.polygon(path3[0], path3[1], edge_color="cyan", edge_width=5, face_color="blue", face_alpha=0.1)

        #mymap.heatmap(latList, lonList, threshold=10, radius=20)


            #Blue
        gradient1 = [
    'rgba(0, 255, 255, 0)',
    'rgba(0, 255, 255, 1)',
    'rgba(0, 225, 255, 1)',
    'rgba(0, 200, 255, 1)',
    'rgba(0, 175, 255, 1)',
    'rgba(0, 160, 255, 1)',
    'rgba(0, 145, 223, 1)',
    'rgba(0, 125, 191, 1)',
    'rgba(0, 110, 255, 1)',
    'rgba(0, 100, 255, 1)',
    'rgba(0, 75, 255, 1)',
    'rgba(0, 50, 255, 1)',
    'rgba(0, 25, 255, 1)',
    'rgba(0, 0, 255, 1)'
        ]

        #// Red - negative
        gradient2 = [
            'rgba(255, 255, 0, 0)',
            'rgba(255, 255, 0, 1)',
            'rgba(255, 225, 0, 1)',
            'rgba(255, 200, 0, 1)',
            'rgba(255, 175, 0, 1)',
            'rgba(255, 160, 0, 1)',
            'rgba(255, 145, 0, 1)',
            'rgba(255, 125, 0, 1)',
            'rgba(255, 110, 0, 1)',
            'rgba(255, 100, 0, 1)',
            'rgba(255, 75, 0, 1)',
            'rgba(255, 50, 0, 1)',
            'rgba(255, 25, 0, 1)',
            'rgba(255, 0, 0, 1)'
        ]

        mymap.heatmap(eventLatList, eventLonList, gradient = gradient1, radius=50, opacity=2)

        #mymap.heatmap(latList, lonList, threshold=10, radius=20)
       # mymap.scatter(latList, lonList, c='r', marker=True)





        #mymap.marker(37.427, -122.145, "yellow")

        mymap.draw(file)
        pass

    def load_event_loc_list(self, region):
        InOut.console_func_begin("load_event_loc_list")
        loadESBNData = LoadEBSNData()

        #region = None
        locList = loadESBNData.load_event_loc_list(region)


        print "locList:", len(locList)

        sampleLocList = locList
        sampleLocList = TypeProcessTool.sampleListByRatio(sampleLocList, 1)
        print "sampleLocList:", len(sampleLocList)


        return sampleLocList

    def get_event_plot_list(self):
        InOut.console_func_begin("get_check_in_plot_list")
        locList = self.load_event_loc_list(self.region)
        latList = []
        lonList = []
        for loc in locList:
            latList.append(loc.latitude)
            lonList.append(loc.longitude)
        print "len:", len(latList), len(lonList)
        return (latList, lonList)




def __main__():
    pl = PlotCity()
    pl.start()