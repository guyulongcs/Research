from Tool.PlotTool.Plotbar import *
from Tool.PlotTool.Plotcdf import *
from Tool.PlotTool.PlotLine import *
from os.path import join
from Config import *

import matplotlib.pyplot as plt

from matplotlib.backends.backend_pdf import PdfPages

from Tool.PlotTool.GeoPlot.gmplot.gmplot import *


class PlotExpRes():
    def __init__(self):
        self.folder = join(Config.folder_data, Config.folder_Pic)
        pass

    def start(self):
        self.plot_acc()
        self.plot_acc_alpha()

        self.plot_acc_context()

        self.plot_precision()

        self.plot_recall()

        self.plot_f1()

        self.plot_auc()

    def plot_acc(self):
        #self.plot_acc_alphamf()
        self.plot_acc_CAMF()

    def plot_auc(self):
        #self.plot_acc_alphamf()
        self.plot_auc_CAMF()

    def plot_acc_alphamf(self):
        self.plot_acc_models()

        pass

    def plot_precision(self):
        #self.plot_precision_models()
        self.plot_precision_models_CAMF()

    def plot_recall(self):
        self.plot_recall_models_CAMF()

    def plot_f1(self):
        self.plot_f1_models_CAMF()

    def plot_acc_CAMF(self):
        self.plot_acc_models_CAMF()

        pass

    def plot_auc_CAMF(self):
        self.plot_auc_models_CAMF()



    def plot_acc_models(self):
        self.plot_acc_models_CHICAGO()
        self.plot_acc_models_PHOENIX()
        self.plot_acc_models_SANJOSE()

        self.plot_acc_models_merge()

    def plot_acc_models_CAMF(self):
        #self.plot_acc_models_CAMF_CHICAGO()
        #self.plot_acc_models_CAMF_PHOENIX()
        #self.plot_acc_models_CAMF_SANJOSE()

        self.plot_acc_models_CAMF_merge()

    def plot_auc_models_CAMF(self):
        self.plot_auc_models_CAMF_merge()



    def plot_acc_alpha(self):
        self.plot_acc_alpha_alphamf()
        self.plot_acc_alpha_CAMF()

    def plot_acc_alpha_alphamf(self):
        x = [0, 0.2, 0.5, 0.8, 1]
        yList = ["CHICAGO", "PHOENIX", "SAN JOSE"]
        y1 = [78, 80.9, 77.3, 74.3, 73.1]
        y2 = [80.6, 83, 79.7, 77.5, 76.5]
        y3 = [83.8, 84.7, 81.9, 77.6, 75.4]
        xaxis = [0, 1, 0.1]
        yaxis = [70, 90, 5]

        title = "Influence of the relative weight $\\alpha$ on the CAMF model"
        fileName =  "accAlphaCAMF.pdf"

        yValueList = [y1, y2, y3]


        plotLine = PlotLine()
        plotLine.x = x
        plotLine.xaxis = xaxis
        plotLine.yaxis = yaxis
        plotLine.title = title

        plotLine.linewidth = 4

        plotLine.xlabel = "$\\alpha$"
        plotLine.ylabel = "ACC(%)"
        plotLine.grid=True

        plotLine.file = join(self.folder, fileName)



        #plot
        plotLine.y = y1
        ymin = plotLine.yaxis[0]
        ymax = plotLine.yaxis[1]
        ytick = plotLine.yaxis[2]
        yt=np.arange(ymin, ymax, ytick)



        pp = PdfPages(plotLine.file)
        plt.figure(1)
        plt.grid(plotLine.grid)


        #line1= plotLine.plot_line_help(plt, x, y1, 'ro-', label = "Line1")

        #plotLine.plot_line_help(plt, x, y2,  'bs:', 'red')
        #plotLine.plot_line_help(plt, x, y3,  'g^--',  'red')


        line1, = plt.plot(plotLine.x, y1, 'ro-', label = "Line1", lw=plotLine.linewidth, alpha = plotLine.alpha)
        line2, = plt.plot(plotLine.x, y2, 'bs:', label = "Line2", lw=plotLine.linewidth, alpha = plotLine.alpha)
        line3, = plt.plot(plotLine.x, y3, 'g^--', label = "Line3", lw=plotLine.linewidth, alpha = plotLine.alpha)

        plt.legend([line1, line2, line3], yList)

        #plt.plot(plotLine.x, y2, ls='bs:', lw=plotLine.linewidth, alpha = plotLine.alpha)
        #plt.plot(plotLine.x, y3, ls='g^--', lw=plotLine.linewidth, alpha = plotLine.alpha)

        plt.title(plotLine.title)
        plt.ylabel(plotLine.ylabel)
        plt.ylim(ymin,ymax)
        plt.xlabel(plotLine.xlabel)

        plt.yticks(yt)
        pp.savefig()
        pp.close()
        plt.close()

    def plot_acc_alpha_CAMF(self):
        x = [0, 0.1, 0.2, 0.5, 0.8, 1]
        yList = ["CHICAGO", "PHOENIX", "SAN JOSE"]
        y1 = [74.5, 75.3, 73.1, 69.8, 68.8, 68.8]
        y2 = [77.6, 78.3, 75.4, 70.7, 70.8, 70.6]
        y3 = [77.2, 80.1, 75.7, 73.4, 72.5, 72.5]


        xaxis = [0, 1, 0.1]
        yaxis = [65, 90, 5]

        title = "Influence of the relative weight $\\alpha$ on the BPR-CAMF model"
        fileName = "accAlphaBPRCAMF.pdf"

        yValueList = [y1, y2, y3]

        plotLine = PlotLine()
        plotLine.x = x
        plotLine.xaxis = xaxis
        plotLine.yaxis = yaxis
        plotLine.title = title

        plotLine.linewidth = 4

        plotLine.xlabel = "$\\alpha$"
        plotLine.ylabel = "ACC(%)"
        plotLine.grid = True

        plotLine.file = join(self.folder, fileName)

        # plot
        plotLine.y = y1
        ymin = plotLine.yaxis[0]
        ymax = plotLine.yaxis[1]
        ytick = plotLine.yaxis[2]
        yt = np.arange(ymin, ymax, ytick)

        pp = PdfPages(plotLine.file)
        plt.figure(1)
        plt.grid(plotLine.grid)

        # line1= plotLine.plot_line_help(plt, x, y1, 'ro-', label = "Line1")

        # plotLine.plot_line_help(plt, x, y2,  'bs:', 'red')
        # plotLine.plot_line_help(plt, x, y3,  'g^--',  'red')


        line1, = plt.plot(plotLine.x, y1, 'ro-', label="Line1", lw=plotLine.linewidth, alpha=plotLine.alpha)
        line2, = plt.plot(plotLine.x, y2, 'bs:', label="Line2", lw=plotLine.linewidth, alpha=plotLine.alpha)
        line3, = plt.plot(plotLine.x, y3, 'g^--', label="Line3", lw=plotLine.linewidth, alpha=plotLine.alpha)

        plt.legend([line1, line2, line3], yList)

        # plt.plot(plotLine.x, y2, ls='bs:', lw=plotLine.linewidth, alpha = plotLine.alpha)
        # plt.plot(plotLine.x, y3, ls='g^--', lw=plotLine.linewidth, alpha = plotLine.alpha)

        plt.title(plotLine.title)
        plt.ylabel(plotLine.ylabel)
        plt.ylim(ymin, ymax)
        plt.xlabel(plotLine.xlabel)

        plt.yticks(yt)
        pp.savefig()
        pp.close()
        plt.close()



    def get_acc_model_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [ 70.3, 59.8, 70.1, 70.0, 80.9]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_acc_model_CAMF_data_CHICAGO(self):
        title = "CHICAGO"
        #yList = [70.3, 59.8, 70.1, 70.0, 75.3]
        yList = [70.3, 59.8, 70.1, 70.0, 75.3, 80.9]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_auc_model_CAMF_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [71.1, 60, 70., 70.0, 75.6]
        yaxis = [55, 85, 5]
        return [title, yList, yaxis]

    def get_precision_model_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [ 62.4, 57.2, 69.5, 69.4, 70.2, 75.4]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_recall_model_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [97.5, 67.5, 68.2, 68.2, 85.2, 90.1]
        yaxis = [55, 101, 5]
        return [title, yList, yaxis]

    def get_f1_model_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [76.1, 61.9, 68.8, 68.8, 76.3, 82.1]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_precision_model_CAMF_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [62.4, 57.2, 69.5, 69.4, 75.4]
        yaxis = [55, 85, 5]
        return [title, yList, yaxis]

    def get_context_model_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [ 72.7, 74.4, 70.6, 69.5, 75.9, 69.6, 73.2, 80.9]
        yaxis = [55, 86, 5]
        return [title, yList, yaxis]

    def get_context_model_CAMF_data_CHICAGO(self):
        title = "CHICAGO"
        yList = [69.3, 66, 66.2, 66, 69.3, 66, 66.1, 75.3, 80.9]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]


    def get_acc_model_CAMF_data_PHOENIX(self):
        title = "PHOENIX"
        #yList = [ 74.6, 62.8, 74.8, 74.7, 78.3]
        yList = [74.6, 62.8, 74.8, 74.7, 78.3, 83]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_auc_model_CAMF_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [75.2, 63, 74.7, 74.6, 78.4]
        yaxis = [55, 85, 5]
        return [title, yList, yaxis]

    def get_acc_model_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [74.6, 62.8, 74.8, 74.7, 83]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_precision_model_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [ 66.9, 59.8, 75.8, 75.8, 74.8, 77.6]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_recall_model_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [94.8, 71.8, 70.6, 70.5, 83.4, 91.4]
        yaxis = [55, 101, 5]
        return [title, yList, yaxis]

    def get_f1_model_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [78.4, 65.2, 73.1, 73.1, 78.9, 83.9]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_precision_model_CAMF_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [66.9, 59.8, 75.8, 75.8, 77.6]
        yaxis = [55, 86, 5]
        return [title, yList, yaxis]

    def get_context_model_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [ 77.1,77.3, 72, 71.1, 78.7, 71, 75.7, 83]
        yaxis = [55, 85, 5]
        return [title, yList, yaxis]

    def get_context_model_CAMF_data_PHOENIX(self):
        title = "PHOENIX"
        yList = [71.4, 66.9, 67, 67, 71, 66.8, 67, 78.3, 83]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_acc_model_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [ 77.5, 61.5, 76.2, 75.5, 79.6]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_acc_model_CAMF_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [75.4, 64.9, 74.6, 74.3, 80.1, 84.7]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_auc_model_CAMF_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [75.4, 65, 74.6, 74.3, 80.2]
        yaxis = [55, 85, 5]
        return [title, yList, yaxis]

    def get_precision_model_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [ 77.5, 61.5, 76.2, 75.5, 77.5, 79.6]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_recall_model_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [71.1, 78.5, 71, 71.4, 84.5, 92.9]
        yaxis = [55, 101, 5]
        return [title, yList, yaxis]

    def get_f1_model_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [74.1, 68.9, 73.5, 73.4, 80.8, 85.8]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_context_model_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [ 77, 77.2, 73.9, 73, 79.1, 73.5, 76.4, 84.7]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]

    def get_context_model_CAMF_data_SANJOSE(self):
        title = "SAN JOSE"
        yList = [67, 69.8, 69.4, 69.7, 71.1, 69.7, 69.4, 80.1, 84.7]
        yaxis = [55, 90, 5]
        return [title, yList, yaxis]


    def plot_acc_models_CHICAGO(self):
        (city, yList, yaxis) = self.get_acc_model_data_CHICAGO()

        self.plot_acc_models_city(city, yList, yaxis)

    def plot_acc_models_PHOENIX(self):
        (city, yList, yaxis) = self.get_acc_model_data_PHOENIX()
        self.plot_acc_models_city(city, yList, yaxis)

    def plot_acc_models_SANJOSE(self):
        (city, yList, yaxis) = self.get_acc_model_data_SANJOSE()
        self.plot_acc_models_city(city, yList, yaxis)

    def plot_acc_models_city(self, title, yList, yaxis):

        plotBar = Plotbar()
        plotBar.xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "BPR-CAMF", "CAMF"]
        plotBar.xcolor = ['green','blue','orange','purple', 'purple', 'red']
        plotBar.xwidth = 0.5
        plotBar.y = yList
        plotBar.yaxis = yaxis
        plotBar.ylabel = "ACC(%)"
        baseTitle = "Accuracy of methods for Event Recommendation"
        plotBar.alpha=0.6
        plotBar.grid = True
        #plotBar.text = city
        plotBar.title = baseTitle + "(" + title + ")"


        fileName =   title + "_" +  ".pdf"
        plotBar.file = join(self.folder, fileName)

        plotBar.plot_bar()

    def plot_precision_models(self):
        self.plot_precision_models_merge()

    def plot_precision_models_CAMF(self):
        self.plot_precision_models_CAMF_merge()

    def plot_recall_models_CAMF(self):
        self.plot_recall_models_CAMF_merge()

    def plot_f1_models_CAMF(self):
        self.plot_f1_models_CAMF_merge()

    def plot_acc_models_merge(self):

        fileName =  "acc.pdf"
        file = join(self.folder, fileName)
        #plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("Accuracy of methods for Event Recommendation")

        ax = fig.add_subplot(311)

        #ax.set_title('CHICAGO')
        data = self.get_acc_model_data_CHICAGO()
        self.plot_acc_models_merge_help(plt, data, False)

        ax = fig.add_subplot(312)

        #ax.set_title('CHICAGO')
        data = self.get_acc_model_data_PHOENIX()
        self.plot_acc_models_merge_help(plt, data, False)

        ax = fig.add_subplot(313)

        #ax.set_title('CHICAGO')
        data = self.get_acc_model_data_SANJOSE()
        self.plot_acc_models_merge_help(plt, data)

        #plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust( hspace =0.3)


        pp.savefig()
        pp.close()
        plt.close()

    def plot_acc_models_CAMF_merge(self):

        fileName = "accCAMF.pdf"
        file = join(self.folder, fileName)
        # plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("Accuracy of methods for Event Recommendation")

        ax = fig.add_subplot(311)

        # ax.set_title('CHICAGO')
        data = self.get_acc_model_CAMF_data_CHICAGO()
        self.plot_acc_models_CAMF_merge_help(plt, data, False)

        ax = fig.add_subplot(312)

        # ax.set_title('CHICAGO')
        data = self.get_acc_model_CAMF_data_PHOENIX()
        self.plot_acc_models_CAMF_merge_help(plt, data, False)

        ax = fig.add_subplot(313)

        # ax.set_title('CHICAGO')
        data = self.get_acc_model_CAMF_data_SANJOSE()
        self.plot_acc_models_CAMF_merge_help(plt, data)

        # plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust(hspace=0.3)

        pp.savefig()
        pp.close()
        plt.close()

    def plot_auc_models_CAMF_merge(self):

        fileName = "aucCAMF.pdf"
        file = join(self.folder, fileName)
        # plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("AUC of methods for Event Recommendation")

        ax = fig.add_subplot(311)

        # ax.set_title('CHICAGO')
        data = self.get_auc_model_CAMF_data_CHICAGO()
        self.plot_auc_models_CAMF_merge_help(plt, data, False)

        ax = fig.add_subplot(312)

        # ax.set_title('CHICAGO')
        data = self.get_auc_model_CAMF_data_PHOENIX()
        self.plot_auc_models_CAMF_merge_help(plt, data, False)

        ax = fig.add_subplot(313)

        # ax.set_title('CHICAGO')
        data = self.get_auc_model_CAMF_data_SANJOSE()
        self.plot_auc_models_CAMF_merge_help(plt, data)

        # plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust(hspace=0.3)

        pp.savefig()
        pp.close()
        plt.close()

    def plot_acc_context(self):
        #self.plot_acc_context_alphamf()
        self.plot_acc_context_CAMF()

    def plot_acc_context_alphamf(self):
        fileName =  "accContext.pdf"
        file = join(self.folder, fileName)
        #plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("Influence of contextual features")

        ax = fig.add_subplot(311)

        #ax.set_title('CHICAGO')
        data = self.get_context_model_data_CHICAGO()
        self.plot_context_merge_help_alphamf(plt, data, False)

        ax = fig.add_subplot(312)

        #ax.set_title('CHICAGO')
        data = self.get_context_model_data_PHOENIX()
        self.plot_context_merge_help_alphamf(plt, data, False)

        ax = fig.add_subplot(313)

        #ax.set_title('CHICAGO')
        data = self.get_context_model_data_SANJOSE()
        self.plot_context_merge_help_alphamf(plt, data, True)

        #plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust( hspace =0.4)


        pp.savefig()
        pp.close()
        plt.close()
        pass

    def plot_acc_context_CAMF(self):
        fileName = "accContextCAMF.pdf"
        file = join(self.folder, fileName)
        # plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("Influence of contextual features")

        ax = fig.add_subplot(311)

        # ax.set_title('CHICAGO')
        data = self.get_context_model_CAMF_data_CHICAGO()
        self.plot_context_merge_help_CAMF(plt, data, False)

        ax = fig.add_subplot(312)

        # ax.set_title('CHICAGO')
        data = self.get_context_model_CAMF_data_PHOENIX()
        self.plot_context_merge_help_CAMF(plt, data, False)

        ax = fig.add_subplot(313)

        # ax.set_title('CHICAGO')
        data = self.get_context_model_CAMF_data_SANJOSE()
        self.plot_context_merge_help_CAMF(plt, data, True)

        # plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust(hspace=0.4)

        pp.savefig()
        pp.close()
        plt.close()
        pass

    def plot_precision_models_merge(self):

        fileName =  "precision.pdf"
        file = join(self.folder, fileName)
        #plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("Precision of methods for Event Recommendation")

        ax = fig.add_subplot(311)

        #ax.set_title('CHICAGO')
        data = self.get_precision_model_data_CHICAGO()
        self.plot_precision_models_merge_help(plt, data, False)

        ax = fig.add_subplot(312)

        #ax.set_title('CHICAGO')
        data = self.get_precision_model_data_PHOENIX()
        self.plot_precision_models_merge_help(plt, data, False)

        ax = fig.add_subplot(313)

        #ax.set_title('CHICAGO')
        data = self.get_precision_model_data_SANJOSE()
        self.plot_precision_models_merge_help(plt, data)

        #plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust( hspace =0.3)


        pp.savefig()
        pp.close()
        plt.close()

    def plot_precision_models_CAMF_merge(self):

        fileName = "precisionCAMF.pdf"
        file = join(self.folder, fileName)
        # plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("Precision of methods for Event Recommendation")

        ax = fig.add_subplot(311)

        # ax.set_title('CHICAGO')
        data = self.get_precision_model_data_CHICAGO()
        self.plot_precision_models_merge_help(plt, data, False)

        ax = fig.add_subplot(312)

        # ax.set_title('CHICAGO')
        data = self.get_precision_model_data_PHOENIX()
        self.plot_precision_models_merge_help(plt, data, False)

        ax = fig.add_subplot(313)

        # ax.set_title('CHICAGO')
        data = self.get_precision_model_data_SANJOSE()
        self.plot_precision_models_merge_help(plt, data)

        # plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust(hspace=0.3)

        pp.savefig()
        pp.close()
        plt.close()


    def plot_recall_models_CAMF_merge(self):
        fileName = "recallCAMF.pdf"
        file = join(self.folder, fileName)
        # plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("Recall of methods for Event Recommendation")

        ax = fig.add_subplot(311)

        # ax.set_title('CHICAGO')
        data = self.get_recall_model_data_CHICAGO()
        self.plot_recall_models_merge_help(plt, data, False)

        ax = fig.add_subplot(312)

        # ax.set_title('CHICAGO')
        data = self.get_recall_model_data_PHOENIX()
        self.plot_recall_models_merge_help(plt, data, False)

        ax = fig.add_subplot(313)

        # ax.set_title('CHICAGO')
        data = self.get_recall_model_data_SANJOSE()
        self.plot_recall_models_merge_help(plt, data)

        # plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust(hspace=0.3)

        pp.savefig()
        pp.close()
        plt.close()

    def plot_f1_models_CAMF_merge(self):
        fileName = "f1CAMF.pdf"
        file = join(self.folder, fileName)
        # plot
        pp = PdfPages(file)
        fig = plt.figure()

        plt.suptitle("$F_1$ of methods for Event Recommendation")

        ax = fig.add_subplot(311)

        # ax.set_title('CHICAGO')
        data = self.get_f1_model_data_CHICAGO()
        self.plot_f1_models_merge_help(plt, data, False)

        ax = fig.add_subplot(312)

        # ax.set_title('CHICAGO')
        data = self.get_f1_model_data_PHOENIX()
        self.plot_f1_models_merge_help(plt, data, False)

        ax = fig.add_subplot(313)

        # ax.set_title('CHICAGO')
        data = self.get_f1_model_data_SANJOSE()
        self.plot_f1_models_merge_help(plt, data)

        # plt.subplots_adjust(bottom=0.3, right=0.9, top=0.9, hspace =0.6, wspace=0.4)
        plt.subplots_adjust(hspace=0.3)

        pp.savefig()
        pp.close()
        plt.close()


    def plot_acc_models_CAMF_merge_help(self, plt, data, hasXlabels=True):
        ylabel = "ACC(/%)"
        xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "BPR-CAMF", "CAMF"]
        self.plot_metrics_models_merge_help(plt, data, xlabels, ylabel, hasXlabels)

    def plot_auc_models_CAMF_merge_help(self, plt, data, hasXlabels=True):
        ylabel = "AUC(/%)"
        xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "BPR-CAMF", "CAMF"]
        self.plot_metrics_models_merge_help(plt, data, xlabels, ylabel, hasXlabels)

    def plot_acc_models_merge_help(self, plt, data, hasXlabels=True):
        ylabel = "ACC(/%)"
        xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "AlphaMF"]
        self.plot_metrics_models_merge_help(plt, data, xlabels, ylabel, hasXlabels)


    def plot_precision_models_merge_help(self, plt, data, hasXlabels=True):
        ylabel = "Precision(/%)"
        xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "BPR-CAMF", "CAMF"]
        self.plot_metrics_models_merge_help(plt, data, xlabels, ylabel, hasXlabels)

    def plot_recall_models_merge_help(self, plt, data, hasXlabels=True):
        ylabel = "Recall(/%)"
        xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "BPR-CAMF", "CAMF"]
        self.plot_metrics_models_merge_help(plt, data, xlabels, ylabel, hasXlabels)


    def plot_f1_models_merge_help(self, plt, data, hasXlabels=True):
        ylabel = "$F_1$(/%)"
        xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "BPR-CAMF", "CAMF"]
        self.plot_metrics_models_merge_help(plt, data, xlabels, ylabel, hasXlabels)

    def plot_bar_list_help(self, plt, data, ylabel, xlabels, xcolor, hasXlabels=True):
        #data
        [title, yList, yaxis] = data
        #base setting
        plotBar = Plotbar()
        plotBar.xlabels = xlabels
        #plotBar.xlabels = []
        plotBar.xcolor = xcolor
        plotBar.xwidth = 0.5

        plotBar.ylabel =  ylabel
        #plotBar.title = "Accuracy of methods for Event Recommendation"
        plotBar.alpha=0.8
        plotBar.grid = True
        #plotBar.text = city

        if(hasXlabels == False):
            plotBar.xlabels = []
            pass

        #plot setting
        plotBar.title = title
        plotBar.y = yList
        plotBar.yaxis = yaxis
        ymin = plotBar.yaxis[0]
        ymax = plotBar.yaxis[1]
        ytick = plotBar.yaxis[2]
        N=len(plotBar.y)
        ind = np.arange(N)
        yt=np.arange(ymin, ymax, ytick)

        plt.grid(plotBar.grid)

        p = plt.bar(ind, plotBar.y, color = plotBar.xcolor, alpha=plotBar.alpha)
        plt.title(plotBar.title)
        plt.xticks(ind + plotBar.xwidth/plotBar.xwidth_base, plotBar.xlabels)
        plt.yticks(yt)
        plt.ylabel(plotBar.ylabel)
        plt.ylim(ymin,ymax)

        if(plotBar.text != None):
            print plotBar.text

            #plt.text(2.5, 80, self.text, horizontalalignment='center',verticalalignment='center')

    def plot_metrics_models_merge_help(self, plt, data, xlabels, ylabel, hasXlabels):
        #xlabels = ["MF", "BPR-MF", "C-MDM", "L-MC", "AlphaMF"]
        xcolor = ['green','blue','orange','purple', 'red']
        self.plot_bar_list_help(plt, data, ylabel, xlabels, xcolor, hasXlabels)

    def plot_context_merge_help_alphamf(self, plt, data, hasXlabels):
        xlabels = ["User", "Temporal", "Spatial", "Semantic", "Event", "Group", "Social", "AlphaMF"]
        ylabel = "ACC(/%)"
        self.plot_context_merge_help(plt, data, xlabels, hasXlabels, ylabel)

    def plot_context_merge_help_CAMF(self, plt, data, hasXlabels):
        xlabels = ["User", "Temporal", "Spatial", "Semantic", "Event", "Group", "Social", "BPR-CAMF", "CAMF"]
        ylabel = "ACC(/%)"
        self.plot_context_merge_help(plt, data, xlabels, hasXlabels, ylabel)


    def plot_context_merge_help(self, plt, data, xlabels, hasXlabels,ylabel):
        #xlabels = ["User", "Temporal", "Spatial", "Semantic", "Event", "Group", "Social", "AlphaMF"]
        xcolor = ['green','blue','orange','brown', 'pink','aqua','coral','purple', 'red']

        self.plot_bar_list_help(plt, data, ylabel, xlabels, xcolor, hasXlabels)

