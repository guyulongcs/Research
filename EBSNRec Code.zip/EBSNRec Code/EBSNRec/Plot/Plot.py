import gmplot

from Tool.PlotTool.GeoPlot.gmplot.gmplot import *

from PlotExpRes import *
from PlotCity import *

class Plot():
    def __init__(self):
        pass

    def start(self):

        pl = PlotCity()
        #pl.start()

        pl = PlotExpRes()
        pl.start()
