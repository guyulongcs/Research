from EBSN.EBSNData import *
from EBSN.User import *
from EBSN.Event import *
from EBSN.Group import *
from EBSN.Location import *
from EBSN.RSVP import *
from EBSN.Category import *
from EBSN.Tag import *
from EBSN.FilePro import *

from Config import *

class LoadEBSNData():
    def __init__(self, region = None):
        self.ebsnData = EBSNData()
        self.region = region

    def load_data(self):
        InOut.console_func_begin("LoadEBSNData load_data")
        self.load_data_single()
        self.load_data_pair()

        return self.ebsnData
        pass


    def load_data_single(self):
        InOut.console_func_begin("load_data_single")
        self.load_data_user()
        self.load_data_group()
        self.load_data_event()
        self.load_data_rsvp()
        self.load_data_location()
        #self.load_data_category()
        #self.load_data_tag()

    def load_data_pair(self):
        InOut.console_func_begin("load_data_pair")
        self.load_group_tag()
        self.load_group_event()
        self.load_group_users()


    def load_data_user(self):
        self.ebsnData.dictUser =  User.load_data_user()
        pass

    def load_data_group(self):
        self.ebsnData.dictGroup = Group.load_data_group()
        self.ebsnData.setGroup = Group.load_set_group_region()
        pass

    def load_data_event(self):

        if(self.region == None):
            self.ebsnData.dictEvent = Event.load_data_event()
        else:
            self.ebsnData.dictEvent = Event.load_data_event_region()
        pass

    def load_data_event_all(self):
        self.ebsnData.dictEvent = Event.load_data_event()


    def load_data_rsvp(self):
        if(self.region == None):
            self.ebsnData.dictRsvp = RSVP.load_data_rsvp()
        else:
            self.ebsnData.dictRsvp = RSVP.load_data_rsvp_region()
        pass

    def load_data_location(self):
        self.ebsnData.dictLocation = Location.load_data_location()
        pass

    def load_data_category(self):
        self.ebsnData.dictCategory = Category.load_data_category()
        pass

    def load_data_tag(self):
        self.ebsnData.dictTag = Tag.load_data_tag()
        pass

    def load_group_tag(self):
        self.ebsnData.dictGroupTagset = FilePro.load_file_pair_to_dictStrSetstr_flag(Config.file_group_tag)
        pass


    def load_group_event(self):
        self.ebsnData.dictGroupEventset = FilePro.load_file_pair_to_dictStrSetstr_flag(Config.file_group_event, self.region)
        self.ebsnData.dictEventGroup = FilePro.load_file_pair_to_dictStrStr_reverse_flag(Config.file_group_event, self.region)

        print "dictEventGroup:", len(self.ebsnData.dictEventGroup)

        pass

    def load_group_users(self):
        (self.ebsnData.dictGroupUserset, self.ebsnData.dictUserGroupset) = FilePro.load_file_pair_to_bi_dictStrSetstr_flag(Config.file_group_user, self.region)
        #TypeProcessTool.check_dictStrSetStrValue(self.ebsnData.dictUserGroupset)


    def load_event_loc_list(self, region=None):

        self.region = region
        Config.region = region
        Config.flag_process_region = True
        Config.file_process_region = region

        self.load_data_event_all()
        self.load_data_group()
        self.load_data_location()

        resList = []
        for event_id in self.ebsnData.dictEvent:
            event = self.ebsnData.dictEvent[event_id]
            group_id = event.group_id
            if(group_id not in self.ebsnData.setGroup):
                continue

            loc_id = event.location_id
            if(loc_id in self.ebsnData.dictLocation):
                loc = self.ebsnData.dictLocation[loc_id]
                resList.append(loc)

        return resList