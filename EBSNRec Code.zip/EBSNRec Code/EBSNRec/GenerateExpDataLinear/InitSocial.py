from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from InitEvent import *
from DataLinear import *
from InitRsvp import *

class InitSocial():
    def __init__(self):

        pass

    @classmethod
    def get_dict_feature_userid_eventid(cls, data, ebsnData, dataLinear):
        print "InitUser get_dict_feature_userid_eventid..."
        R = data._ratingList_complete

        (dict_userid_eventid_hasAttendOnFriendCnt, dict_userid_eventid_hasAttendOffFriendCnt) = InitRsvp.get_dict_userid_eventid_hasAttendFriendCnt(data, ebsnData, dataLinear)

        return (dict_userid_eventid_hasAttendOnFriendCnt, dict_userid_eventid_hasAttendOffFriendCnt)

