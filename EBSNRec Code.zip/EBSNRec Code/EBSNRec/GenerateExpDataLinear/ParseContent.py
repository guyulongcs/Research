from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from DataLinear import *



class ParseContent():
    def __init__(self):

        pass

    @classmethod
    def generate_feature(cls, user_id, event_id, ebsnData, dataLinear):
        user_event_content_sim = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventid_content_sim, user_id, event_id)

        resList = []
        resList = [user_event_content_sim]
        print "contentFeature:", resList
        return resList

    @classmethod
    def cal_user_event_content_similarity(cls, user_id, event_id, dataLinear):
        user_feature = dataLinear.dict_content_userId_vec_tfidf
        event_feature = dataLinear.dict_content_eventId_vec_tfidf
        sim = Content.cal_item_similarity_cos(user_feature, event_feature)

        return sim