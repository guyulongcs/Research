from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from DataLinear import *
from ParseEvent import *
from EBSN.Location import *


class ParseLocation():
    def __init__(self):

        pass

    @classmethod
    def generate_feature(cls, user_id, event_id, ebsnData, dataLinear):
        resList = []
        #feature
        dis = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventid_dis, user_id, event_id)
        pastEventDis = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventid_pastEventDis, user_id, event_id)

        resList = [dis, pastEventDis]
        return resList



    @classmethod
    def get_feature_user_event_dis(cls, user_id, event_id, ebsnData):
        res = 0
        res = Location.get_userid_eventid_dis(user_id, event_id, ebsnData)
        return res

    @classmethod
    def get_feature_user_event_pastEvent_dis(cls, event_id, hasattend_eventid_list, ebsnData, dataLinear):
        res = 0
        nume = 0
        deno = 0
        for past_event_id in hasattend_eventid_list:
            dis_event = Location.get_eventid_eventid_dis(event_id, past_event_id, ebsnData)
            sim_event = Content.cal_event_similarity(event_id, past_event_id, dataLinear)

            nume += (dis_event * sim_event)
            deno += sim_event
        res = Math.divide(nume, deno)

        return res
        pass