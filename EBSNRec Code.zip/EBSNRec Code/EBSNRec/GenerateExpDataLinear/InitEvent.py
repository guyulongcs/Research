from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from InitEvent import *
from DataLinear import *
from ParseLocation import *
from EBSN.Content import *
import warnings

class InitEvent():
    def __init__(self):
        pass


    @classmethod
    def eventlist_2_grouplist(cls, eventlist, ebsnData):

        resList = [InitEvent.event_2_group(event, ebsnData) for event in eventlist]
        #print "eventList:", eventlist
        #print "group_list:", resList
        #print "dictEventGroup:", len(self.ebsnData.dictEventGroup)

        # print "\neventlist_2_grouplist..."
        # print "eventList:", eventlist
        # print "groupList:", resList

        return resList

    @classmethod
    def event_2_group(cls, event, ebsnData):
        return ebsnData.dictEventGroup[event]

    @classmethod
    def get_dict_feature_userid_eventid(cls, data, ebsnData, dataLinear):
        R = data._ratingList_complete

        dict_userid_eventid_simEventCnt = {}
        dict_userid_eventid_hasRsvpCnt = {}

        i=0
        N = len(R)
        for rating in R:
            user_id = rating[0]
            event_id = rating[1]
            rate = rating[2]
            #if(user_id not in data._userSet):
            #    continue
            #if(Data.IsItemPositive(rate) == False):
            #    continue

            has_attend_event_list = dataLinear.get_hasAttendEventidList(user_id, event_id)

            simEventCnt = InitEvent.getSimilarEventCnt(event_id, has_attend_event_list, dataLinear)
            eventHasRsvpCnt = InitEvent.getEventHasRsvpCnt(user_id, event_id, ebsnData, dataLinear)

            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_simEventCnt, user_id, event_id, simEventCnt)
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_hasRsvpCnt, user_id, event_id, eventHasRsvpCnt)

            i+=1
            if(i% 100 == 0):
                print "\ninitEvent"
                print "%d / %d" % (i, N)
                print "\nuser_id:%s, event_id:%s" % (user_id, event_id)
                print "\nsimEventCnt:%d, eventHasRsvpCnt:%d" % (simEventCnt, eventHasRsvpCnt)

                #break


        return (dict_userid_eventid_simEventCnt, dict_userid_eventid_hasRsvpCnt)
        pass

    @classmethod
    def getSimilarEventCnt(cls, event, event_list, dataLinear):
        cnt = 0
        for e in event_list:
            sim = Content.cal_event_similarity(event, e, dataLinear)
            if(sim > Config.p_linear_event_sim_thres):
                cnt += 1
        return cnt

    @classmethod
    def getEventHasRsvpCnt(cls, user_id, event_id, ebsnData, dataLinear):
        cnt = 0

        try:
            rsvpid = dataLinear.dict_eventid_userid_rsvpid[event_id][user_id]
            rsvpCur = ebsnData.dictRsvp[rsvpid]
            for uid in dataLinear.dict_eventid_userid_rsvpid[event_id]:
                rsvpid = dataLinear.dict_eventid_userid_rsvpid[event_id][uid]
                rsvp = ebsnData.dictRsvp[rsvpid]
                if(RSVP.happenBefore(rsvp, rsvpCur)):
                    cnt += 1
        except:
            warnings.warn("getEventHasRsvpCnt except")
            cnt = 0

        return cnt