from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from EBSN.Content import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from DataLinear import *
from ParseEvent import *




class ParseGroup():
    def __init__(self):

        pass

    @classmethod
    def generate_feature(cls, user_id, event_id, ebsnData, dataLinear):

        InOut.console_func_begin("ParseGroup")
        InOut.console_func_begin("generate_feature")
        resList = []


        simGroup = dataLinear.dict_userid_eventid_group_sim[user_id][event_id]

        resList = [simGroup]

        print "eventFeature:", resList
        return resList


    @classmethod
    def get_user_event_feature_content_group(cls, user_id, event_id, hasattend_eventid_list, ebsnData, dataLinear):
        numer = 0
        denom = 0
        for past_eventid in hasattend_eventid_list:
            event_sim_content = Content.cal_event_similarity(event_id, past_eventid, dataLinear)
            event_sim_group = ParseGroup.cal_event_sim_group(user_id, event_id, past_eventid, ebsnData)
            numer += (event_sim_group * event_sim_content )
            denom += event_sim_content

        res = Math.divide(numer, denom)
        return res
        pass

    @classmethod
    def cal_event_sim_group(cls, user_id, eventid, past_eventid, ebsnData):
        userid_groupset = ebsnData.dictUserGroupset[user_id]
        eventid_group = ebsnData.dictEventGroup[eventid]
        past_eventid_group = ebsnData.dictEventGroup[past_eventid]
        f1=0
        f2=0
        if(eventid_group in userid_groupset):
            f1 = 1
        if(eventid_group == past_eventid_group):
            f2 = 1

        p = Config.p_linear_group_same_group_weigtht
        res = f1 * p + f2 * (1-p)
        return res

