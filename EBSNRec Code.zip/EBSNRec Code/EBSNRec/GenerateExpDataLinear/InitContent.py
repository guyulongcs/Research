from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *

class InitContent():
    def __init__(self):

        pass

    @classmethod
    def init(cls, data, ebsnData, dataLinear):
        #(dictContentEventidVecTfidf, dictContentUseridVecTfidf) = InitContent.get_content_event_user_vec_tfidf(ebsnData.dictEvent, data, dataLinear)

        #return (dictContentEventidVecTfidf, dictContentUseridVecTfidf)
        pass

    @classmethod
    def get_dict_feature_userid_eventid(cls, data, dataLinear):
        dict_userid_eventid_feature = InitContent.get_dict_feature_userid_eventid_help(data, dataLinear)
        return dict_userid_eventid_feature

    @classmethod
    def get_dict_feature_userid_eventid_help(cls, data, dataLinear):
        #dict_content_userId_vec_tfidf = InitContent.get_content_userId_vec_tf_idf(data, dataLinear.dict_userid_eventid_hasAttendEventidList, dataLinear.dict_content_eventId_vec_tfidf)

        R = data._ratingList_complete

        i=0
        N = len(R)
        dict_userid_eventid_content_sim = {}
        for rating in R:
            user_id = rating[0]
            event_id = rating[1]
            rate = rating[2]
            #if(user_id not in data._userSet):
            #    continue
            #if(Data.IsItemPositive(rate) == False):
            #    continue
            content_sim=0
            if(True):
            #try:

                has_attend_event_list = dataLinear.get_hasAttendEventidList(user_id, event_id)
                user_vec = InitContent.get_user_vec_tf_idf_from_event(data, has_attend_event_list, dataLinear.dict_content_eventid_vec_tfidf)
                event_vec = dataLinear.dict_content_eventid_vec_tfidf[event_id]
                content_sim = Content.cal_item_similarity_cos(user_vec, event_vec)


            #except:
            #    content_sim=0

            #print "user_id:%s, event_id:%s, content_sim:%f" %(user_id, event_id, content_sim)
            #print "user_vec:", user_vec
            #print "event_vec:", event_vec

            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_content_sim, user_id, event_id, content_sim)

            i+=1
            if(i% 100 == 0):
                print "\ninitContent"
                print "%d / %d" % (i, N)
                print "\nuser_id:%s, event_id:%s, content_sim:%f" % (user_id, event_id, content_sim)



        return (dict_userid_eventid_content_sim)
        pass

    @classmethod
    def get_content_event_vec_tfidf(cls, data, ebsnData):
        InOut.console_func_begin("get_content_event_vec_tfidf")
        dictContentEventidVecTfidf = Event.get_dict_eventId_vec_tfidf(ebsnData.dictEvent, Config.p_linear_content_tfidf_wordscnt)
        return dictContentEventidVecTfidf


    # @classmethod
    # def get_content_userId_vec_tf_idf(cls, data, dict_userid_eventid_hasAttendEventidList, dict_content_eventId_vec_tfidf):
    #     dictContentUseridVecTfidf = InitContent.get_user_vec_tf_idf_from_event(data, dict_userid_eventid_hasAttendEventidList, dict_content_eventId_vec_tfidf)
    #     return dictContentUseridVecTfidf
    #
    #     pass
    # @classmethod
    # def get_content_event_user_vec_tfidf(cls, dictEvent, data, dict_userid_eventid_hasAttendEventidList):
    #
    #     dictContentEventidVecTfidf = {}
    #
    #     dictContentEventidVecTfidf = Event.get_dict_eventId_vec_tfidf(dictEvent, Config.p_linear_content_tfidf_wordscnt)
    #     dictContentUseridVecTfidf = InitContent.get_user_vec_tf_idf_from_event(data, dict_userid_eventid_hasAttendEventidList, dictContentEventidVecTfidf)
    #
    #     return (dictContentEventidVecTfidf, dictContentUseridVecTfidf)

    @classmethod
    def get_user_vec_tf_idf_from_event(cls, data, hasAttendEventidList, dictContentEventidVecTfidf):

        event_id_list = hasAttendEventidList
        event_id_vec_list = InitContent.trans_event_id_list_2_event_id_vec_list(event_id_list, dictContentEventidVecTfidf)
        user_vec = SparseMatrix.cal_sparseMatrix_veclist_sum(event_id_vec_list)

        return user_vec

        pass

    @classmethod
    def trans_event_index_list_2_event_id_list(cls, event_index_list, data):
        res = [data._dictIndexItem[i] for i in event_index_list]
        return res

    @classmethod
    def trans_event_id_list_2_event_id_vec_list(cls, event_id_list, dictContentEventidVecTfidf):
        res = [dictContentEventidVecTfidf[i] for i in event_id_list]
        return res


