from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *

from DataLinear import *
from InitRsvp import *
from InitContent import *
from InitUser import *

class InitBase():
    def __init__(self):

        pass

    @classmethod
    def init(cls, data, ebsnData):
        InOut.console_func_begin("InitBase")
        dataLinear = DataLinear()

        #rsvp
        (dataLinear.dict_userid_eventid_rsvpid, dataLinear.dict_eventid_userid_rsvpid) = InitRsvp.get_dict_bi_userid_eventid_rsvpid(data, ebsnData)

        #has attend
        dataLinear.dict_userid_eventid_hasAttendEventidList = InitRsvp.get_dict_userid_eventid_hasAttendEventidList(data, ebsnData, dataLinear)
        #content
        dataLinear.dict_content_eventid_vec_tfidf = InitContent.get_content_event_vec_tfidf(data, ebsnData)

        InOut.console_func_end("InitBase")
        return dataLinear





