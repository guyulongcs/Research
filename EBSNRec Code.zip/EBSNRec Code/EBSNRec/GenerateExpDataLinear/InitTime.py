from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from InitContent import *

class InitTime():
    def __init__(self):
        pass

    @classmethod
    def init(cls, data, ebsnData):

        pass


    @classmethod
    def get_dict_feature_userid_eventid(cls, data, ebsnData, dataLinear):
        dictEventTimeVec = InitTime.get_dict_time_event_vec(ebsnData.dictEvent)
        dict_userid_eventid_time_sim = InitTime.get_dict_userid_eventid_time_sim(data, dataLinear, dictEventTimeVec)
        return dict_userid_eventid_time_sim




    @classmethod
    def get_dict_time_event_vec(cls, dictEvent):
        dictEventTimeVec = {}
        for event_id in dictEvent:
            event = dictEvent[event_id]
            event_time = event.get_event_time()
            vec = TimeTool.get_time_vec_of_datetime(event_time)
            dictEventTimeVec[event_id] = vec

        return dictEventTimeVec
        pass


    @classmethod
    def get_dict_userid_eventid_time_sim(cls, data, dataLinear, dictEventTimeVec):

        R = data._ratingList_complete

        dict_userid_eventid_time_sim = {}
        for rating in R:
            user_id = rating[0]
            event_id = rating[1]
            rate = rating[2]
            #if(user_id not in data._userSet):
            #    continue
            #if(Data.IsItemPositive(rate) == False):
            #    continue

            time_sim = 0
            #try:
            if(True):
                has_attend_event_list = dataLinear.get_hasAttendEventidList(user_id, event_id)
                user_vec = InitTime.get_time_user_vec(dictEventTimeVec, has_attend_event_list)
                event_vec = dictEventTimeVec[event_id]

                time_sim = Content.cal_item_similarity_cos(user_vec, event_vec)

                #print "\n1: user_id:%s, event_id:%s, time_sim:%f" % (user_id, event_id, time_sim)
            #except:
            #    time_sim = 0

            # print "\n2: user_id:%s, event_id:%s, time_sim:%f" % (user_id, event_id, time_sim)
            # print "user_vec:", user_vec
            # print "event_vec:", event_vec

            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_time_sim, user_id, event_id, time_sim)

        return (dict_userid_eventid_time_sim)
        pass

    @classmethod
    def get_time_user_vec(cls, dictEventTimeVec, has_attend_event_list):

        user_vec = None
        event_id_vec_list = InitTime.trans_event_id_list_2_event_id_vec_list(has_attend_event_list, dictEventTimeVec)
        user_vec = SparseMatrix.cal_sparseMatrix_veclist_avg(event_id_vec_list)
        #print "event_id_vec_list:"
        #print event_id_vec_list
        #print "user_vec:", user_vec
        return user_vec



    @classmethod
    def trans_event_id_list_2_event_id_vec_list(cls, event_id_list, dictEventTimeVec):
        res = [dictEventTimeVec[i] for i in event_id_list]
        return res



