from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from DataLinear import *



class ParseUser():
    def __init__(self):

        pass

    @classmethod
    def generate_feature(cls, user_id, event_id, ebsnData, dataLinear):
        print "ParseUser..."
        resList = []
        #feature: attend event cnt; attend event by group of event_id cnt; attend event by group of event_id ratio
        event_cnt = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventid_hasAttendCnt, user_id, event_id)
        group_id = ebsnData.dictEventGroup[event_id]
        print "group_id:", group_id
        eventGroup_cnt = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventidGroupid_hasAttendCnt, user_id, event_id)

        s = "user_id:%s, event_id:%s, event_cnt:%d, event_group_cnt: %d" % (user_id, event_id, event_cnt, eventGroup_cnt)
        #print s
        if(event_cnt > 0 and eventGroup_cnt > 0):
            #print s
            pass
        eventGroup_ratio = Math.divide(eventGroup_cnt, event_cnt)
        resList = [event_cnt, eventGroup_cnt, eventGroup_ratio]
        print "userFeature:", resList
        return resList
