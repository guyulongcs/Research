from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from DataLinear import *



class ParseSocial():
    def __init__(self):

        pass

    @classmethod
    def generate_feature(cls, user_id, event_id, ebsnData, dataLinear):
        resList = []

        onFriendHasRsvpCnt = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventid_onFriendHasRsvpCnt, user_id, event_id)
        offFriendHasRsvpCnt = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventid_offFriendHasRsvpCnt, user_id, event_id)


        s = "user_id:%s, event_id:%s, onFriendHasRsvpCnt:%d, offFriendHasRsvpCnt: %d" % (user_id, event_id, onFriendHasRsvpCnt, offFriendHasRsvpCnt)


        resList = [onFriendHasRsvpCnt, offFriendHasRsvpCnt]

        if(onFriendHasRsvpCnt > 0 or offFriendHasRsvpCnt > 0 ):
            print "userFeature:", resList
        return resList
