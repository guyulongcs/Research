from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from DataLinear import *
from ParseEvent import *


class ParseTime():
    def __init__(self):

        pass

    @classmethod
    def generate_feature(cls, user_id, event_id, ebsnData, dataLinear):

        resList = []
        time_sim = TypeProcessTool.get_dictstrstrint_value(dataLinear.dict_userid_eventid_time_sim, user_id, event_id)
        resList=[time_sim]

        return resList

    @classmethod
    def get_feature_user_event_time(cls, user_id, event_id, dataLinear):
        res = 0
        res = ParseTime.get_sim_user_event_time(user_id, event_id, dataLinear)
        return res


    @classmethod
    def get_sim_user_event_time(cls, user_id, event_id, dataLinear):
        user_feature = dataLinear.dict_time_userid_vec[user_id]
        event_feature = dataLinear.dict_time_eventid_vec[event_id]
        sim = Content.cal_item_similarity_cos(user_feature, event_feature)

        return sim

