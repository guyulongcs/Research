from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *

from DataLinear import *
from ParseUser import *
from ParseContent import *
from ParseEvent import *
from ParseGroup import *
from ParseLocation import *
from ParseSocial import *
from ParseTime import *



class Parse():
    def __init__(self, data, ebsnData, dataLinear):
        self.data = data
        self.ebsnData = ebsnData
        self.dataLinear = dataLinear
        pass

    def parse_process(self):
        InOut.console_func_begin("parse_process")
        R = self.data._ratingList_complete
        print "R:", len(R)
        dict_linear_feature = {}
        for rating in R:
            user_id = rating[0]
            event_id = rating[1]
            rate = rating[2]
            linear_feature = self.generate_model_data_linear_user_item(user_id, event_id)
            #print "user_id:%s, event_id:%s" % (user_id, event_id)
            #print "linear_feature:",  len(linear_feature)
            print linear_feature

            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_linear_feature, user_id, event_id, linear_feature)

        return dict_linear_feature
        pass


    def generate_model_data_linear_user_item(self,  user_id, event_id):
        InOut.console_func_begin("console_func_begin")
        resList = []

        for feature_type in Config.p_linear_feature_type_list:
            fList = self.generate_model_data_linear_user_item_feature_of_type(user_id, event_id, feature_type)
            resList.extend(fList)
        return resList




    # def get_user_product_list(self):
    #     ratingList = self._ratingList
    #     resList = []
    #
    #     for rating in ratingList:
    #         user = rating[0]
    #         item = rating[1]
    #         rate = rating[2]
    #         resList.append([user, item])
    #     return resList
    #
    #     pass

    def generate_model_data_linear_user_item_feature_of_type(self, user_id, event_id, feature_type):
        resList = []
        if(feature_type == "user"):
            resList = self.generate_model_data_linear_user_item_feature_of_user(user_id, event_id)
        elif(feature_type == "event"):
            resList = self.generate_model_data_linear_user_item_feature_of_event(user_id, event_id)
        elif(feature_type == "group"):
            resList = self.generate_model_data_linear_user_item_feature_of_group(user_id, event_id)
        elif(feature_type == "social"):
            resList = self.generate_model_data_linear_user_item_feature_of_social( user_id, event_id)
        elif(feature_type == "location"):
            resList = self.generate_model_data_linear_user_item_feature_of_location(user_id, event_id)
        elif(feature_type == "time"):
            resList = self.generate_model_data_linear_user_item_feature_of_time(user_id, event_id)
        elif(feature_type == "content"):
             resList = self.generate_model_data_linear_user_item_feature_of_content(user_id, event_id)
        elif(feature_type == "social"):
            resList = self.generate_model_data_linear_user_item_feature_of_social(user_id, event_id)
        return resList

    def generate_model_data_linear_user_item_feature_of_user(self, user_id, event_id):
        return ParseUser.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)


    def generate_model_data_linear_user_item_feature_of_event(self, user_id, event_id):
        return ParseEvent.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)


    def generate_model_data_linear_user_item_feature_of_group(self, user_id, event_id):
        return ParseGroup.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)

    def generate_model_data_linear_user_item_feature_of_social(self, user_id, event_id):
        return ParseSocial.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)

    def generate_model_data_linear_user_item_feature_of_location(self, user_id, event_id):
        return ParseLocation.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)

    def generate_model_data_linear_user_item_feature_of_time(self, user_id, event_id):
        return ParseTime.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)

    def generate_model_data_linear_user_item_feature_of_content(self, user_id, event_id):
        return ParseContent.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)

    def generate_model_data_linear_user_item_feature_of_social(self, user_id, event_id):
        return ParseSocial.generate_feature(user_id, event_id, self.ebsnData, self.dataLinear)

