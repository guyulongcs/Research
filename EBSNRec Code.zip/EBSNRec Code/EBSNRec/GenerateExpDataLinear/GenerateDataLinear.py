from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from Init import *
from Parse import *
from DataLinear import *
from Init import *
from Parse import *

class GenerateExpDataLinear():
    def __init__(self, data, ebsnData):
        self.data = data
        self.ebsnData = ebsnData
        self.dataLinear = DataLinear()
        self.dict_linear_feature = None

    def generate_data_linear(self):
        InOut.console_func_begin("generate_data_linear")
        self.generate_data_linear_init()
        self.generate_data_linear_parse()
        return self.dict_linear_feature

    def generate_data_linear_init(self):
        InOut.console_func_begin("generate_data_linear_init")
        init = Init(self.data, self.ebsnData)
        self.dataLinear = init.init_process()
        pass

    def generate_data_linear_parse(self):
        InOut.console_func_begin("generate_data_linear_parse")
        parse = Parse(self.data, self.ebsnData, self.dataLinear)
        self.dict_linear_feature = parse.parse_process()

    @classmethod
    def parse_linear_data_with_feature_list(cls, dataLinear, featureList):

        pass


    @classmethod
    def has_feature_user(cls):
        return "user" in Config.p_linear_feature_type_list

    @classmethod
    def has_feature_content(cls):
        return "content" in Config.p_linear_feature_type_list

    @classmethod
    def has_feature_event(cls):
        return "event" in Config.p_linear_feature_type_list

    @classmethod
    def has_feature_group(cls):
        return "group" in Config.p_linear_feature_type_list


    @classmethod
    def has_feature_location(cls):
        return "location" in Config.p_linear_feature_type_list

    @classmethod
    def has_feature_time(cls):
        return "time" in Config.p_linear_feature_type_list
