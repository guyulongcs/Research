from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from InitEvent import *
from DataLinear import *
from ParseLocation import *

class InitLocation():
    def __init__(self):

        pass

    @classmethod
    def get_dict_feature_userid_eventid(cls, data, ebsnData, dataLinear):
        R = data._ratingList_complete

        dict_userid_eventid_dis = {}
        dict_userid_eventid_pastEventDis = {}

        i = 0
        N = len(R)
        for rating in R:
            user_id = rating[0]
            event_id = rating[1]
            rate = rating[2]
            #if(user_id not in data._userSet):
            #    continue
            #if(Data.IsItemPositive(rate) == False):
            #    continue

            has_attend_event_list = dataLinear.get_hasAttendEventidList(user_id, event_id)

            dis = ParseLocation.get_feature_user_event_dis(user_id, event_id, ebsnData)
            pastEvent_dis = ParseLocation.get_feature_user_event_pastEvent_dis(event_id, has_attend_event_list, ebsnData, dataLinear)


            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_dis, user_id, event_id, dis)
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_pastEventDis, user_id, event_id, pastEvent_dis)

            i+=1
            if(i% 100 == 0):
                print "\ninitLocation"
                print "%d / %d" % (i, N)
                print "\nuser_id:%s, event_id:%s" % (user_id, event_id)
                print "\ndis:%f, pastEvent_dis:%f" % (dis, pastEvent_dis)

        return (dict_userid_eventid_dis, dict_userid_eventid_pastEventDis)


