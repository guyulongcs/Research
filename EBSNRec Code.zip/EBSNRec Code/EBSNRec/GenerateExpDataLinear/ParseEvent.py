from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from DataLinear import *



class ParseEvent():
    def __init__(self):
        pass

    @classmethod
    def generate_feature(cls, user_id, event_id, ebsnData, dataLinear):
        InOut.console_func_begin("ParseEvent")
        InOut.console_func_begin("generate_feature")
        resList = []

        #past_eventid_list = EBSNData.get_past_eventid_list(event_id, ebsnData)
        #past_eventid_content_sim_list = ParseEvent.cal_event_eventlist_sim_content(event_id, past_eventid_list, dataLinear.dict_content_eventId_vec_tfidf)
        #past_eventid_list_after_sim_filter = ParseEvent.filt_eventid_by_content_sim(past_eventid_list, past_eventid_content_sim_list )

        simEventCnt = dataLinear.dict_userid_eventid_simEventCnt[user_id][event_id]
        hasRsvpCnt = dataLinear.dict_userid_eventid_hasRsvpCnt[user_id][event_id]
        rsvpCnt = ParseEvent.get_event_rsvp_cnt(event_id, ebsnData)

        resList = [simEventCnt, hasRsvpCnt, rsvpCnt]

        print "eventFeature:", resList
        return resList


    @classmethod
    def get_event_rsvp_cnt(cls, event_id, ebsnData):
        event = ebsnData.dictEvent[event_id]
        cnt = max(event.rsvp_limit, event.headCount)

        return cnt


    @classmethod
    def filt_eventid_by_content_sim(cls, event_list, sim_list):
        InOut.console_func_begin("filt_eventid_by_content_sim")
        resList = []
        for i in xrange(len(event_list)):
            sim = sim_list[i]
            print "sim:", sim
            if(ParseEvent.is_eventsim_great_threshold(sim)):
                resList.append(event_list[i])
        return resList

        pass

    @classmethod
    def is_eventsim_great_threshold(cls, sim):
        res = sim > Config.p_linear_event_similar_content_threshold
        return res

    @classmethod
    def cal_event_eventlist_sim_content(cls, event_id, eventid_list, dict_content_eventId_vec_tfidf):
        resList = []
        for e in eventid_list:
            sim = ParseEvent.cal_event_event_sim_content(event_id, e, dict_content_eventId_vec_tfidf)
            resList.append(sim)
        return resList

    @classmethod
    def cal_event_event_sim_content(cls, eventid1, eventid2, dict_content_eventId_vec_tfidf):
        v1 = dict_content_eventId_vec_tfidf[eventid1]
        v2 = dict_content_eventId_vec_tfidf[eventid2]
        res = Content.cal_item_similarity_cos(v1, v2)
        return res

    @classmethod
    def get_userid_hasattend_eventid_list(cls, user_id, event_id, ebsnData, dataLinear):
        eventid_list = []
        for eventid in dataLinear.dict_userid_eventid_rsvpid[user_id]:
            flag =  Event.happenBefore(ebsnData.dictEvent[eventid], ebsnData.dictEvent[event_id])
            if(flag == False):
                continue
            eventid_list.append(event_id)
        return eventid_list

