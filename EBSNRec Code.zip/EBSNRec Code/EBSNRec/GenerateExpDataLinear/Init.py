from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from InitTime import *
from InitLocation import *
from InitGroup import *
from InitBase import *
from InitSocial import *

from DataLinear import *

from InitUser import *
from InitContent import *
from InitRsvp import *




class Init():
    def __init__(self, data, ebsnData):
        self.data = data
        self.ebsnData = ebsnData
        self.dataLinear = DataLinear()
        pass

    def init_process(self):
        InOut.console_func_begin("init_process")
        self.init()
        self.dataLinear.printInfo()
        return self.dataLinear

    def init(self):
        InOut.console_func_begin("init")

        self.init_base()

        for feature_type in Config.p_linear_feature_type_list:
            self.init_feature_type(feature_type)


        InOut.console_func_end("init")

    def init_feature_type(self, feature):
        if(feature == "user"):
            self.init_user()
        if(feature == "content"):
            self.init_content()
        if(feature == "event"):
            self.init_event()
        if(feature == "group"):
            self.init_group()
        if(feature == "location"):
            self.init_location()
        if(feature == "time"):
            self.init_time()
        if(feature == "social"):
            self.init_social()


    def init_user(self):
        InOut.console_func_begin("init_user")
        (self.dataLinear.dict_userid_eventid_hasAttendCnt, self.dataLinear.dict_userid_eventidGroupid_hasAttendCnt) = InitUser.get_dict_feature_userid_eventid(self.data, self.ebsnData, self.dataLinear)

        pass

    def init_location(self):
        InOut.console_func_begin("init_location")
        (self.dataLinear.dict_userid_eventid_dis, self.dataLinear.dict_userid_eventid_pastEventDis) = InitLocation.get_dict_feature_userid_eventid(self.data, self.ebsnData, self.dataLinear)

    def init_content(self):
        InOut.console_func_begin("init_content")
        self.dataLinear.dict_userid_eventid_content_sim = InitContent.get_dict_feature_userid_eventid(self.data, self.dataLinear)
        pass

    def init_rsvp(self):
        InOut.console_func_begin("init_rsvp")
        self.dataLinear.dict_userid_eventid_rsvpid = InitRsvp.init(self.data, self.ebsnData)

    def init_time(self):
        InOut.console_func_begin("init_time")
        (self.dataLinear.dict_userid_eventid_time_sim) = InitTime.get_dict_feature_userid_eventid(self.data, self.ebsnData, self.dataLinear)

    def init_event(self):
        InOut.console_func_begin("init_event")
        (self.dataLinear.dict_userid_eventid_simEventCnt, self.dataLinear.dict_userid_eventid_hasRsvpCnt) = InitEvent.get_dict_feature_userid_eventid(self.data, self.ebsnData, self.dataLinear)

    def init_group(self):
        InOut.console_func_begin("init_group")
        (self.dataLinear.dict_userid_eventid_group_sim) = InitGroup.get_dict_feature_userid_eventid(self.data, self.ebsnData, self.dataLinear)

    def init_social(self):
        InOut.console_func_begin("init_social")
        (self.dataLinear.dict_userid_eventid_onFriendHasRsvpCnt, self.dataLinear.dict_userid_eventid_offFriendHasRsvpCnt) = InitSocial.get_dict_feature_userid_eventid(self.data, self.ebsnData, self.dataLinear)


    def init_base(self):
        self.dataLinear = InitBase.init(self.data, self.ebsnData)


