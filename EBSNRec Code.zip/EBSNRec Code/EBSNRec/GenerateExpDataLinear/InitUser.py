from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from InitEvent import *
from DataLinear import *

class InitUser():
    def __init__(self):

        pass

    @classmethod
    def get_dict_feature_userid_eventid(cls, data, ebsnData, dataLinear):
        print "InitUser get_dict_feature_userid_eventid..."
        R = data._ratingList_complete

        dict_userid_eventid_hasAttendCnt = {}
        dict_userid_eventidGroupid_hasAttendCnt = {}
        for rating in R:
            user_id = rating[0]
            event_id = rating[1]
            rate = rating[2]
            #if(user_id not in data._userSet):
            #    continue
            #if(Data.IsItemPositive(rate) == False):
            #    continue
            eventidGroupid = ebsnData.dictEventGroup[event_id]

            has_attend_event_list = dataLinear.get_hasAttendEventidList(user_id, event_id)

            has_attend_group_list = InitEvent.eventlist_2_grouplist(has_attend_event_list, ebsnData)

            eventidGroupid_hasAttendCnt = TypeProcessTool.cal_list_has_str_cnt(has_attend_group_list, eventidGroupid)

            # print "\nhas_attend_event_list:", has_attend_event_list
            # print "eventidGroupid:", eventidGroupid
            # print "has_attend_group_list:", has_attend_group_list
            # print "eventidGroupid_hasAttendCnt:", eventidGroupid_hasAttendCnt

            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_hasAttendCnt, user_id, event_id, len(has_attend_event_list))
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventidGroupid_hasAttendCnt, user_id, event_id, eventidGroupid_hasAttendCnt)

        return (dict_userid_eventid_hasAttendCnt, dict_userid_eventidGroupid_hasAttendCnt)


    # @classmethod
    # def trans_dict_user_eventlist_2_dict_user_event_group_cnt(cls, dictUserEventList, ebsnData):
    #     dict_user_eventGroup_cnt = {}
    #     for (user, eventlist) in dictUserEventList.items():
    #
    #         grouplist = InitEvent.eventlist_2_grouplist(eventlist, ebsnData)
    #         #print "eventList"
    #         #print eventlist
    #         #print "groupList", grouplist
    #
    #         TypeProcessTool.dictStrStrInt_add_str_liststr(dict_user_eventGroup_cnt, user, grouplist)
    #
    #     return dict_user_eventGroup_cnt
    #     pass



