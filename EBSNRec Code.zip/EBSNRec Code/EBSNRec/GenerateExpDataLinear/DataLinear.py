from Tool.TypeTool.TypeProcessTool import *
from Config import *
import numpy as np

class DataLinear():
    def __init__(self):
        #user
        self.dict_userid_eventid_hasAttendCnt = {}
        self.dict_userid_eventidGroupid_hasAttendCnt = {}

        #content
        self.dict_content_eventid_vec_tfidf = {}
        self.dict_userid_eventid_content_sim = {}

        #rsvp
        self.dict_userid_eventid_rsvpid = {}
        self.dict_eventid_userid_rsvpid = {}

        #hasAttend
        self.dict_userid_eventid_hasAttendEventidList={}

        #location
        self.dict_userid_eventid_dis={}
        self.dict_userid_eventid_pastEventDis={}

        #time
        self.dict_userid_eventid_time_sim={}

        #group
        self.dict_userid_eventid_group_sim = {}

        #social
        self.dict_userid_eventid_onFriendHasRsvpCnt = {}
        self.dict_userid_eventid_offFriendHasRsvpCnt = {}

        pass


    def printInfo(self):
        print "dataLinear:"
        print "dict_userid_eventid_hasAttendCnt:", len(self.dict_userid_eventid_hasAttendCnt)
        print "dict_userid_eventidGroupid_hasAttendCnt:", len(self.dict_userid_eventidGroupid_hasAttendCnt)

        #content
        print "dict_content_eventid_vec_tfidf:", len(self.dict_content_eventid_vec_tfidf)
        print "dict_userid_eventid_content_sim:", len(self.dict_userid_eventid_content_sim)

        print "dict_userid_eventid_rsvpid:", len(self.dict_userid_eventid_rsvpid)


        print "dict_userid_eventid_time_sim:", len(self.dict_userid_eventid_time_sim)

        print "dict_userid_eventid_hasAttendEventidList:", len(self.dict_userid_eventid_hasAttendEventidList)

    def get_hasAttendEventidList(self, user_id, event_id):
        res = TypeProcessTool.get_dictstrstrlist(self.dict_userid_eventid_hasAttendEventidList, user_id, event_id)
        return res

    @classmethod
    def get_linear_valid_index_list(cls, typeList):
        #print "get_linear_valid_index_list"
        #print "typeList:", typeList
        res = []

        i = 0
        for type in Config.p_linear_feature_type_list:
            cnt = Config.p_linear_feature_dictTypeCnt[type]
            indexList = range(i, i+cnt)
            if(type in typeList):
                res.extend(indexList)
            i += cnt

        #print "res:", res

        return res
