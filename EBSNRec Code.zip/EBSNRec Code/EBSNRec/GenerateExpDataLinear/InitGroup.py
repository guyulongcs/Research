from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *
from InitEvent import *
from DataLinear import *
from ParseLocation import *
from EBSN.Content import *
from ParseGroup import *

class InitGroup():
    def __init__(self):
        pass

    @classmethod
    def get_dict_feature_userid_eventid(cls, data, ebsnData, dataLinear):
        R = data._ratingList_complete

        dict_userid_eventid_group_sim = {}


        i=0
        N = len(R)
        for rating in R:
            user_id = rating[0]
            event_id = rating[1]
            rate = rating[2]
            #if(user_id not in data._userSet):
            #    continue
            #if(Data.IsItemPositive(rate) == False):
            #    continue

            has_attend_event_list = dataLinear.get_hasAttendEventidList(user_id, event_id)

            simGroup = ParseGroup.get_user_event_feature_content_group(user_id, event_id, has_attend_event_list, ebsnData, dataLinear)

            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_group_sim, user_id, event_id, simGroup)

            i+=1
            if(i % 100 == 0):
                print "\ninitGroup"
                print "%d / %d" % (i, N)
                print "\nuser_id:%s, event_id:%s" % (user_id, event_id)
                print "\nsimGroup:%f" % (simGroup)
                #break

        return (dict_userid_eventid_group_sim)
        pass