from Config import *
from EBSN.Group import *
from EBSN.Event import *
from EBSN.RSVP import *
from Tool.StringTool import *
from Tool.MatrixTool.Matrix import *
from Tool.MatrixTool.SparseMatrix import *
from Tool.TypeTool.TypeProcessTool import *
from RecSys.Datamodel.rating import *
from RecSys.Datamodel.data import *
from Tool.MathTool.MathTool import *
from AnalyseEBSNData import *

class InitRsvp():
    def __init__(self):

        pass


    @classmethod
    def get_dict_userid_eventid_rsvpid(cls, data, ebsnData):
        InOut.console_func_begin("get_dict_userid_eventid_rsvpid")
        dict_userid_eventid_rsvpid = {}
        for rsvp_id in ebsnData.dictRsvp:
            rsvp = ebsnData.dictRsvp[rsvp_id]
            userid = rsvp.user_id
            eventid = rsvp.event_id
            if((userid not in data._userSet) or (eventid not in data._itemSet)):
                continue
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_rsvpid, userid, eventid, rsvp_id)
        return dict_userid_eventid_rsvpid
        pass

    @classmethod
    def get_dict_bi_userid_eventid_rsvpid(cls, data, ebsnData):
        InOut.console_func_begin("get_dict_bi_userid_eventid_rsvpid")
        dict_userid_eventid_rsvpid = {}
        dict_eventid_userid_rsvpid = {}
        for rsvp_id in ebsnData.dictRsvp:
            rsvp = ebsnData.dictRsvp[rsvp_id]
            userid = rsvp.user_id
            eventid = rsvp.event_id
            if((userid not in data._userSet) or (eventid not in data._itemSet)):
                continue
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_rsvpid, userid, eventid, rsvp_id)
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_eventid_userid_rsvpid, eventid, userid, rsvp_id)
        return (dict_userid_eventid_rsvpid, dict_eventid_userid_rsvpid)
        pass

    @classmethod
    def get_dict_userid_eventid_hasAttendEventidList(cls, data, ebsnData, dataLinear):
        InOut.console_func_begin("get_dict_userid_eventid_hasAttendEventidList")
        dict_userid_eventid_hasAttendEventidList = {}
        ratingList = data._ratingList_complete
        for i in xrange(len(ratingList)):
            ratingItem = ratingList[i]
            user_id = ratingItem[0]
            event_id = ratingItem[1]
            hasAttendEventidList = InitRsvp.get_userid_eventid_hasattend_eventid_list(user_id, event_id, ebsnData, dataLinear)
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_hasAttendEventidList, user_id, event_id, hasAttendEventidList)

        return dict_userid_eventid_hasAttendEventidList

        pass


    @classmethod
    def get_dict_userid_eventid_hasAttendFriendCnt(cls, data, ebsnData, dataLinear):
        InOut.console_func_begin("get_dict_userid_eventid_hasAttendFriendCnt")
        dict_userid_eventid_hasAttendOnFriendCnt = {}
        dict_userid_eventid_hasAttendOffFriendCnt = {}

        ratingList = data._ratingList_complete
        for i in xrange(len(ratingList)):
            ratingItem = ratingList[i]
            user_id = ratingItem[0]
            event_id = ratingItem[1]

            (hasAttendOnFriendCnt, hasAttendOffFriendCnt) = InitRsvp.get_userid_eventid_hasAttendFriendCnt(user_id, event_id, data, ebsnData, dataLinear)
            print ">>on:%d, off:%d" % (hasAttendOnFriendCnt, hasAttendOffFriendCnt)
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_hasAttendOnFriendCnt, user_id, event_id, hasAttendOnFriendCnt)
            TypeProcessTool.dictStrDictStrValue_add_str_str_str(dict_userid_eventid_hasAttendOffFriendCnt, user_id, event_id, hasAttendOffFriendCnt)

        return (dict_userid_eventid_hasAttendOnFriendCnt, dict_userid_eventid_hasAttendOffFriendCnt)

    @classmethod
    def get_userid_eventid_hasAttendFriendCnt(cls, user_id, event_id, data, ebsnData, dataLinear):
        onFriendCnt = 0
        offFriendCnt = 0

        (onFriendSet, offFriendSet) = data.get_friend_set(user_id)

        if(event_id in dataLinear.dict_eventid_userid_rsvpid):

            if(user_id not in dataLinear.dict_eventid_userid_rsvpid[event_id]):
                print "**not In"
                print len(dataLinear.dict_eventid_userid_rsvpid[event_id].keys())
                return (onFriendCnt, offFriendCnt)
            user_rsvp_id = dataLinear.dict_eventid_userid_rsvpid[event_id][user_id]
            for u_id in dataLinear.dict_eventid_userid_rsvpid[event_id]:
                #on
                if(u_id in onFriendSet):
                    u_rsvp_id = dataLinear.dict_eventid_userid_rsvpid[event_id][u_id]
                    if(RSVP.happenBefore(ebsnData.dictRsvp[u_rsvp_id], ebsnData.dictRsvp[user_rsvp_id])):
                        onFriendCnt += 1
                #off
                if(u_id in offFriendSet):
                    u_rsvp_id = dataLinear.dict_eventid_userid_rsvpid[event_id][u_id]
                    if(RSVP.happenBefore(ebsnData.dictRsvp[u_rsvp_id], ebsnData.dictRsvp[user_rsvp_id])):
                        offFriendCnt += 1

        return (onFriendCnt, offFriendCnt)
        pass


    @classmethod
    def get_userid_eventid_hasattend_eventid_list(cls, user_id, event_id, ebsnData, dataLinear):
        eventid_list = []
        for rsvp_eventid in dataLinear.dict_userid_eventid_rsvpid[user_id]:
            if(event_id not in ebsnData.dictEvent):
                continue
            if(rsvp_eventid not in ebsnData.dictEvent):
                continue
            rsvp_event = ebsnData.dictEvent[rsvp_eventid]
            cur_event = ebsnData.dictEvent[event_id]

            flag =  Event.happenBefore(rsvp_event, cur_event)
            if(flag == False):
                continue
            eventid_list.append(rsvp_eventid)
        return eventid_list
