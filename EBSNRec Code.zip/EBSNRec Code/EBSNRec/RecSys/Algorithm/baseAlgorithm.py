from RecSys.Datamodel.data import *

from Tool.MatrixTool.SparseMatrix import *

class BaseAlgorithm():
    def __init__(self):
        #self._data = Data()
        #self._matrix = SparseMatrix()
        pass

