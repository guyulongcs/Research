from scipy.sparse import *
import numpy as np
from numpy import linalg as LA
from sklearn.decomposition import NMF
from sklearn.utils.validation import *
from Tool.InOutTool.InOutTool import *
from RecSys.Algorithm.baseAlgorithm import *
from Tool.TypeTool.TypeProcessTool import *
from MatrixFactorization import *

import warnings

from Tool.InOutTool.InOutTool import *

class BPRMatrixFactorization():
    def __init__(self):
        self.log_detail_list = []
        pass

    def matrix_factor(self, X, U=None, V=None, n_components=None,
                               init='random', solver='gd',
                               tol=1e-4, max_iter=200, alpha=0.01, lamda_u=0, lamda_v=0,
                               regularization=None, random_state=None, mf_train_only_positive = True):
        InOut.console_func_begin("BPRMatrixFactorization matrix_factor")
        if init == None:
            init = 'random'

        if init == 'random':
            U, V = MatrixFactorization.mf_init(X, n_components, init=init, random_state=random_state)
        else:
            raise ValueError("Invalid init parameter '%s'." % init)


        if solver == 'gd':
            U, V, n_iter = self.mf_gradient_desenct(X, U, V, tol, max_iter, alpha, lamda_u, lamda_v, mf_train_only_positive)
        else:
            raise ValueError("Invalid solver parameter '%s'." % solver)

        if n_iter == max_iter:
            warnings.warn("Maximum number of iteration %d reached." % max_iter)

        return U, V, n_iter
        pass



    def mf_gradient_desenct(self, R, U, V, tol, max_iter, alpha, lamda_u, lamda_v, mf_train_only_positive):
        InOut.console_func_begin("mf_gradient_desenct")
        n_iter = 0


        for step in xrange(max_iter):


            process_cnt = 0

            N = len(U)
            for row in xrange(N):
                process_cnt += 1
                #row = rowIndex[index]
                #col = colIndex[index]

                posCols = find(R[row] > 0)[1]
                negCols = find(R[row] < 0)[1]

                posColCnt = len(posCols)
                negColCnt = len(negCols)

                if(posColCnt == 0 or negColCnt == 0):
                    continue

                (posColList, negColList) = self.samplePosNegCols(posCols, negCols)

                for posCol in posCols:
                    for negCol in negCols:
                        #update
                        rateDiff = BPRMatrixFactorization.cal_rate_diff(U, V, row, posCol, negCol)
                        weight = 1 - Math.sigmoid(rateDiff)

                        coef=1
                        coef = -1
                        coef_alpha=1
                        U[row] += coef_alpha * alpha * (weight * (V[posCol] - V[negCol]) + coef * lamda_u * U[row])
                        V[posCol] += coef_alpha * alpha * (weight * U[row] + coef * lamda_v * V[posCol])
                        V[negCol] += coef_alpha * alpha * (weight * (-U[row]) + coef * lamda_v * V[negCol])

                        #print "processCnt:%d/%d, row:%d, posCol:%d, negCol:%d" % (process_cnt, N, row, posCol, negCol)

                if(process_cnt % 1000 == 0):
                    cost = 0
                    print "\nstep:%d, process_cnt:%d/%d" % (step, process_cnt, N)
                    #print "\nstep:%d, process_cnt:%d, cost:%f" % (step, process_cnt, cost)
                    pass

            #


            n_iter += 1

            if(n_iter % 10 != 0):
                continue

            cost = BPRMatrixFactorization.mf_cal_cost(R, U, V, lamda_u, lamda_v)

            log_str = "\nstep:%d, cost:%f" % (step+1, cost)
            self.log_detail_list.append(log_str)

            print log_str

            if(cost < tol):
                #break
                pass



        return U, V, n_iter
        pass

    def samplePosNegCols(self, posCols, negCols):
        posColList = []
        negColList = []

        posN = len(posCols)
        negN = len(negCols)

        maxCnt = posN * negN

        maxCntThreshold = Config.BPR_sample_PosNegCol_MaxCnt
        if (maxCnt > maxCntThreshold):
            maxCnt = max(maxCntThreshold, maxCnt / 10)

        posColIndexList = np.random.randint(0, posN, maxCnt)
        negColIndexList = np.random.randint(0, negN, maxCnt)

        posColList = posCols[posColIndexList]
        negColList = negCols[negColIndexList]

        return (posColList, negColList)

    @classmethod
    def cal_rate_diff(cls, U, V, row, posCol, negCol):
        rpos = MatrixFactorization.predict(U[row], V[posCol])
        rneg = MatrixFactorization.predict(U[row], V[negCol])
        diff = rpos - rneg

        return diff


    @classmethod
    def mf_cal_cost(self, R, U, V, lamda_u, lamda_v):
        InOut.console_func_begin("mf_cal_cost")
        J = 0
        J1 = self.mf_cal_se(R, U, V)

        coef = -1
        J2 = lamda_u * LA.norm(U) + lamda_v * LA.norm(V)

        J = J1 + coef * J2
        return J


    @classmethod
    def cal_reconstruction_err(cls, X, W, H):
        InOut.console_func_begin("cal_reconstruction_err")
        res = MatrixFactorization.mf_cal_se(X, W, H)
        return res


    @classmethod
    def mf_cal_se(cls, R, U, V):
        InOut.console_func_begin("mf_cal_se")
        (rowIndex, colIndex) = SparseMatrix.FindSparseMatrixNZ(R)

        process_cnt = 0

        predictCnt = 0
        predictPosCnt = 0

        sum = 0
        N = len(U)
        for row in xrange(N):
            process_cnt += 1
            posCols = find(R[row] > 0)[1]
            negCols = find(R[row] < 0)[1]

            posColCnt = len(posCols)
            negColCnt = len(negCols)

            if(posColCnt == 0 or negColCnt == 0):
                continue

            cur = 0
            for posCol in posCols:
                for negCol in negCols:
                    predictCnt += 1
                    #update
                    rateDiff = BPRMatrixFactorization.cal_rate_diff(U, V, row, posCol, negCol)

                    if(rateDiff > 0):
                        predictPosCnt += 1

                    rateDiff = Math.sigmoid(rateDiff)
                    rateDiff = Math.log(rateDiff)
                    cur += rateDiff

            #add
            sum += cur

            if(process_cnt % 1000 == 0):

                #print "\nmf_cal_se: process_cnt:%d/%d" % (process_cnt, N)
                pass

        InOut.console_func_end("mf_cal_se")

        ratio = Math.divide(predictPosCnt, predictCnt)

        #return ratio

        return sum



    @classmethod
    def mf_cal_rsme_from_re_nnz(cls, re, nnz):
        se = re
        return MatrixFactorization.mf_cal_rsme_from_se_nnz(se, nnz)

    @classmethod
    def mf_cal_rsme_from_se_nnz(cls, se, nnz):
        rsme = np.sqrt(se / nnz)
        return rsme

    # def mf_cal_rsme(self, X, W, H):
    #     se = self.mf_cal_se(X, W, H)
    #     N = X.nnz
    #     rsme = np.sqrt(se / N)
    #     return rsme
    #

    def get_log_detail_list(self):
        return self.log_detail_list


