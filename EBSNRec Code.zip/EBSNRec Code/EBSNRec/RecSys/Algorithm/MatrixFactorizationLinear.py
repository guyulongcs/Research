from scipy.sparse import *
import numpy as np
from numpy import linalg as LA
from sklearn.decomposition import NMF
from sklearn.utils.validation import *
from Tool.InOutTool.InOutTool import *
from RecSys.Algorithm.baseAlgorithm import *

import warnings

from Tool.InOutTool.InOutTool import *
from MatrixFactorization import *

class MatrixFactorizationLinear():
    def __init__(self):

        self.log_detail_list = []
        pass

    def matrix_factor(self, R, Rlinear=None,R_linear_valid_index_list=None, UserWeight = None, U=None, V=None, Theta=None, n_components=None, n_linear_feature=None,
                               init='random', solver='gd',
                               tol=1e-4, max_iter=200, batch_size= 50,
                                alpha=0.01, w_mf=0.5, w_linear=0.5,
                                lamda_u=0., lamda_v=0, lamda_theta=0.,
                               regularization=None, random_state=None, mf_func = 'None', linear_func="Linear", mf_user_reg=False, lamda_user_reg=0., mf_train_only_positive = True):
        '''
        R = UV^T

        The objective function is::
         0.5 + ||R - UV^T||_Fro^2
        + 0.5 * lamda_u * * ||U||_Fro^2
        + 0.5 * lamda_v * * ||V||_Fro^2
        :param R:
        :param U:
        :param V:
        :param n_components: K
        :param init: None | 'random'
            - 'random':
                sqrt(R.mean() / n_components)
        :param update_H:
        :param solver: 'gd'
            'gd' is a Gradient Descent solver
        :param tol: float, default: 1e-4
            Tolerance of the stopping condition.
        :param max_iter:    integer, default: 200
             Maximum number of iterations before timing out.
        :param alpha: double, default = 0.001
            learning rate
        :param w_mf: double, default = 0.001
            weight of mf
        :param w_linear: double, default = 0.001
            weight of linear
        :param lamda_u: double, default: 0.
            Constant that multiplies the regularization terms.
        :param lamda_v: double, default: 0.
            Constant that multiplies the regularization terms.
        :param lamda_theta: double, default: 0.
            Constant that multiplies the regularization terms.

        :param regularization: 'both' | 'U' | 'V' | None
             Select whether the regularization
        :param random_state: integer seed, RandomState instance, or None (default)
             Random number generator seed control.
        :param linear_func: 'Linear' | 'Sigmoid'

        :return:
        U
        V
        n_iter : int
            Actual number of iterations.
        '''
        n_linear_feature = self.get_n_linear_feature(n_linear_feature, R_linear_valid_index_list)

        InOut.console_func_begin("MatrixFactorizationLinear matrix_factor")
        print "w_mf:", w_mf
        print "w_linear:", w_linear
        init_method = ""
        if init == None:
            init = 'random'
        if init == 'random':
            U, V, Theta = self.mf_init(R, n_components, n_linear_feature, init=init, random_state=random_state)
        else:
            raise ValueError("Invalid init parameter '%s'." % init)

        if solver == 'gd':
            U, V, Theta, n_iter = self.mf_gradient_desenct( R, Rlinear,R_linear_valid_index_list, U, V, Theta, tol, max_iter, batch_size, alpha, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func, mf_user_reg, UserWeight, lamda_user_reg, mf_train_only_positive)
        else:
            raise ValueError("Invalid solver parameter '%s'." % solver)

        if n_iter == max_iter:
            warnings.warn("Maximum number of iteration %d reached." % max_iter)

        return U, V, Theta, n_iter
        pass

    def mf_init(self, R,  n_components, n_linear_feature, init=None, random_state=None):
        '''
        R=UV^T
        :param R:
        :param n_components:
        :param init:
        :param random_state:

        :return:
        U
        V
        '''
        n_users, n_items = R.shape
        if init is None:
            init = 'random'

        if init == 'random':
            rng = check_random_state(random_state)
            print "R mean:", R.mean()
            print "component:", n_components
            avg = np.sqrt(np.abs(R.mean()) / n_components)
            #avg = R.mean()

            U = avg * rng.randn(n_users, n_components)
            V = avg * rng.randn(n_items, n_components)

            avg2 = R.mean()
            Theta = avg2 * rng.randn(n_linear_feature)

            #np.abs(U, U)
            #np.abs(V, V)

            print "U:", U, U.shape
            print "V:", V, V.shape
            print "Theta:", Theta.shape

            return U, V, Theta


        pass

    def mf_is_rating_valid(self, v):
        flag = False
        if(v > 0):
            flag = True
        return flag

    def mf_gradient_desenct(self, R, Rlinear,R_linear_valid_index_list, U, V, Theta, tol, max_iter, batch_size, alpha, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func, mf_user_reg, UserWeight, lamda_user_reg, mf_train_only_positive):
        return self.mf_gradient_desenct_batch(R, Rlinear, R_linear_valid_index_list, U, V, Theta, tol, max_iter, batch_size,  alpha, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func, mf_user_reg, UserWeight, lamda_user_reg, mf_train_only_positive)
        #return self.mf_gradient_desenct2(R, U, V, tol, max_iter, alpha, lamda_u, lamda_v)

    @classmethod
    def is_linear_func_simoid(cls, linear_func='Linear'):
        return linear_func == "Sigmoid"

    @classmethod
    def is_linear_func_none(cls, linear_func='Linear'):
        return linear_func == "None"

    @classmethod
    def is_mf_func_sigmoid(cls, mf_func='None'):
        return (mf_func == Config.p_mf_func_list[1])

    @classmethod
    def cal_linear_value(cls, w, R, linear_func):
        res = np.dot(w, R)
        if(MatrixFactorizationLinear.is_linear_func_simoid(linear_func)):
            res = Math.sigmoid(res)

        return res

    def predict_l(self, vu, vv, w, R, R_linear_valid_index_list,  w_mf, w_linear, mf_func, linear_func, flagPrint=False, flagTag=""):
        R = self.get_linear_data(R, R_linear_valid_index_list)
        return self.predict(vu, vv, w, R, w_mf, w_linear, mf_func, linear_func, flagPrint, flagTag)

    def predict(self, vu, vv, w, R, w_mf, w_linear, mf_func, linear_func, flagPrint=False, flagTag=""):
        #InOut.console_func_begin("predict")

        p  = 0
        p_mf = 0
        p_linear = 0
        if(MatrixFactorizationLinear.is_mf_valid(w_mf)):
            p_mf = np.dot(vu, vv)

            if(MatrixFactorizationLinear.is_mf_func_sigmoid(mf_func)):
                p_mf = Math.sigmoid(p_mf)

            p += w_mf * p_mf

        if(MatrixFactorizationLinear.is_linear_func_none(linear_func) == False):
            p_linear = MatrixFactorizationLinear.cal_linear_value(w, R, linear_func)
            p += w_linear * p_linear

        if(flagPrint):
            print "\n"
            print flagTag
            print "vu:", vu
            print "vv:", vv
            print "w:", w
            print "R:", R

            print "p_mf:", p_mf
            print "p_linear", p_linear
            print "p:", p
        return p


    def get_batch_data(self, R, batch_size, mf_train_only_positive):
        print "batch_size:", batch_size
        (rowIndex, colIndex, valueList) = SparseMatrix.FindSparseMatrixNZRowColValue(R)
        batch_data = []
        cnt = 0
        batch = []
        for index in xrange(len(rowIndex)):
            row = rowIndex[index]
            col = colIndex[index]
            value = valueList[index]
            instance = [row, col, value]


            if(mf_train_only_positive and (self.mf_is_rating_valid(R[row, col]) == False)):
                continue
                pass

            batch.append(instance)
            cnt += 1
            if(cnt >= batch_size):
                batch_data.append(batch)
                cnt = 0
                batch = []
        if(len(batch) > 0):
            batch_data.append(batch)

        return batch_data


    def get_linear_data(self, linearData, R_linear_valid_index_list):

        res = linearData
        #print "R_linear_valid_index_list:", R_linear_valid_index_list
        if(R_linear_valid_index_list is not None):
            N = len(R_linear_valid_index_list)
            if(N > 0):
                res = linearData[R_linear_valid_index_list]

        #print "\nget_linear_data..."
        #print "linearData:", linearData
        #print "res:", res

        return res
        pass

    def get_n_linear_feature(self, n_linear_feature, R_linear_valid_index_list):
        res = n_linear_feature
        if(R_linear_valid_index_list is not None):
            N = len(R_linear_valid_index_list)
            if(N > 0):
                res = N
        return res

        pass
    def mf_gradient_desenct_batch(self, R, Rlinear,R_linear_valid_index_list,  U, V, Theta, tol, max_iter, batch_size, alpha, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func, mf_user_reg, UserWeight, lamda_user_reg, mf_train_only_positive):
        InOut.console_func_begin("mf_gradient_desenct_batch")
        n_iter = 0

        np.seterr(all='raise')

        [userCnt, components_cnt] = U.shape
        batch_data = self.get_batch_data(R, batch_size, mf_train_only_positive)

        batch_total_cnt = len(batch_data)

        linear_feature_cnt = len(Theta)

        flagMFValid = self.is_mf_valid(w_mf)
        flagLinearValid = self.is_linear_valid(w_linear)

        stepCostList = []
        for step in xrange(max_iter):
            process_num = 0


            for batch_id in xrange(batch_total_cnt):
                #process batch
                #print "step: %d/%d, batch:%d/%d" % (step+1, max_iter, batch_id+1, batch_total_cnt)
                sumU = np.zeros(components_cnt)
                sumV = np.zeros(components_cnt)
                sumTheta = np.zeros(linear_feature_cnt)

                #cal graident
                batch_cnt = 0
                for instance in batch_data[batch_id]:
                    #try:
                    if(True):
                        row = instance[0]
                        col = instance[1]
                        value = instance[2]

                        linear_data = self.get_linear_data(Rlinear[row][col], R_linear_valid_index_list)
                        predict = self.predict(U[row], V[col], Theta, linear_data,  w_mf, w_linear, mf_func, linear_func, False, "Train")
                        real = MatrixFactorization.norm_R_value_pos_neg_to_no_less_than_zero(value)
                        err = real - predict

                        #print "row:%s, col:%s, value:%s, real:%s, predict:%s, err:%s" % (str(row), str(col), str(value), str(real), str(predict), str(err))
                        #print "linear:", Rlinear[row][col]


                        #mf
                        if(flagMFValid):
                            (gradient_U, gradient_V) = self.get_gradient_mf(R, U, V, row, col, components_cnt, err, w_mf, mf_func, mf_user_reg, UserWeight, lamda_user_reg)


                            #update
                            if(gradient_U is not None):
                                U[row] += alpha * (gradient_U - lamda_u * U[row])
                            if(gradient_V is not None):
                                V[col] += alpha * (gradient_V - lamda_v * V[col])

                        #if(gradient_U != None):
                        #    sumU += gradient_U
                        #if(gradient_V != None):
                        #    sumV += gradient_V

                        #linear
                        if(flagLinearValid):
                            graident_Theta = self.get_gradient_linear(linear_data, Theta, err, linear_func, w_linear)
                            if(graident_Theta is not None):
                                #print "gradient_Theta:", graident_Theta
                                sumTheta += graident_Theta

                        batch_cnt += 1
                        #Theta += alpha * (graident_Theta - lamda_theta * Theta)
                    #except:
                    else:
                        print "except in instance"

                #batch end
                #update
                #print "process batch end..."
                try:
                    if(flagLinearValid):
                        #print "\nold Theta:", Theta
                        Theta += alpha * (sumTheta - lamda_theta * Theta)
                        #print "new Theta:", Theta
                except:
                    print "except in update"

                N = batch_total_cnt/10
                #N = 2

                if((batch_id+1) % N == 0):
                    #print "step: %d/%d, batch:%d/%d" % (step+1, max_iter, batch_id+1, batch_total_cnt)
                    #cost = self.mf_cal_cost(R, Rlinear, UserWeight, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, mf_user_reg, lamda_user_reg, linear_func )
                    #print "\n>>>>>>>>>>>>step:%d, batch:%d, cost:%f" % (step+1, batch_id+1, cost)
                    pass


            #
            cost = self.mf_cal_cost(R, Rlinear,R_linear_valid_index_list,  UserWeight, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, mf_user_reg, lamda_user_reg, linear_func )


            log_str = ">>>>>>>>>>>>step:%d, cost:%f" % (step+1, cost)
            self.log_detail_list.append(log_str)
            print "\n", log_str

            n_iter += 1
            if(self.gradient_descent_converge(stepCostList, cost, n_iter, max_iter)):
                break
            stepCostList.append(cost)


        return U, V, Theta, n_iter
        pass

    def gradient_descent_converge(self, stepCostList, cost, n_iter, max_iter):
        flag = False
        if(n_iter >= max_iter):
            flag = True
        else:
            #return flag
            if(n_iter < 10):
                flag = False
            else:
                N = len(stepCostList)
                j=N-1
                cnt = 0
                while(j >= 0):
                    preCost =  stepCostList[j]
                    if(preCost > cost and ((preCost - cost) < 0.0001)):
                        cnt += 1
                    else:
                        break
                    j-=1
                if(cnt > 5):
                    flag = True


        return flag

    def get_gradient_mf(self, R, U, V, row, col, components_cnt, err, w_mf, mf_func, mf_user_reg, UserWeight, lamda_user_reg):
        #process_mf

        gradient_U = None
        gradient_V = None

        #weight_mf
        weight_mf = 1
        if(MatrixFactorizationLinear.is_mf_valid(w_mf) and MatrixFactorizationLinear.is_mf_func_sigmoid(mf_func) ):
            f = np.dot(U[row], V[col])
            weight_mf = f * (1 - f)

        #w_mf_value
        w_mf_value = 0
        if(MatrixFactorizationLinear.is_mf_valid(w_mf)):
            w_mf_value = w_mf

            err_weight = err  * weight_mf * w_mf_value
            gradient_U = (err_weight * V[col])
            gradient_V = (err_weight * U[row])

            if(mf_user_reg):
                socialRegValue = 0
                oldURow = U[row]
                (flag, socialRegValue) = MatrixFactorization.cal_social_reg_of_user(U, row, UserWeight, lamda_user_reg)

                if(flag):
                    gradient_U -= socialRegValue
        return (gradient_U, gradient_V)

    def get_gradient_linear(self, RlinearRowCol, Theta, err, linear_func, w_linear):
        #process_linear
        gradient_Theta = None
        if(MatrixFactorizationLinear.is_linear_func_none(linear_func) == False):
            weight_tmp = 1
            if(MatrixFactorizationLinear.is_linear_func_simoid(linear_func)):
                linear_value = MatrixFactorizationLinear.cal_linear_value(Theta, RlinearRowCol, linear_func)
                weight_tmp = linear_value * (1-linear_value)
            #print "err:", err
            gradient_Theta = (err * w_linear * weight_tmp * RlinearRowCol)

        return gradient_Theta

    @classmethod
    def cal_sig_derive_value(cls, sigValue):
        res = sigValue * (1-sigValue)
        return res

    def has_linear_func(self, linear_func):
        res = (MatrixFactorizationLinear.is_linear_func_none(linear_func) == False)
        return res

    # def mf_gradient_desenct1(self, R, Rlinear, U, V, Theta, tol, max_iter, batch_size, alpha, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func, mf_user_reg, UserWeight, lamda_user_reg, mf_train_only_positive):
    #     InOut.console_func_begin("mf_gradient_desenct1")
    #     n_iter = 0
    #
    #     np.seterr(all='raise')
    #
    #     batch_data = self.get_batch_data(R, batch_size)
    #
    #
    #     for step in xrange(max_iter):
    #         (rowIndex, colIndex, valueList) = SparseMatrix.FindSparseMatrixNZRowColValue(R)
    #         process_cnt = 0
    #
    #
    #
    #         for index in xrange(len(rowIndex)):
    #
    #             row = rowIndex[index]
    #             col = colIndex[index]
    #
    #
    #             #print "index:%d, row:%d, col:%d, value: %f" % (index, row, col, R[row, col])
    #
    #             if(mf_train_only_positive and (self.mf_is_rating_valid(R[row, col]) == False)):
    #                 continue
    #                 pass
    #
    #
    #
    #
    #
    #             #print "row:%d, col:%d" % (row, col)
    #             #print "Rlinear[row][col]:", Rlinear[row][col]
    #             predict = self.predict(U[row], V[col], Theta, Rlinear[row][col], w_mf, w_linear, mf_func, linear_func, False, "Train")
    #
    #             #predict = np.dot(U[row], V[col]
    #             #real = R[row, col]
    #             real = MatrixFactorization.norm_R_value_pos_neg_to_no_less_than_zero( R[row, col])
    #             err = real - predict
    #
    #             #print "real:%f, predict:%f, err:%f" % (real, predict, err)
    #
    #             #U[row] += alpha * (err * V[col])
    #             #V[col] += alpha * (err * U[row])
    #
    #             # print "\nerr:", err
    #             #
    #             # print "\nbefore update"
    #             #
    #             # print "U[row]:", U[row]
    #             # print "V[col]:", V[col,:]
    #             # print "Theta:", Theta
    #
    #             #process_mf
    #             #weight_mf
    #             weight_mf = 1
    #             if(MatrixFactorizationLinear.is_mf_valid(w_mf) and MatrixFactorizationLinear.is_mf_func_sigmoid(mf_func) ):
    #                 f = np.dot(U[row], V[col])
    #                 weight_mf = f * (1 - f)
    #
    #
    #             #w_mf_value
    #             w_mf_value = 0
    #             if(MatrixFactorizationLinear.is_mf_valid(w_mf)):
    #                 #print "update mf"
    #                 w_mf_value = w_mf
    #
    #                 #social reg
    #
    #                 flag = False
    #                 if(mf_user_reg):
    #                     socialRegValue = 0
    #                     oldURow = U[row]
    #                     (flag, socialRegValue) = MatrixFactorization.cal_social_reg_of_user(U, row, UserWeight, lamda_user_reg)
    #                     if(process_cnt % 1000 == 0):
    #                         #print "flag:", flag
    #                         #print "socialRegValue:", socialRegValue
    #                         pass
    #                     if(flag):
    #                         try:
    #                             U[row] += alpha * (err  * weight_mf * w_mf_value * V[col] - socialRegValue - lamda_u * U[row])
    #                         except:
    #                             U[row] = oldURow
    #
    #                 try:
    #                     if((mf_user_reg == False) or (flag == False)):
    #                         U[row] += alpha * (err  * weight_mf * w_mf_value * V[col] - lamda_u * U[row])
    #                     V[col] += alpha * (err  * weight_mf * w_mf_value * U[row] - lamda_v * V[col])
    #                 except:
    #                     pass
    #
    #             #process_linear
    #             try:
    #                 #print "update linear"
    #                 if(MatrixFactorizationLinear.is_linear_func_none(linear_func) == False):
    #                     if(MatrixFactorizationLinear.is_linear_func_simoid(linear_func) == False):
    #                         Theta += alpha * (err * w_linear * Rlinear[row][col] - lamda_theta * Theta)
    #                     else:
    #                         #print "update Theta"
    #                         linear_value = MatrixFactorizationLinear.cal_linear_value(Theta, Rlinear[row][col], linear_func)
    #                         weight_tmp = linear_value * (1-linear_value)
    #                         #print "err:", err
    #                         Theta += alpha * (err * w_linear * weight_tmp * Rlinear[row][col] - lamda_theta * Theta)
    #
    #             except:
    #                 pass
    #
    #             #print "\nafter update"
    #             #
    #             # print "U[row]:", U[row]
    #             # print "V[col]:", V[col,:]
    #             #print "Theta:", Theta
    #
    #
    #             process_cnt += 1
    #             if(process_cnt % 1000 == 0):
    #                 cost = 0
    #                 cost = self.mf_cal_cost(R, Rlinear, UserWeight, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, mf_user_reg, lamda_user_reg, linear_func )
    #                 print "\nstep:%d, process_cnt:%d, cost:%f" % (step, process_cnt, cost)
    #                 print "Theta:", Theta
    #                 #print "\nstep:%d, process_cnt:%d, cost:%f" % (step, process_cnt, cost)
    #                 pass
    #
    #         #
    #         cost = self.mf_cal_cost(R, Rlinear, UserWeight, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, mf_user_reg, lamda_user_reg, linear_func )
    #         if(cost < tol):
    #             break
    #
    #         n_iter += 1
    #         print "\nstep:%d, cost:%f" % (step+1, cost)
    #
    #     return U, V, Theta, n_iter
    #     pass

    @classmethod
    def is_mf_user_reg(cls, mf_user_reg):
        return mf_user_reg


    def mf_cal_cost(self, R, Rlinear,R_linear_valid_index_list,  UserWight, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, mf_user_reg, lamda_user_reg, linear_func):
        J = 0

        #None
        J1 = self.mf_cal_se(R, Rlinear, R_linear_valid_index_list, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func)

        J2 = 0
        if(MatrixFactorizationLinear.is_mf_valid(w_mf)):
            J2 += lamda_u * LA.norm(U) + lamda_v * LA.norm(V)

        if(MatrixFactorizationLinear.is_mf_user_reg(mf_user_reg)):
            user_reg =  MatrixFactorization.cal_social_reg(U, UserWight, lamda_user_reg)
            J2 += user_reg

        if(MatrixFactorizationLinear.is_linear_func_none(linear_func)):
            J2 += 0
        else:
            J2 += lamda_theta * LA.norm(Theta)
        J = 1.0/2 * (J1 + J2)

        print "cost:", J
        return J

    @classmethod
    def is_mf_valid(cls, w_mf):
        threshold = 1e-5

        flag = w_mf > threshold

        #print "is_mf_valid:", flag
        return flag

    @classmethod
    def is_linear_valid(cls, w_linear):
        threshold = 1e-5

        flag = w_linear > threshold

        #print "is_mf_valid:", flag
        return flag

    def mf_cal_se(self, R, Rlinear, R_linear_valid_index_list, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func):
        """
        Frobenius norm between R and WH^T, safe for sparse array
        (R-WH^T)^2
        """
        #InOut.console_func_begin("mf_cal_se")
        #print R.shape
        #print W.shape
        #print H.shape

        #HT = np.transpose(H)
        if False:
            #error = LA.norm(R - np.dot(W, HT))
            pass
        else:
            #WH = np.dot(W, H)
            #print "R nnz:", R.nnz
            index = find(R)
            rowIndex = index[0]
            colIndex = index[1]

            #print "rowIndex:", len(rowIndex)
            list = []
            for id in range(len(rowIndex)):
                row = rowIndex[id]
                col = colIndex[id]
                #real = R[row, col]
                real = MatrixFactorization.norm_R_value_pos_neg_to_no_less_than_zero( R[row, col])

                linear_data = self.get_linear_data(Rlinear[row][col], R_linear_valid_index_list)
                predict = self.predict(U[row,:], V[col,:], Theta, linear_data, w_mf, w_linear, mf_func, linear_func, False, "cal_see")


                #print "real: %f, predict: %f" % (real, predict)
                tmp = real-predict
                list.append(tmp)
            error = LA.norm(list)
            #print "mf_cal_se error:", error

        se = error * error
        return se




    def mf_cal_reconstruction_err(self, R, Rlinear, R_linear_valid_index_list, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func):
        res = self.mf_cal_se(R, Rlinear, R_linear_valid_index_list, U, V, Theta, lamda_u, lamda_v, lamda_theta, w_mf, w_linear, mf_func, linear_func)
        return res


    def mf_cal_rsme(self, re, nnz):
        return MatrixFactorizationLinear.mf_cal_rsme_from_se_nnz(re, nnz)

    @classmethod
    def mf_cal_rsme_from_se_nnz(cls, se, nnz):
        return MatrixFactorization.mf_cal_rsme_from_se_nnz(se, nnz)

    # def mf_cal_rsme(self, R, W, H):
    #     se = self.mf_cal_se(R, W, H)
    #     N = R.nnz
    #     rsme = np.sqrt(se / N)
    #     return rsme

    def get_log_detail_list(self):
        return self.log_detail_list