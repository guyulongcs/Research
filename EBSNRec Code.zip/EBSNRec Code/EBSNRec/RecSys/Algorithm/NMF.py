from scipy.sparse import *
import numpy as np
from numpy import linalg as LA
from sklearn.decomposition import NMF
from sklearn.utils.validation import *
from Tool.InOutTool.InOutTool import *
from RecSys.Algorithm.baseAlgorithm import *

import warnings

from Tool.InOutTool.InOutTool import *

class NMF(BaseAlgorithm):

    def __init__(self, K=50):
        self.K = K


    def fit(self, matrix):
        InOut.console_func_begin("MatrixFactorization")
        print "matrix:", matrix.shape
        model = NMF(n_components=self.K, init='random', random_state=0)
        model.fit(matrix)

        #print "components:"
        #print model.components_


        err = model.reconstruction_err_
        print "reconstruction_err_:", err

