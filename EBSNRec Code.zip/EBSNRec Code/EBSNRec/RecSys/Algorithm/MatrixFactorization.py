from scipy.sparse import *
import numpy as np
from numpy import linalg as LA
from sklearn.decomposition import NMF
from sklearn.utils.validation import *
from Tool.InOutTool.InOutTool import *
from RecSys.Algorithm.baseAlgorithm import *
from Tool.TypeTool.TypeProcessTool import *


import warnings

from Tool.InOutTool.InOutTool import *

class MatrixFactorization():
    def __init__(self):
        self.log_detail_list = []
        pass

    def matrix_factor(self, X, U=None, V=None, n_components=None,
                               init='random', solver='gd',
                               tol=1e-4, max_iter=200, alpha=0.01, lamda_u=0, lamda_v=0,
                               regularization=None, random_state=None, mf_train_only_positive = True):
        '''
        X = UV^T

        The objective function is::
         0.5 + ||X - UV^T||_Fro^2
        + 0.5 * lamda_u * * ||U||_Fro^2
        + 0.5 * lamda_v * * ||V||_Fro^2
        :param R:
        :param U:
        :param V:
        :param n_components: K
        :param init: None | 'random'
            - 'random':
                sqrt(X.mean() / n_components)
        :param update_H:
        :param solver: 'gd'
            'gd' is a Gradient Descent solver
        :param tol: float, default: 1e-4
            Tolerance of the stopping condition.
        :param max_iter:    integer, default: 200
             Maximum number of iterations before timing out.
        :param alpha: double, default = 0.001
            learning rate
        :param lamda_u: double, default: 0.
            Constant that multiplies the regularization terms.
        :param lamda_v: double, default: 0.
            Constant that multiplies the regularization terms.

        :param regularization: 'both' | 'U' | 'V' | None
             Select whether the regularization
        :param random_state: integer seed, RandomState instance, or None (default)
             Random number generator seed control.

        :return:
        U
        V
        n_iter : int
            Actual number of iterations.
        '''

        if init == None:
            init = 'random'

        if init == 'random':
            U, V = MatrixFactorization.mf_init(X, n_components, init=init, random_state=random_state)
        else:
            raise ValueError("Invalid init parameter '%s'." % init)


        if solver == 'gd':
            U, V, n_iter = self.mf_gradient_desenct(X, U, V, tol, max_iter, alpha, lamda_u, lamda_v, mf_train_only_positive)
        else:
            raise ValueError("Invalid solver parameter '%s'." % solver)

        if n_iter == max_iter:
            warnings.warn("Maximum number of iteration %d reached." % max_iter)

        return U, V, n_iter
        pass

    @classmethod
    def mf_init(cls, X, n_components, init=None, random_state=None):
        '''
        X=UV^T
        :param X:
        :param n_components:
        :param init:
        :param random_state:

        :return:
        U
        V
        '''
        n_users, n_items = X.shape
        if init is None:
            init = 'random'

        if init == 'random':
            print "X mean:", X.mean()
            print "component:", n_components
            avg = np.sqrt(np.abs(X.mean()) / n_components)
            #avg = X.mean()
            rng = check_random_state(random_state)

            U = avg * rng.randn(n_users, n_components)
            V = avg * rng.randn(n_items, n_components)

            #np.abs(U, U)
            #np.abs(V, V)

            return U, V


        pass

    @classmethod
    def mf_is_rating_valid(cls, v):
        flag = False
        if(v > 0):
            flag = True
        return flag

    def mf_gradient_desenct(self, R, U, V, tol, max_iter, alpha, lamda_u, lamda_v, mf_train_only_positive):
        return self.mf_gradient_desenct1(R, U, V, tol, max_iter, alpha, lamda_u, lamda_v, mf_train_only_positive)
        #return self.mf_gradient_desenct2(R, U, V, tol, max_iter, alpha, lamda_u, lamda_v)

    def mf_gradient_desenct1(self, R, U, V, tol, max_iter, alpha, lamda_u, lamda_v, mf_train_only_positive):
        n_iter = 0
        for step in xrange(max_iter):
            (rowIndex, colIndex) = SparseMatrix.FindSparseMatrixNZ(R)

            process_cnt = 0
            for index in xrange(len(rowIndex)):

                row = rowIndex[index]
                col = colIndex[index]


                #print "index:%d, row:%d, col:%d, value: %f" % (index, row, col, R[row, col])

                if(mf_train_only_positive and (MatrixFactorization.mf_is_rating_valid(R[row, col]) == False)):
                    continue
                    pass

                predict = MatrixFactorization.predict(U[row], V[col])
                #real = R[row, col]

                real = MatrixFactorization.norm_R_value_pos_neg( R[row, col])

                err = real - predict
                #print "predict:%f, real:%f, err:%f" %(predict, real, err)

                #U[row] += alpha * (err * V[col])
                #V[col] += alpha * (err * U[row])

                U[row] += alpha * (err * V[col] - lamda_u * U[row])
                V[col] += alpha * (err * U[row] - lamda_v * V[col])

                process_cnt += 1
                if(process_cnt % 10 == 0):
                    cost = 0
                    #print "\nstep:%d, process_cnt:%d, cost:%f" % (step, process_cnt, cost)
                    pass

            #
            cost = self.mf_cal_cost(R, U, V, lamda_u, lamda_v)
            if(cost < tol):
                break

            n_iter += 1

            log_str = "\nstep:%d, cost:%f" % (step+1, cost)
            self.log_detail_list.append(log_str)

            print log_str

        return U, V, n_iter
        pass

    @classmethod
    def predict(cls, u, v):
        p = np.dot(u, v)
        return p

    def mf_cal_cost(self, R, U, V, lamda_u, lamda_v):
        J = 0
        J1 = self.mf_cal_se(R, U, V)
        J2 = lamda_u * LA.norm(U) + lamda_v * LA.norm(V)
        J = 1.0/2 * (J1 + J2)
        return J

    @classmethod
    def norm_R_value_pos_neg(cls, value):
        res = value
        if(res < 0):
            res = 0
        return res

    @classmethod
    def norm_R_value_pos_neg_to_no_less_than_zero(cls, value):
        res = value
        if(res < 0):
            res = 0
        return res

    @classmethod
    def cal_reconstruction_err(cls, X, W, H):
        res = MatrixFactorization.mf_cal_se(X, W, H)
        return res


    @classmethod
    def mf_cal_se(cls, X, W, H):
        """
        Frobenius norm between X and WH^T, safe for sparse array
        (X-WH^T)^2
        """
        #InOut.console_func_begin("mf_cal_se")
        #print X.shape
        #print W.shape
        #print H.shape

        HT = np.transpose(H)
        if not issparse(X):
            error = LA.norm(X - np.dot(W, HT))
        else:
            #WH = np.dot(W, H)
            #print "X nnz:", X.nnz
            index = find(X)
            rowIndex = index[0]
            colIndex = index[1]

            #print "rowIndex:", len(rowIndex)
            list = []
            for id in range(len(rowIndex)):
                row = rowIndex[id]
                col = colIndex[id]


                real = MatrixFactorization.norm_R_value_pos_neg( X[row, col])
                #real = X[row, col]
                predict = np.dot(W[row,:], H[col, :])
                #print "real: %f, predict: %f" % (real, predict)
                tmp = real-predict
                list.append(tmp)
            error = LA.norm(list)

            #print "mf_cal_se error:", error

        se = error * error
        return se

    @classmethod
    def mf_cal_rsme_from_re_nnz(cls, re, nnz):
        se = re
        return MatrixFactorization.mf_cal_rsme_from_se_nnz(se, nnz)

    @classmethod
    def mf_cal_rsme_from_se_nnz(cls, se, nnz):
        rsme = np.sqrt(math.fabs(se / nnz))
        return rsme

    # def mf_cal_rsme(self, X, W, H):
    #     se = self.mf_cal_se(X, W, H)
    #     N = X.nnz
    #     rsme = np.sqrt(se / N)
    #     return rsme
    #

    @classmethod
    def cal_social_reg_of_user_vec(cls, U, row, UserWeight):
        #InOut.console_func_begin("cal_social_reg_of_user_vec")
        friendList = find(UserWeight[row])[1]
        weightList = find(UserWeight[row])[2]

        diff = 0

        res = None

        flag = False
        if(len(friendList) > 0):
            flag = True

            sumWeight = sum(weightList)
            sumWeight = float(sumWeight)

            if(TypeProcessTool.is_float_zero(sumWeight)):
                flag=False
                return (flag, res)

            #print "cal_social_reg_of_user_vec"
            #print "row:", row
            #print "frindList:", friendList
            #print "weightList:", weightList
            #print "len:", len(friendList)
            #print "sumWeight:", sumWeight


            tmp = U[row]
            for i in xrange(len(friendList)):
                f = friendList[i]
                w = weightList[i]
                tmp -= (w / sumWeight) * (U[f])
            res =  tmp

            #print "res:", res


        return (flag, res)
        pass

    @classmethod
    def cal_social_reg_of_user(cls, U, row, UserWeight, lamda_user_reg):
        (flag, vec) = MatrixFactorization.cal_social_reg_of_user_vec(U, row, UserWeight)
        res = None
        if(flag):
            res = lamda_user_reg * vec
        return (flag, res)


    @classmethod
    def cal_social_reg(cls, U, UserWeight, lamda_user_reg):
        res = 0
        rowSum = 0
        for row in xrange(len(U)):
            (flag, resRow) = MatrixFactorization.cal_social_reg_of_user_vec(U, row, UserWeight)
            if(flag):
                rowValue = LA.norm(resRow)
                rowSum += rowValue
        res = lamda_user_reg * rowSum

        return res


    def get_log_detail_list(self):
        return self.log_detail_list
