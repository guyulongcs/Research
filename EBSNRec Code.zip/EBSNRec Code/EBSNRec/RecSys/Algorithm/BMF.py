from scipy.sparse import *
import numpy as np
from numpy import linalg as LA
from sklearn.decomposition import NMF
from sklearn.utils.validation import *
from Tool.InOutTool.InOutTool import *
from RecSys.Algorithm.baseAlgorithm import *
from MatrixFactorization import *
import warnings

from Tool.InOutTool.InOutTool import *
from BPRMatrixFactorization import *

class BMF(BaseAlgorithm):
    def __init__(self, n_components = 10, init=None, solver='gd', tol=1e-4,  max_iter=10,
                 alpha=0.01, lamda_u=0., lamda_v=0., regularization=None, random_state=None, mf_train_only_positive=True):
        self.n_components = n_components
        self.init = init
        self.solver = solver
        self.tol = tol
        self.max_iter = max_iter
        self.alpha = alpha
        self.lamda_u = lamda_u
        self.lamda_v = lamda_v
        self.regularization = regularization
        self.random_state = random_state

        self.mf_train_only_positive = mf_train_only_positive

        self.mf = BPRMatrixFactorization()
        self.reconstruction_err_ = 0
        self.RSME = 0

        self.log_detail_list = []

    def train(self, X=None, y=None, **params):
        return self.fit(X, y, **params)
        #return self


    def fit(self, X, y=None, U=None, V=None):

        X = check_array(X, accept_sparse=('csr', 'csc'))

        print "\nX:", X.shape
        print "X nnz:", X.nnz


        U, V, n_iter_ = self.mf.matrix_factor(
            X=X, U=U, V=V, n_components=self.n_components,
            init=self.init, solver=self.solver, tol=self.tol, max_iter=self.max_iter,
            alpha=self.alpha, lamda_u=self.lamda_u, lamda_v=self.lamda_v, regularization=self.regularization,
            random_state=self.random_state)

        self.log_detail_list = self.mf.get_log_detail_list()

        print "U:", V.shape
        print "V:", V.shape

        #error
        V_trans = np.transpose(V)
        print "V_trans:", V_trans.shape

        #square_err = MatrixFactorization.mf_cal_se(X, U, V)
        self.reconstruction_err_ = MatrixFactorization.cal_reconstruction_err(X, U, V)
        self.RSME = MatrixFactorization.mf_cal_rsme_from_re_nnz(self.reconstruction_err_, X.nnz)

        print "reconstruction_err_:", self.reconstruction_err_
        print "RSME:", self.RSME

        self.n_components_ = U.shape[1]
        self.U = U
        self.V = V
        self.n_iter_ = n_iter_

        return (U, V, n_iter_)
        pass

    def get_log_detail_list(self):
        return self.log_detail_list
