from scipy.sparse import *
import numpy as np
from numpy import linalg as LA
from sklearn.decomposition import NMF
from sklearn.utils.validation import *
from Tool.InOutTool.InOutTool import *
from RecSys.Algorithm.baseAlgorithm import *
from MatrixFactorizationLinear import *
import warnings

from Tool.InOutTool.InOutTool import *

class MFLinear(BaseAlgorithm):
    def __init__(self, n_components = 10, n_linear_feature = 0, init=None, solver='gd', tol=1e-4,  max_iter=10, batch_size=50,
                 alpha=0.01, w_mf=0.5, w_linear=0.5, lamda_u=0., lamda_v=0., lamda_theta = 0.,
                 regularization=None, random_state=None, mf_func = None, linear_func = None, mf_user_reg=False, lamda_user_reg=0., mf_train_only_positive=True):
        self.n_components = n_components
        self.n_linear_feature = n_linear_feature
        self.init = init
        self.solver = solver
        self.tol = tol
        self.max_iter = max_iter
        self.batch_size = batch_size
        self.alpha = alpha
        self.w_mf = w_mf
        self.w_linear = w_linear
        self.lamda_u = lamda_u
        self.lamda_v = lamda_v
        self.lamda_theta = lamda_theta
        self.regularization = regularization
        self.random_state = random_state
        self.mf_func = mf_func
        self.linear_func = linear_func
        self.mf_user_reg = mf_user_reg
        self.lamda_user_reg = lamda_user_reg
        self.mf_train_only_positive = mf_train_only_positive

        self.reconstruction_err_ = 0
        self.RSME = 0

        self.log_detail_list = []



        self.mf = MatrixFactorizationLinear()



    def train(self, R=None, Rlinear=None,R_linear_valid_index_list=None, UserWeight = None,  y=None, **params):
        return self.fit(R, Rlinear,R_linear_valid_index_list, UserWeight, y, **params)
        #return self


    def fit(self, R, Rlinear=None, R_linear_valid_index_list=None, UserWeight = None, y=None, U=None, V=None):

        R = check_array(R, accept_sparse=('csr', 'csc'))

        print "\nR:", R.shape
        print "R nnz:", R.nnz


        U, V, Theta, n_iter_ = self.mf.matrix_factor(
            R=R, Rlinear=Rlinear, R_linear_valid_index_list=R_linear_valid_index_list,UserWeight=UserWeight, U=U, V=V, n_components=self.n_components, n_linear_feature=self.n_linear_feature,
            init=self.init, solver=self.solver, tol=self.tol, max_iter=self.max_iter, batch_size = self.batch_size,
            alpha=self.alpha, w_mf =self.w_mf, w_linear=self.w_linear,
            lamda_u=self.lamda_u, lamda_v=self.lamda_v, lamda_theta=self.lamda_theta,
            regularization=self.regularization,
            random_state=self.random_state, mf_train_only_positive=self.mf_train_only_positive, mf_func = self.mf_func, linear_func=self.linear_func, mf_user_reg = self.mf_user_reg, lamda_user_reg = self.lamda_user_reg)

        self.log_detail_list = self.mf.get_log_detail_list()
        print "U:", V.shape
        print "V:", V.shape

        #error
        V_trans = np.transpose(V)
        print "V_trans:", V_trans.shape


        self.reconstruction_err_ = self.mf.mf_cal_reconstruction_err(R, Rlinear, R_linear_valid_index_list, U, V, Theta, self.lamda_u, self.lamda_v, self.lamda_theta, self.w_mf, self.w_linear, self.mf_func, self.linear_func)
        self.RSME = self.mf.mf_cal_rsme(self.reconstruction_err_, R.nnz)

        print "reconstruction_err_:", self.reconstruction_err_
        print "RSME:", self.RSME

        self.n_components_ = U.shape[1]
        self.U = U
        self.V = V
        self.n_iter_ = n_iter_

        return (U, V, Theta, n_iter_)
        pass

    def predict(self, U, V,  Theta, Rlinear, R_linear_valid_index_list, row, col, flagPrint=False, flagTag=""):

        return self.mf.predict_l(U[row, :], V[col,:],Theta, Rlinear[row][col], R_linear_valid_index_list, self.w_mf, self.w_linear,self.mf_func, self.linear_func, flagPrint, flagTag)

        pass

    def get_log_detail_list(self):
        return self.log_detail_list
