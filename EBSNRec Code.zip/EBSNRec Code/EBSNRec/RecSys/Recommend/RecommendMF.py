
from RecSys.Recommend.Recommend import *
from Tool.MLTool.Evaluation import *
from Config import *
from RecSys.Algorithm.MF import *
from RecSys.Algorithm.NMF import *

class RecommendMF(Recommend):
    def __init__(self):
        self.data = Data()

        self.n_components = Config.p_mf_components
        self.max_iter = Config.p_mf_base_iteration_number
        self.alpha = Config.p_mf_alpha
        self.lamda_u = 0.00
        self.lamda_v = 0.00

        self.U = None
        self.V = None

        self.n_iter = 0

        self.mf_train_only_positive = Config.p_mf_train_only_positive

        #model
        self.mf = MF(n_components = self.n_components, max_iter=self.max_iter, alpha=self.alpha, lamda_u=self.lamda_u, lamda_v=self.lamda_v, mf_train_only_positive = self.mf_train_only_positive)
        self.nmf = NMF(K = self.n_components)

        self.log = []

        self.log_detail_list = []

        pass


    def set_data(self, data):
        #self.data.set_data(data)
        #self.data = data["dataDump"]
        self.data = data




    def train_mf(self):
        (self.U, self.V, self.n_iter) = self.mf.train(self.data._R_train_pos)
        self.log_detail_list.extend(self.mf.get_log_detail_list())
    # def train_mf_linear(self):
    #     (self.U, self.V, self.Theta, self.n_iter) = self.mf.train(self.data._R_train, self.data._dict_user_event_featureList)



    #def train(self, X=None, y=None, **params):
    #    pass

    def predict(self, user_id, product_id):
        user_feature = self.userFeatures(user_id)
        product_feature = self.productFeature(product_id)
        r = np.dot(user_feature, product_feature)
        return r
        pass

    def predictAll(self, list_user_product):
        InOut.console_func_begin("predictAll")
        l = []
        for user_product in list_user_product:
            user = user_product[0]
            product = user_product[1]

            #print "user:", user
            #print "product:", product

            r = self.predict(user, product)
            #print "r:", r
            l.append(r)
        return l
        pass

    def predictUserProductList(self, user_id, list_product_id):
        list_user_product = []
        for product_id in list_product_id:
            list_user_product.append([user_id, product_id])

        r = self.predictAll(list_user_product)
        return r

    def predictProductUserList(self, product_id, list_user_id):
        list_user_product = []
        for user_id in list_user_id:
            list_user_product.append([user_id, product_id])

        r = self.predictAll(list_user_product)
        return r

    def recommendUsers(self, product_id, num):
        pass

    def recommendProducts(self, user_id, num):
        pass

    def productFeature(self, product_id):
        product_index = self.get_product_index(product_id)
        return self.V[product_index]
        pass

    def userFeatures(self, user_id):
        user_index = self.get_user_index(user_id)
        return self.U[user_index]
        pass



    def evaluate_validation(self):
        InOut.console_func_begin("evaluate_validation")
        self.log_info_append("\nevaluate_validation")
        ratingList = self.data._ratingList_validation
        res = self.evaluation_list(ratingList)
        self.log_info_extend(res)

    def evaluate_test(self):
        InOut.console_func_begin("evaluate_test")
        self.log_info_append("\nevaluate_test")
        res = self.evaluation_list(self.data._ratingList_test)
        self.log_info_extend(res)


    # def generate_evaluate_data(self):
    #     self.data.generate_evaluate_data(Config.flag_filt_R_not_positive, Config.p_ml_split_ratio["train"], Config.p_ml_split_ratio["validation"])

    def evaluate_model(self, data):
        InOut.console_func_begin("evaluate_model")
        self.log_info_append("\n>>>>>>RecommendMF...")
        self.set_data(data)
        self.evaluate_model_mf()


    def evaluate_model_mf(self):
        self.train_mf()
        self.evaluate_validation()
        self.evaluate_test()

    def get_list_real_predict(self, ratingList):
        (list_user_product, list_r_real) = Recommend.get_list_user_product_and_rate_from_ratingList(ratingList)

        #predict
        list_r_predict = self.predictAll(list_user_product)

        #norm
        list_r_real = Recommend.norm_list_real(list_r_real)
        list_r_predict = Recommend.norm_list_real(list_r_predict)
        return (list_r_real, list_r_predict)


    def evaluation_list(self, ratingList):
        (list_r_real, list_r_predict) = self.get_list_real_predict(ratingList)
        res = Recommend.evaluation_real_predict(list_r_real, list_r_predict)
        return res

    def get_log(self):
        return self.log

    def get_log_detail(self):
        return self.log_detail_list

    def log_info_append(self, str):
        self.log.append(str)
        self.log_detail_list.append(str)

    def log_info_extend(self, strList):
        self.log.extend(strList)
        self.log_detail_list.extend(strList)
