from RecSys.Datamodel.data import *
from RecSys.Algorithm.MatrixFactorization import *
from scipy.sparse import rand

#from RecommendMF import *
from Tool.MLTool.Evaluation import *

class Recommend():


    def __init__(self):
        self.data = Data()
        self.recommend_type = None
        self.recommend = None
        self.log = []

    def set_recommend_type_data(self, type=None, data=None):
        if(type == "MF"):
            self.recommend_type = type
            #self.recommend = RecommendMF()
            #self.recommend.set_data(data)

    def train(self, X=None, y=None, **params):
        pass

    def predict(self, user_id, product_id):
        pass

    def predictAll(self, list_user_product):
        pass

    def recommendUsers(self, product_id, num):
        pass

    def recommendProducts(self, user_id, num):
        pass

    def productFeature(self, product_id):
        pass

    def userFeatures(self, user_id):
        pass

    def get_user_index(self, user_id):
        #print "_dictUserIndex:", len(self.data._dictUserIndex)
        #print "user_id:", user_id
        index = self.data._dictUserIndex[user_id]
        return index
        pass

    def get_product_index(self, product_id):
        index = self.data._dictItemIndex[product_id]
        return index
        pass

    def get_user_product_list(self):
        return self.data.get_user_product_list()

    @classmethod
    def test(self, data):
        recommend = Recommend()

        recommend.set_recommend_type_data("MF", data)
        recommend.test()

        pass




    def test(self, data):
        #self.test_ebsn(data)
        self.test_random()


    def test_ebsn(self, data):

        self.mf.train(data)
        self.nmf.train(data)

        pass

    def test_random(self):
        R = self.get_sparse_matrix()
        self.mf.train(R)
        self.nmf.fit(R,K=self.n_components)

        pass

    def get_sparse_matrix(self):
        R = rand(1000, 2000, density=0.01, format='csr', random_state=None)
        #R = rand(10, 20, density=0.01, format='csr', random_state=None)

        return R

    @classmethod
    def evaluation_real_predict(cls, list_r_real, list_r_predict):
        #evaluate
        res = Evaluation.metrics_real_predict(list_r_real, list_r_predict)
        return res
        pass

    @classmethod
    def norm_list_real(cls, list):
        res = []
        for v in list:
            res.append(Recommend.norm_value(v))
        return res
        pass

    @classmethod
    def norm_value(cls, value):
        res = 1
        if(value < 0.5):
            res = 0
        return res

    @classmethod
    def get_list_user_product_and_rate_from_ratingList(cls, ratingList):
        list_user_product = []
        rateList = []
        for rating in ratingList:
            user = rating[0]
            product = rating[1]
            rate = rating[2]
            #print "user:", user
            #print "product:", product
            #print "rate:", rate
            list_user_product.append([user, product])
            rateList.append(rate)
        return (list_user_product, rateList)

        pass



