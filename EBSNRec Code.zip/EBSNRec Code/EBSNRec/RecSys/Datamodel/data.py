from Tool.MatrixTool.SparseMatrix import *
from Tool.MLTool.CrossValidation import *
from RecSys.Datamodel.rating import *
from Tool.MLTool.PreProcessing import *
from EBSN.Event import *
from GenerateExpDataUWeight import *
from scipy.sparse import *

import random


class Data():
    def __init__(self):
        #input
        #ratingList:
        self._ratingList_init = []       #original,  [ user, item, rate ], rate can be 1/-1
        self._ratingList_complete = []    #pos, negAll
        self._userSet = set()
        self._itemSet = set()

        #process
        self._dictUserIndex = {}
        self._dictItemIndex = {}
        self._dictIndexUser = {}
        self._dictIndexItem = {}
        self._DU = 0
        self._DV = 0
        self._R_Init = None
        self._R_train_pos_neg = None
        self._R_train_pos = None

        self._user_product_list_pos = []
        self._user_product_list_neg = []

        #self._ratingListTrain = []
        #self._ratingListTest = []
        self._ratingList_train = []
        self._ratingList_validation = []
        self._ratingList_test = []

        self._predict_ratingList = []

        self._dict_user_event_featureList = {}
        self._R_linear = {}
        self._R_linear_valid_index_list = []
        self._n_linear_feature = 0

        self.dict_user_eventCnt = {}
        self.dict_user_eventGroup_cnt = {}

        self.dictContentEventidVecTfidf = {}
        self.dictContentUseridVecTfidf = {}

        self._dict_user_user_weight_on = {}
        self._dict_user_user_weight_off = {}


        self._dict_user_user_sameGroupCnt = {}
        self._dict_user_user_sameEventCnt = {}

        self._user_weight = None


    def get_dump_data(self):
        dataDump = Data()
        dataDump._R_train_pos_neg = self._R_train_pos_neg
        dataDump._R_train_pos = self._R_train_pos
        dataDump._dictUserIndex = self._dictUserIndex
        dataDump._dictItemIndex = self._dictItemIndex

        dataDump._ratingList_complete = self._ratingList_complete
        dataDump._ratingList_validation = self._ratingList_validation
        dataDump._ratingList_test = self._ratingList_test

        dataDump._userSet = self._userSet
        dataDump._itemSet = self._itemSet

        dataDump._dict_user_event_featureList = self._dict_user_event_featureList
        dataDump._R_linear = PreProcessing.norm_dict_str_str_listDouble_to_array_using_row_col_index(self._dict_user_event_featureList, self._dictUserIndex, self._dictItemIndex)
        dataDump._n_linear_feature = PreProcessing.get_dict_str_str_listDouble_colcnt(self._dict_user_event_featureList)

        dataDump._dict_user_user_weight_on = self._dict_user_user_weight_on
        dataDump._dict_user_user_weight_off = self._dict_user_user_weight_off
        dataDump._user_weight = self._user_weight
        #dataDump._n_linear_feature = self._n_linear_feature

        dataDump.printInfo()


        return dataDump

    def get_dump_data_user_weight(self):
        dataDump = Data()
        dataDump._dict_user_user_weight_on = self._dict_user_user_weight_on
        dataDump._dict_user_user_weight_off = self._dict_user_user_weight_off
        dataDump._user_weight = self._user_weight
        return dataDump

    def printInfo(self):
        print "_R_train_pos_neg:", self._R_train_pos_neg.shape
        print "_R_train_pos:", self._R_train_pos.shape
        print "_dictUserIndex:", len(self._dictUserIndex)
        print "_dictItemIndex:", len(self._dictItemIndex)
        print "_ratingList_validation:", len(self._ratingList_validation)
        print "_ratingList_test:",len(self._ratingList_test)
        print "_dict_user_event_featureList", len(self._dict_user_event_featureList)
        print "_R_linear:", len(self._R_linear)

        print "_ratingList_complete:",len(self._ratingList_complete)
        print "_userSet:", len(self._userSet)
        print "_itemSet:", len(self._itemSet)

        print "_dict_user_user_weight_on:", len(self._dict_user_user_weight_on)
        print "_dict_user_user_weight_off:", len(self._dict_user_user_weight_off)

        if(self._user_weight != None):
            print "_user_weight:", self._user_weight.shape
            print "_user_weight nnz:", self._user_weight.nnz

    def printRLinear(self):
        for key1 in self._R_linear:
            for key2 in self._R_linear[key1]:
                v = self._R_linear[key1][key2]
                print "key1:%s, key2:%s" % (str(key1), str(key2))
                print v
        pass

    def print_dict_user_event_featureList(self):
        cnt = 0
        for key1 in self._dict_user_event_featureList:
            for key2 in self._dict_user_event_featureList[key1]:
                v = self._dict_user_event_featureList[key1][key2]
                print "key1:%s, key2:%s" % (str(key1), str(key2))
                print v
                cnt+=1

        print "len:", len(self._dict_user_event_featureList)
        print "cnt:", cnt
        pass

    def print_dict_user_user_weight_on(self):
        InOut.console_func_begin("print_dict_user_user_weight_on")
        for u1 in self._dict_user_user_weight_on:
            for u2 in self._dict_user_user_weight_on[u1]:
                weight = self._dict_user_user_weight_on[u1][u2]
                print "u1:%s, u2:%s, on weight:%f" % (u1, u2, weight)

    def print_dict_user_user_weight_off(self):
        InOut.console_func_begin("print_dict_user_user_weight_off")
        for u1 in self._dict_user_user_weight_off:
            for u2 in self._dict_user_user_weight_off[u1]:
                weight = self._dict_user_user_weight_off[u1][u2]
                print "u1:%s, u2:%s, off weight:%f" % (u1, u2, weight)





    def set_data_value(self, ratingList, rowSet, colSet):
        InOut.console_func_begin("set_data_value")
        self._ratingList_init = ratingList
        self._userSet = rowSet
        self._itemSet = colSet
        print "rating:", len(self._ratingList)

        pass

    def set_data(self, data):
        InOut.console_func_begin("set_data")
        print "row:", len(data["rowSet"])
        print "col:", len(data["colSet"])
        print "rating:", len(data["ratingList"])
        self.set_data_value(data["ratingList"], data["rowSet"], data["colSet"])

    def generate_evaluate_data(self, flag_filt_R_not_positive=False, p_split_train_ratio=0.6, p_split_validation_ratio=0.2):
        #get R_Init, R, train, validation, test
        InOut.console_func_begin("generate_evaluate_data")
        self.get_R_Init()
        self.get_ratingList_complete()
        self.get_rating_train_validation_test( p_split_train_ratio, p_split_validation_ratio)
        self.get_R_train(flag_filt_R_not_positive)

    def get_R_Init(self):
        #get R_Init
        InOut.console_func_begin("get_R")


        #ratingList = Rating.ratingListToList(self._ratingList_init)
        #print "user_set:", len(self._userSet)
        (self._R_Init, self._R_pos, self._R_neg, self.DU, self.DV, self._dictUserIndex, self._dictItemIndex, self._dictIndexUser, self._dictIndexItem) = SparseMatrix.CreateSparseMatrixInit(self._ratingList_init, self._userSet, self._itemSet)




    def get_rating_train_validation_test(self, p_split_train_ratio, p_split_validation_ratio):
        #get R, train, validation, test
        self.generate_train_validation_test_data(p_split_train_ratio, p_split_validation_ratio)

    def get_R_train(self, flag_filt_R_not_positive):
        self._R_train_pos = self.get_R_train_ratingList(self._ratingList_train, True)
        self._R_train_pos_neg = self.get_R_train_ratingList(self._ratingList_train, False)



    def get_ratingList_complete(self):
        ratingPosNegList = self.get_rating_pos_negAll_list()
        self._ratingList_complete = ratingPosNegList

    def generate_train_validation_test_data(self, train_ratio, validation_ratio):
        InOut.console_func_begin("generate_train_test_data")

        (train, validation, test) = CrossValidation.split_list_train_validation_test(self._ratingList_complete, train_ratio, validation_ratio)
        self._ratingList_train = train
        self._ratingList_validation = validation
        self._ratingList_test = test
        #self._ratingList_predict = self._ratingList_test
        #return (train, validation, test)
        pass

    def get_user_product_list_poslist_neglist(self):
        (user_product_index_pos, user_product_index_negAll) = self.get_user_product_index_pos_negAll()
        (user_product_list_pos, user_product_list_neg) = self.trans_user_product_index_to_item_pos_neg(user_product_index_pos, user_product_index_negAll)
        return (user_product_list_pos, user_product_list_neg)

    def get_rating_pos_negAll_list(self):
        (user_product_list_pos, user_product_list_neg) = self.get_user_product_list_poslist_neglist()

        ratingPosNegList = self.get_ratingList_all(user_product_list_pos, user_product_list_neg)
        return ratingPosNegList
        pass


    def get_R_train_ratingList(self, ratingList, flag_filt_not_positive):
        InOut.console_func_begin("get_R_train")
        R = SparseMatrix.CreateSparseMatrix(ratingList, self._dictUserIndex, self._dictItemIndex, flag_filt_not_positive)
        return R
        pass

    def get_ratingList_all(self, user_product_list_pos, user_product_list_neg):
        InOut.console_func_begin("get_ratingList_all")

        resList = []
        posValue = 1
        negValue = -1
        for item in user_product_list_pos:
            resList.append([item[0], item[1], posValue])
        for item in user_product_list_neg:
            resList.append([item[0], item[1], negValue])

        return resList
        pass


    def get_user_product_index_pos_negAll(self):
        InOut.console_func_begin("get_user_product_index_posneg")
        user_product_index_pos = []
        user_product_index_neg = []

        for row in xrange(self.DU):
            posCols = find(self._R_pos[row])[1]
            negCols = find(self._R_neg[row])[1]
            #cols = random.randrange(0, self.DV)
            negAllCols = self.get_negAll_cols(self.DV, posCols, negCols)

            #print "posCols:", posCols
            #print "negCols:", negCols
            #print "negAllCols:", negAllCols

            for col in posCols:
                #print "pos col:", col
                user_product_index_pos.append([row, col])
            for col in negAllCols:
                #print "neg col:", col
                user_product_index_neg.append([row, col])

        return (user_product_index_pos, user_product_index_neg)



    def trans_user_product_index_to_item_pos_neg(self, user_product_index_pos, user_product_index_neg):
        InOut.console_func_begin("get_user_product_list_posneg")
        user_product_list_pos = []
        user_product_list_neg = []

        user_product_list_pos = self.trans_user_product_index_to_item(user_product_index_pos)
        user_product_list_neg = self.trans_user_product_index_to_item(user_product_index_neg)

        return (user_product_list_pos, user_product_list_neg)


    def trans_user_product_index_to_item(self, user_product_index):
        InOut.console_func_begin("trans_user_product_index_to_item")

        print "user_product_index:", len(user_product_index)

        resList = []
        for unit in user_product_index:
            row = unit[0]
            col = unit[1]
            #print "unit:", len(unit)
            #print "unit[0]:", unit[0]
            #print "unit[1]:", unit[1]
            #print "row:%d, dictIndexUser:%s" % (row, len(self._dictIndexUser))
            #print "col:%d" % (col)
            #print "col:%d, _dictIndexItem:%s" % (col, len(self._dictIndexItem))
            user = self._dictIndexUser[row]
            item = self._dictIndexItem[col]
            resList.append([user, item])
        return resList

    def get_negAll_cols(self, N, posCols, negCols):
        #print "N:", N
        addCnt = len(posCols) - len(negCols)
        negAllCols = negCols
        if(addCnt <= 0):
            return negAllCols
        posSet = set(posCols)
        negSet = set(negCols)

        posnegSet = posSet | negSet
        negAllSet = negSet


        cnt = 0
        while(True):
            rnd = random.randrange(0, N)
            if(rnd in posnegSet):
                continue
            if(rnd in negAllSet):
                continue
            negAllSet.add(rnd)

            cnt += 1
            if(cnt >= addCnt):
                break
        negAllCols = list(negAllSet)
        return negAllCols


    def get_ratingList_pos(self):
        SparseMatrix.FindSparseMatrixNZ(self._R_Init)
        pass

    def get_ratingList_pos_neg(self):
        resList = []
        for rating in self._ratingList:
            user = rating[0]
            item = rating[1]
            rate = rating[2]
            if(rate > 0):
                pass
        pass

    pass

    def norm_exp_data_linear(self):
        InOut.console_func_begin("norm_exp_data_linear")
        print "_dict_user_event_featureList:", len(self._dict_user_event_featureList)

        self._R_linear = PreProcessing.norm_dict_str_str_listDouble_to_array_using_row_col_index(self._dict_user_event_featureList, self._dictUserIndex, self._dictItemIndex)
        self._n_linear_feature = PreProcessing.get_dict_str_str_listDouble_colcnt(self._dict_user_event_featureList)

    def norm_exp_data_user_weight(self):
        InOut.console_func_begin("norm_exp_data_user_weight")

        self._user_weight = GenerateExpDataUWeight.generate_user_weight_matrix(self._dict_user_user_weight_on, self._dict_user_user_weight_off, self._dictUserIndex, self._userSet, Config.p_mf_user_weight_on)
        print self._user_weight.shape
        pass

    @classmethod
    def IsItemPositive(cls, item):
        return (item > 0)



    def get_friend_set(self, user_id):
        onFriendSet = set()
        offFriendSet = set()
        if(user_id in self._dict_user_user_sameGroupCnt):
            onFriendSet = set(self._dict_user_user_sameGroupCnt[user_id].keys())
        if(user_id in self._dict_user_user_sameEventCnt):
            offFriendSet = set(self._dict_user_user_sameEventCnt[user_id].keys())
        return (onFriendSet, offFriendSet)




