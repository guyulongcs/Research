class Rating():
    def __init__(self, user="", item="", rate=0):
        self._user = user
        self._item = item
        self._rate = rate

    @classmethod
    def get_user_product_list(cls, ratingList):
        list = []

        for rating in ratingList:
            list.append([rating._user, rating._item])
        return list

        pass

    def toList(self):
        return [self._user, self._item, self._rate]

    @classmethod
    def ratingListToList(self, ratingList):
        res = []
        for rating in ratingList:
            res.append(rating.toList())
        return res
