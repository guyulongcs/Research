class Item():
    def __init__(self, id):
        self._id = id

    def __repr__(self):
        return str(self._id)

