__author__ = 'guyulong'


import time
import datetime
import pytz
import warnings
import numpy as np


class TimeTool():

    @classmethod
    def get_time_now(cls):
        now = datetime.datetime.now()
        return now

    @classmethod
    def get_time_now_str(cls):
        now = TimeTool.get_time_now()
        s = now.strftime("%Y-%m-%d %H:%M:%S")
        return s


    @classmethod
    def get_time_from_seconds(cls, n):
        n = int(n)
        timeUnit = TimeUnit(n)
        return timeUnit

    @classmethod
    def get_datetime_from_str(cls, s):
        s_format = "%Y-%m-%d %H:%M:%S"

        #t = time.strptime(s, s_format)
        #dt = datetime.datetime.fromtimestamp(time.mktime(t))
        dt = None

        try:
            dt =  datetime.datetime.strptime(s, s_format)
        except:
            warnings.warn("get_datetime_from_str...Time is not %s" % s_format)

        return dt

    @classmethod
    def get_datetime_or_str(cls, s):
        res = s
        dt = TimeTool.get_datetime_from_str(s)
        if(dt != None):
            res = dt
        return res
        pass


    @classmethod
    def get_datetime_from_timestamp(cls, s,  timeZone="America/Chicago"):
        tz = pytz.timezone(timeZone)
        dt = time.gmtime(float(s))
        dt = datetime.datetime.fromtimestamp(float(s), tz)
        return dt

    @classmethod
    def get_datetimestr_from_timestamp(cls, s, timeZone="America/Chicago"):
        dt = TimeTool.get_datetime_from_timestamp(s, timeZone)
        s = dt.strftime("%Y-%m-%d %H:%M:%S")
        return s

    @classmethod
    def get_time_vec_of_datetime_base(cls, dt):
        res = []
        #hour of day
        res = np.zeros(24*7)
        hourOfDay = dt.hour
        dayOfWeek = dt.weekday()
        index = (hourOfDay+1) * (dayOfWeek+1) - 1
        res[index] = 1

        return res

    @classmethod
    def get_time_vec_of_datetime(cls, dt):
        res = []
        #hour of day

        hourOfDay = dt.hour
        hourRegion = TimeTool.get_time_region_of_hour(hourOfDay)
        hourRegionCnt = TimeTool.get_time_region_cnt()

        dayOfWeek = dt.weekday()

        res = TimeTool.get_time_vec_of_datetime_append(hourRegionCnt, hourRegion, dayOfWeek)
        #res = TimeTool.get_time_vec_of_datetime_join(hourRegionCnt, hourRegion, dayOfWeek)
        #append
        # res = np.zeros(hourRegionCnt + 7)
        # res[hourRegion] = 1
        # res[hourRegionCnt + dayOfWeek] = 1

        #join
        index = (hourRegion) * (dayOfWeek+1) - 1
        res[index] = 1

        return res

    @classmethod
    def get_time_vec_of_datetime_append(cls, hourRegionCnt, hourRegion, dayOfWeek):

        res = np.zeros(hourRegionCnt + 7)
        res[hourRegion] = 1
        res[hourRegionCnt + dayOfWeek] = 1
        return res

    @classmethod
    def get_time_vec_of_datetime_join(cls, hourRegionCnt, hourRegion, dayOfWeek):
        #join
        res = np.zeros(hourRegionCnt * 7)
        index = (hourRegion) * (dayOfWeek+1) - 1
        res[index] = 1
        return res

    @classmethod
    def get_time_region_of_hour(cls, h):
        res = 0
        if(h <= 5):
            res = 0
        elif(res <= 12):
            res = 1
        elif(res <= 18):
            res = 2
        else:
            res = 3
        return res

    @classmethod
    def get_time_region_cnt(cls):
        res = 4
        return res


class TimeUnit():
    def __init__(self, n=0):
        self.h=0
        self.m=0
        self.s=0

        self.setValue(n)

    def toString(self):
        s = "%s H %s M %s S" % (str(self.h), str(self.m), str(self.s))
        return s

    def setValue(self, n):
        n = int(n)
        self.s = n
        if(self.s > 60):
            self.m = self.s / 60
            self.s = self.s % 60
        if(self.m > 60):
            self.h = self.m / 60
            self.m = self.m % 60

