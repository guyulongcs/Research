import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

class PlotLine():
    def __init__(self):
        #x
        self.xlabel = ""
        self.xcolor = []
        self.xaxis = []
        #y
        self.y = []
        self.yaxis = []
        self.ylabel = ""
        self.title = ""
        self.alpha=0.6
        self.grid = False
        self.file = ""
        self.text = None
        self.linewidth = 2
        self.alpha = 3

    def plot_line_help(self, plt, x, y1, ls, lab):
        return plt.plot(x, y1, ls, label =lab, lw=self.linewidth, alpha = self.alpha )

    def plot_line(self):
        #plot setting
        ymin = self.yaxis[0]
        ymax = self.yaxis[1]
        ytick = self.yaxis[2]


        #plot
        pp = PdfPages(self.file)
        plt.figure(1)
        plt.grid(self.grid)

        plt.plot(self.x, self.y)

        plt.title(self.title)

        plt.ylabel(self.ylabel)
        plt.ylim(ymin,ymax)


        pp.savefig()
        pp.close()
        plt.close()