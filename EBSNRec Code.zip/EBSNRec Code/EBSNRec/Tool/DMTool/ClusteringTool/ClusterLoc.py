from GeoLoc import *

class ClusterLoc():
    def __init__(self):
        self.locList = []
        self.centerLoc = GeoLoc()
        pass