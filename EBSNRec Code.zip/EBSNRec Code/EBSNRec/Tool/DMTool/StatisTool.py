from Tool.TypeTool.TypeProcessTool import *
from Tool.InOutTool.InOutTool import *

class StatisTool():
    def __init__(self):
        pass

    @classmethod
    def StatisListLineListColDict(cls, listLineList, col):
        dict = {}
        for listLine in listLineList:
            TypeProcessTool.dictStrInt_add_key(dict, listLine[col])
        return dict

    @classmethod
    def StatisDictStrInt(cls, dict):
        InOut.console_func_begin("AnalyseDictStrInt")
        #AnalyseTool.AnalyseDictStrIntSort(dict)
        StatisTool.StatisDictStrIntValue(dict)

    @classmethod
    def StatisDictStrIntSort(cls, dict):
        dictSort = TypeProcessTool.dict_sort(dict, True)
        for (key, value) in dictSort:
            print str(key) + "\t" + str(value)

        pass

    @classmethod
    def StatisDictStrIntValue(cls, dict):
        dictValueCnt = {}
        for value in dict.values():
            TypeProcessTool.dictStrInt_add_key(dictValueCnt, value)
        InOut.console_print_dict_str_str(dictValueCnt)

    @classmethod
    def StatisDictStrListstr2DictStrInt(cls, dict):
        dictRes = {}
        for (key, value) in dict.items():
            dictRes[key] = len(value)
        return dictRes