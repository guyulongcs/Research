
class GeoBoundBox():
    def __init__(self, swlat, swlon, nelat, nelon):
        self.swlat = swlat
        self.swlon = swlon
        self.nelat = nelat
        self.nelon = nelon