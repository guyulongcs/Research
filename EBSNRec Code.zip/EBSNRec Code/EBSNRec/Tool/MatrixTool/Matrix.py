import numpy as np


class Matrix():
    def __init__(self):
        self._matrix = None

    @classmethod
    def BuildDictIndexFromSet(cls, itemSet):
        dict = {}
        index = 0
        for item in itemSet:
            dict[item] = index
            index += 1
        return dict

    pass

