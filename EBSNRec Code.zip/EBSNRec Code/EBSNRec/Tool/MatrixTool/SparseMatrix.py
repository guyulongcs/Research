from scipy.sparse import *
import numpy as np
from Tool.InOutTool.InOutTool import *
from Tool.MatrixTool.Matrix import *
from Tool.TypeTool.TypeProcessTool import *


class SparseMatrix(Matrix):
    def __init__(self):

        pass

    def create(self, data, rowSet, colSet):
        self._matrix = SparseMatrix.CreateSparseMatrix(data, rowSet, colSet)

    @classmethod
    def IsItemPositive(cls, item):
        return (item > 0)

    @classmethod
    def CreateSparseMatrixInit(cls, data, rowSet, colSet):

        '''
        :param data: [rowItem, colItem, rating]
        :param rowSet: rowItem set
        :param colSet: colItem set
        :return:
        '''
        InOut.console_func_begin("CreateSparseMatrixInit")
        #print "rowSet:%d" % len(rowSet)
        dictRowIndex = Matrix.BuildDictIndexFromSet(rowSet)
        dictColIndex = Matrix.BuildDictIndexFromSet(colSet)

        dictIndexRow = TypeProcessTool.GetDictReverse(dictRowIndex)
        dictIndexCol = TypeProcessTool.GetDictReverse(dictColIndex)

        M = len(dictRowIndex)
        N = len(dictColIndex)
        rowList = []
        colList = []
        rowPosList = []
        rowNegList = []
        colPosList = []
        colNegList = []
        dataList= []
        dataPosList = []
        dataNegList= []
        for item in data:
            #print "item:", item
            rowItem = item[0]
            colItem = item[1]
            rating = item[2]

            #print len(dictRowIndex)
            #print dictRowIndex.keys()
            #print "rowItem:%s" % rowItem

            rowIndex = dictRowIndex[rowItem]
            colIndex = dictColIndex[colItem]
            rowList.append(rowIndex)
            colList.append(colIndex)



            dataList.append(rating)

            if(SparseMatrix.IsItemPositive(rating)):
                dataPosList.append(rating)
                rowPosList.append(rowIndex)
                colPosList.append(colIndex)
            else:
                dataNegList.append(rating)
                rowNegList.append(rowIndex)
                colNegList.append(colIndex)


        r = SparseMatrix.CreateSparseMatrixList(dataList, rowList, colList, M, N)
        r_pos = SparseMatrix.CreateSparseMatrixList(dataPosList, rowPosList, colPosList, M, N)
        r_neg = SparseMatrix.CreateSparseMatrixList(dataNegList, rowNegList, colNegList, M, N)



        return (r, r_pos, r_neg, M, N, dictRowIndex, dictColIndex, dictIndexRow, dictIndexCol)


    @classmethod
    def CreateSparseMatrix(cls, data, dictRowIndex, dictColIndex, flag_filt_not_positive=True):

        '''
        :param data: [rowItem, colItem, rating]
        :param rowSet: rowItem set
        :param colSet: colItem set
        :return:
        '''


        M = len(dictRowIndex)
        N = len(dictColIndex)
        rowList = []
        colList = []
        dataList = []

        for item in data:
            #print "item:", item
            rowItem = item[0]
            colItem = item[1]
            rating = item[2]


            rowIndex = dictRowIndex[rowItem]
            colIndex = dictColIndex[colItem]

            #dataList.append(rating)

            if(flag_filt_not_positive and (SparseMatrix.IsItemPositive(rating)==False)):
                continue
                pass

            dataList.append(rating)
            rowList.append(rowIndex)
            colList.append(colIndex)

        r = SparseMatrix.CreateSparseMatrixList(dataList, rowList, colList, M, N)



        return r

    @classmethod
    def CreateSparseMatrixList(cls, dataList, rowList, colList, M, N):
        '''
        :param data:   ratingList
        :param rowSet: rowIndexList
        :param colSet: colIndexList
        :return:
        '''
        res = csr_matrix((np.array(dataList), (np.array(rowList), np.array(colList))), shape = (M, N))
        SparseMatrix.PrintSparseMatrix(res.nnz, M, N)
        return res

    @classmethod
    def PrintSparseMatrix(cls, nnz, M, N):
        print "\nSparseMatrix:"
        print "shape:", M, ",", N
        print "nnz:", nnz
        sparseRatio = SparseMatrix.CalSparseMatrixSparseRatio(nnz, M, N)
        print "sparseRatio:", sparseRatio

    @classmethod
    def CalSparseMatrixSparseRatio(cls, nnz, M, N):
        r = 1 - float(nnz) / (M * N)
        return r

    @classmethod
    def FindSparseMatrixNZ(cls, m):
        #InOut.console_func_begin("FindSparseMatrixNZ")
        index = find(m)
        rowIndex = index[0]
        colIndex = index[1]


        #print "row:%d, col:%d" % (len(rowIndex), len(colIndex))
        #print "first item:%d, %d, %f" % (rowIndex[0], colIndex[0], m[rowIndex[0], colIndex[0]])
        return (rowIndex, colIndex)

    @classmethod
    def FindSparseMatrixNZRowColValue(cls, m):
        #InOut.console_func_begin("FindSparseMatrixNZ")
        index = find(m)
        rowIndex = index[0]
        colIndex = index[1]
        valueList = index[2]

        #print "row:%d, col:%d" % (len(rowIndex), len(colIndex))
        #print "first item:%d, %d, %f" % (rowIndex[0], colIndex[0], m[rowIndex[0], colIndex[0]])
        return (rowIndex, colIndex, valueList)

    @classmethod
    def cal_sparseMatrix_dot(cls, row1, row2):
        res = 0


        row1cols = find(row1)[1]
        row2cols = find(row2)[1]

        rowcols = TypeProcessTool.get_join_liststr(row1cols, row2cols)

        #print row1cols
        #print row2cols
        #print rowcols

        for col in rowcols:
            res += (row1[0, col] * row2[0, col])
        return res

    @classmethod
    def cal_sparseMatrix_veclist_sum(cls, veclist):

        res = sum(veclist)
        if(isinstance(res, int)):
            res = []
        #
        # print "\ncal_sparseMatrix_veclist_sum..."
        # print "vecList:", veclist
        # print "resList:", res

        return res

    @classmethod
    def cal_sparseMatrix_veclist_avg(cls, veclist):


        N = len(veclist)
        sum = SparseMatrix.cal_sparseMatrix_veclist_sum(veclist)

        #print "sum:"
        #print sum
        avg = sum

        if(N>0):
            avg = avg / float(N)

        res = avg

        return res

