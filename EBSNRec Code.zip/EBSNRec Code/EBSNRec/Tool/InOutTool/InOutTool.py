import sys


class InOut():
    @classmethod
    def console_func_begin(cls, str):
        print "\n>>>>>>>>>>>>%s begin..." % str

    @classmethod
    def console_func_end(cls, str):
         print "\n%s end..." % str

    @classmethod
    def except_info(cls, str):
        print "\nExcept in %s!" % str

        print "Unexpected error:", sys.exc_info()[0]

    @classmethod
    def debug(cls, str, debugMode=True):
        if(debugMode):
            print "debug...\t%s" % str

    @classmethod
    def console_print_dict_str_str(cls, d):
        lineList = []
        for key in d:
            line = str(key) + "\t" + str(d[key])
            lineList.append(line)
        InOut.console_print_linelist(lineList)

    @classmethod
    def console_print_linelist(cls, lineList):
        for line in lineList:
            print line

    @classmethod
    def printDebug(cls):
        str = "************************Debug************************"
        print str