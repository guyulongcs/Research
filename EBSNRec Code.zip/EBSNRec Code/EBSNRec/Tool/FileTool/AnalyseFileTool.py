from FileTool import *
class AnalyseFileTool():
    def __init__(self):
        pass

    @classmethod
    def AnalyseFileCSVColDict(cls, file, file_line_skip_cnt=0, p_delimiter=',', p_quotechar = '"'):
        listLineList = FileTool.ReadFileCSVToListStringList(file, file_line_skip_cnt, p_delimiter, p_quotechar)

