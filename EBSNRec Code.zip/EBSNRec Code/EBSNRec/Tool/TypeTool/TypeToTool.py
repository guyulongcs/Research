__author__ = 'guyulong'

import warnings
class TypeToTool():
    def __init__(self):
        pass

    @classmethod
    def float_str_to_float(cls, str):
        str = TypeToTool.norm_str(str)

        str = str.strip()

        #str = "3.14"
        # print "str:", str
        f = float(str)
        return f


        return res

    @classmethod
    def norm_str(cls, str):
        if(str == None or str == ""):
            str="0"
        return str



    @classmethod
    def float_str_to_int(cls, str):
        #n = 0
        if(str == ""):
            str = "0"

        n = int(round(float(str)))
        #try:
        #    n = int(round(float(str)))
            #print "str: %s" % str
            #print "n: %d" % n
        #except:
        #    print "str is not digit: $%s$" % str

        return n

    @classmethod
    def int_str_to_int(cls, str):
        n = None

        try:
            if(str == ""):
                str="0"

            n=int(str)
        except:
            warnings.warn("int_str_to_int")
            pass
        return n

    @classmethod
    def listLineList_to_linelist(cls, listLineList, connStr="\t"):
        resList = []
        for listLine in listLineList:
            line = connStr.join(listLine)
            resList.append(line)
        return resList

    @classmethod
    def setstr_to_setint(cls, setstr):
        res = set()
        for s in setstr:
            n = TypeToTool.str_to_int(s)
            res.add(n)
        return res

    @classmethod
    def dictStrStr_to_listStr(cls, dict):
        strList = []
        for key in dict:
            value = dict[key]
            line = str(key) + "\t" + str(value)
            strList.append(line)
        return strList


    @classmethod
    def list_to_set(cls, l):
        return set(l)

    @classmethod
    def listint_to_liststr(cls, l):
        return [str(i) for i in l]
