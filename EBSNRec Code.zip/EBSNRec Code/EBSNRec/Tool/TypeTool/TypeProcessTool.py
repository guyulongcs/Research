import random
from collections import Counter
from Tool.InOutTool.InOutTool import *
import math
from Tool.MathTool.MathTool import *
from TypeToTool import *

class TypeProcessTool():
    @classmethod
    def dict_sort(cls, a, descend = False):
        a = sorted(a.items(), key=lambda a: a[1], reverse = descend)
        return a

        #
        #for k, v in a:
        #   print "%s: %s" % (k, v)



    @classmethod
    def splitListByRatio(self, l, ratio):
        l1 = []
        l2 = []

        for item in l:
            n = random.random()
            if( n <= ratio):
                l1.append(item)
            else:
                l2.append(item)
        return (l1, l2)



    @classmethod
    def filt_liststr_by_set(cls, l, s):
        res= []
        if(len(l) == 0):
            return res
        for item in l:
            if(item in s):
                res.append(item)
        return res

    @classmethod
    def get_list_str_sub_n(cls, list, N=-1):
        res = []
        i=0
        for line in list:
            res.append(line)
            i += 1
            if(N >= 0 and i >= N):
                break
        return res

    @classmethod
    def get_list_most_common(cls, list):
        c = Counter(list)
        res = c.most_common(1)[0][0]
        return res

    @classmethod
    def dictStrSetstr_add_str_str(cls, dict, key, str):
        if(key not in dict):
            dict[key] = set()
        dict[key].add(str)

    @classmethod
    def dictStrListStr_add_str_str(cls, dict, key, str):
        if(key not in dict):
            dict[key] = list()
        dict[key].append(str)



    @classmethod
    def dictStrInt_add_key(cls, dict, key):
        if(key not in dict):
            dict[key] = 0
        dict[key] += 1

    @classmethod
    def dictStrDictStrValue_add_str_str_str(cls, d, key1, key2, str):
        if(key1 not in d):
            d[key1]={}
        d[key1][key2] = str

    @classmethod
    def FiltDictStrIntByThreshold(cls, dict, threshold):
        res = set()
        for key, value in dict.items():
            if(value >= threshold):
                res.add(key)
        return res

    @classmethod
    def GetDictReverse(cls, dict):
        res = {}
        for key, value in dict.items():
            res[value] = key
        return res

    @classmethod
    def check_dictStrSetStrValue(self, dict):
        InOut.console_func_begin("check_dictStrSetStrValue")
        for key in dict:
            value = dict[key]
            #print "len(value):", len(value)
            if(len(value) > 1):
                print "key:", key

    @classmethod
    def dictStrStrInt_add_str_liststr(cls, dict, key, liststr):
        #print "key:", key
        #print "listStr:"
        #print liststr
        if key not in dict:
            dict[key] = {}
        for str in liststr:
            if str not in dict[key]:
                dict[key][str] = 0
            dict[key][str] += 1

    @classmethod
    def get_dictstrstrint_value(cls, dict, key1, key2):
        res = 0
        if(key1 in dict and key2 in dict[key1]):
            res = dict[key1][key2]
        return res

    @classmethod
    def get_dictstrint_value(cls, dict, key):
        res = 0
        if(key in dict):
            res = dict[key]
        return res

    @classmethod
    def get_dict_str_setstr_value(cls, dict, key):
        res = set()
        if(key in dict):
            res = dict[key]
        return res

    @classmethod
    def cal_jaccard(cls, set1, set2):
        a = set1 & set2
        b = set1 | set2
        res = Math.divide(len(a), len(b))
        return res

    @classmethod
    def get_join_liststr(cls, ls1, ls2):
        s1 = set(ls1)
        s2 = set(ls2)
        s = s1 & s2
        l = list(s)
        return l

    @classmethod
    def is_float_zero(cls, f):
        flag = False
        esp = math.pow(10, -8)
        flag = f < esp
        return flag

    @classmethod
    def get_dictstrstrlist(cls, dict, key1, key2):
        res=[]
        try:
            res = dict[key1][key2]
        except:
            res = []
        return res

    @classmethod
    def cal_list_has_str_cnt(cls, l, s):
        cnt = 0
        for str in l:
            if(str == s):
                cnt += 1
        return cnt

    @classmethod
    def get_conn_listint(cls, li, ch):
        liststr = TypeToTool.listint_to_liststr(li)
        res = ch.join(liststr)
        return res

    @classmethod
    def sampleListByRatio(cls, l, ratio):
        N = len(l)
        k=int(N*ratio)
        index = random.sample(range(0,N), k)

        res = []
        for i in index:
            res.append(l[i])
        return res