
import math

class Math():
    @classmethod
    def sigmoid(cls, x):
        res=0
        try:
            res = 1 / (1+math.exp(-x))
        except:
            res = 0
        return res

    @classmethod
    def log(cls, x, base=math.e):
        res = 0
        res = math.log(x, base)
        return res

    @classmethod
    def divide(cls, x, y):
        y = float(y)
        if(y == 0):
            res = 0
        elif(Math.is_float_zero(y)):
            res = 0
        else:
            res = x / float(y)
        # print "divide:"
        # print "x:", x
        # print "y:", y
        return res

    @classmethod
    def divide_list_list(cls, lx, ly):
        res = []
        for i in xrange(len(lx)):
            x = lx[i]
            y = ly[i]
            r = Math.divide(x, y)
            res.append(r)
        return res

    @classmethod
    def is_float_zero(cls, f):
        flag = False
        esp = math.pow(10, -8)
        flag = f < esp
        return flag
