import random
import math

class RandomTool():

    @classmethod
    def get_random(cls, minNum, maxNum):
        res = random.randint(minNum, maxNum)
        return res

    @classmethod
    def get_random_list(cls, minNum, maxNum, cnt):
        list = []
        for i in range(cnt):
            num = RandomTool.get_random(minNum, maxNum)
            list.append(num)
        return list