class StringTool():
    @classmethod
    def SplitStr(cls, s, splitChar=','):
        res = s.split(splitChar)
        return res