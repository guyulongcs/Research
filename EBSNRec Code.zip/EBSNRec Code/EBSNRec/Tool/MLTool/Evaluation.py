import sklearn
from sklearn.metrics import *
from Tool.InOutTool.InOutTool import *
from Tool.TypeTool.TypeProcessTool import *

class Evaluation():
    def __init__(self):
        self.tp = 0
        self.fp = 0
        self.tn = 0
        self.fn = 0

        self.precision = 0.0
        self.recall = 0.0
        self.f1 = 0.0

    def SetValue(self, tp, fp, tn, fn):
        self.tp = tp
        self.fp = fp
        self.tn = tn
        self.fn = fn

    def evaluate(self):
        self.precision = self.tp / (float(self.tp + self.fp))
        self.recall = (self.tp ) / (float(self.tp + self.fn))
        try:
            self.f1 = 2 * self.precision * self.recall / (self.precision + self.recall)
        except:
            pass

        print "precision:%.3f, recall: %.3f, f1:%.3f" % (self.precision, self.recall, self.f1)

    @classmethod
    def metrics_real_predict(cls, realList, predictList):
        InOut.console_func_begin("metrics_real_predict")

        res =[]
        s = "realList:"
        #res.append(s)
        s = TypeProcessTool.get_conn_listint(realList, ' ')
        #res.append(s)

        s = "predictList:"
        #res.append(s)
        s = TypeProcessTool.get_conn_listint(predictList, ' ')

        #res.append(s)

        (posCnt, negCnt) = Evaluation.get_list_pos_neg_cnt(realList)
        s = "real pos:%d, neg:%d" % (posCnt, negCnt)
        res.append(s)

        accuracy =  accuracy_score(realList, predictList)

        precision = precision_score(realList, predictList,  average='micro')
        recall = recall_score(realList, predictList, average='micro')
        f1 = f1_score(realList, predictList)

        auc = Evaluation.auc_score(realList, predictList)

        s = "accuracy: %f" % accuracy
        res.append(s)
        s = "precision: %f, recall:%f, f1:%f" % (precision, recall, f1)
        res.append(s)
        s = "auc:%f" % (auc)
        res.append(s)

        InOut.console_print_linelist(res)

        return res

        pass

    @classmethod
    def get_list_pos_neg_cnt(cls, l):

        N = len(l)
        posL = [i for i in l if i > 0]
        pos = len(posL)
        neg = N-pos
        return (pos, neg)

    @classmethod
    def auc_score(cls, realList, predictList):
        res = 0
        fpr, tpr, thresholds = roc_curve(realList, predictList)
        res = auc(fpr, tpr)
        return res