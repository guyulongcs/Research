from sklearn.feature_extraction.text import *
class FeatureExtraction():
    def __init__(self):

        pass

    @classmethod
    def extract_list_str_tf_idf(cls, listStr, max_features=1000):
        print "extract_list_str_tf_idf..."
        tfIdfVectorizer = TfidfVectorizer(max_features=max_features)
        X = tfIdfVectorizer.fit_transform(listStr)
        print X.shape
        return X
        pass