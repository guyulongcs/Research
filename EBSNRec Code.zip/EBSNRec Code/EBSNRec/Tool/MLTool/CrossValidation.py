import random

class CrossValidation():


    @classmethod
    def split_list_train_test(cls, l, train_ratio):
        train_list = []
        test_list = []
        for item in l:
            rnd = random.random()
            if(rnd < train_ratio):
                train_list.append(item)
            else:
                test_list.append(item)

        return (train_list, test_list)
        pass

    @classmethod
    def split_list_train_validation_test(cls, l, train_ratio, validation_ratio):
        train_list = []
        validation_list = []
        test_list = []
        for item in l:
            rnd = random.random()
            if(rnd < train_ratio):
                train_list.append(item)
            elif (rnd < (train_ratio + validation_ratio)):
                validation_list.append(item)
            else:
                test_list.append(item)

        return (train_list, validation_list, test_list)
        pass


