import numpy as np

from Tool.TypeTool.TypeProcessTool import *
from Tool.InOutTool.InOutTool import *
from Tool.MathTool.MathTool import *

class PreProcessing():
    @classmethod
    def norm_dict_str_str_listDouble_to_array_using_row_col_index(cls, dict_str_str_listDouble, dictRowItemIndex, dictColItemIndex):
        InOut.console_func_begin("norm_dict_str_str_listDouble")
        listDoubleList = []
        for key1 in dict_str_str_listDouble:
            #print "key1:", key1
            for key2 in dict_str_str_listDouble[key1]:
                listDouble = dict_str_str_listDouble[key1][key2]

                #print "listDouble:", listDouble
                listDoubleList.append(listDouble)


        a = np.array(listDoubleList)
        a_col_mean = np.mean(a, 0)
        a_col_std = np.std(a, 0)

        dictRes = {}
        for key1 in dict_str_str_listDouble:
            for key2 in dict_str_str_listDouble[key1]:

                listDouble = dict_str_str_listDouble[key1][key2]


                listDoubleNorm = Math.divide_list_list(listDouble - a_col_mean, a_col_std)

                # print "listDouble:", listDouble
                # print "a_col_mean:", a_col_mean
                # print "a_col_std:", a_col_std
                # print "listDoubleNorm:", listDoubleNorm

                key1Index = dictRowItemIndex[key1]
                key2Index = dictColItemIndex[key2]

                arrayDoubleNorm = np.array(listDoubleNorm)
                arrayDoubleNorm = np.insert(arrayDoubleNorm, 0, 1)      #b
                #print "listDoubleNorm:", listDoubleNorm
                #print "arrayDoubleNorm:", arrayDoubleNorm
                TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictRes, key1Index, key2Index, arrayDoubleNorm)
        return dictRes
        pass

    # @classmethod
    # def norm_dict_str_str_listDouble(cls, dict_str_str_listDouble):
    #     InOut.console_func_begin("norm_dict_str_str_listDouble")
    #     listDoubleList = []
    #     for key1 in dict_str_str_listDouble:
    #         #print "key1:", key1
    #         for key2 in dict_str_str_listDouble[key1]:
    #             listDouble = dict_str_str_listDouble[key1][key2]
    #             #print "listDouble", listDouble
    #             listDoubleList.append(listDouble)
    #
    #     a = np.array(listDoubleList)
    #     a_col_mean = np.mean(a, 0)
    #     a_col_std = np.std(a, 0)
    #
    #     dictRes = {}
    #     for key1 in dict_str_str_listDouble:
    #         for key2 in dict_str_str_listDouble[key1]:
    #             listDouble = dict_str_str_listDouble[key1][key2]
    #             #print "listDouble", listDouble
    #             listDoubleNorm = (listDouble - a_col_mean) / a_col_std
    #             #print "listDoubleNorm", listDoubleNorm
    #             arrayDoubleNorm = np.insert(arrayDoubleNorm, 0, 1)
    #             TypeProcessTool.dictStrDictStrValue_add_str_str_str(dictRes, key1, key2, listDoubleNorm)
    #     return dictRes
    #     pass

    @classmethod
    def get_dict_str_str_listDouble_colcnt(cls, dict_str_str_listDouble):
        N= 0
        for key1 in dict_str_str_listDouble:
            #print "key1:", key1
            for key2 in dict_str_str_listDouble[key1]:
                listDouble = dict_str_str_listDouble[key1][key2]
                N = len(listDouble)

                N += 1     #b
                break
            break
        return N

