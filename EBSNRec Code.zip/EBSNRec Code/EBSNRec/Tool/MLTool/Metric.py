from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

class Metric():
    @classmethod
    def cal_vec_cos(cls, v1, v2):

        #if((len(v1) == 0) or (len(v2)==0)):
        #    return 0


        res = 0

        if(Metric.is_type_list(v1) or Metric.is_type_list(v2)):
            v1 = np.array(v1)
            v2 = np.array(v2)

        #print "v1:", v1
        #v1 = v1.reshape(1,-1)
        #v2 = v2.reshape(1,-1)

        #
        if(Metric.is_empty_arr(v1) or Metric.is_empty_arr(v2)):
             res = 0
        # #try:
        # #if(True):
        else:
             res = cosine_similarity(v1, v2)
             res = res [0,0]
        #except:
        #    res = 0

        # print "v1:", v1
        # print "v2:", v2
        # print "cos:", res

        return res

    @classmethod
    def is_type_list(cls, v):
        return isinstance(v, list)

    @classmethod
    def is_empty_arr(cls, v):
        res = True
        if(isinstance(v, list)):
            res = (len(v) == 0)
        else:
            shape = v.shape
            if(len(shape) == 1):
                res = (v.shape[0]==0)
            elif(len(shape) == 2):
                res = (v.shape[1]==0)
        return res